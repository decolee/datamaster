# Databricks notebook source
# MAGIC %run ./funcionario_dados/atualizar_tb_funcionario

# COMMAND ----------

# MAGIC %run ./funcionario_dados/data_masking