# Databricks notebook source
# MAGIC %run ./app_2

# COMMAND ----------

# MAGIC %run ./qa_teste

# COMMAND ----------

# MAGIC %run ./app_3

# COMMAND ----------

# MAGIC %run ./app_4

# COMMAND ----------

# MAGIC %run ./app_5

# COMMAND ----------

# MAGIC %run ./app_6

# COMMAND ----------

# MAGIC %run ./kafka/envio_stream

# COMMAND ----------

# MAGIC %run ./lider_view

# COMMAND ----------

