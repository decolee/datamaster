# Databricks notebook source
spark.sparkContext.setLogLevel("WARN")  # Options include ERROR, WARN, INFO, DEBUG

# COMMAND ----------

# MAGIC %run ./create_mock_table/create_table

# COMMAND ----------

# MAGIC %run ./perguntas/perguntas_nv_basico

# COMMAND ----------

# MAGIC %run ./perguntas/perguntas_nv_medio

# COMMAND ----------

# MAGIC %run ./perguntas/perguntas_nv_avancado

# COMMAND ----------

# MAGIC %run ./perguntas/create_table_perguntas

# COMMAND ----------

