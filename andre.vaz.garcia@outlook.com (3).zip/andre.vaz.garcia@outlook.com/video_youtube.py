# Databricks notebook source
pip install pytube

# COMMAND ----------

pip install moviepy

# COMMAND ----------

pip install SpeechRecognition

# COMMAND ----------

pip install --upgrade moviepy imageio-ffmpeg

# COMMAND ----------

from pytube import YouTube
import subprocess
import os
import speech_recognition as sr

def download_youtube_video(url):
    yt = YouTube(url)
    video = yt.streams.filter(only_audio=True).first()
    return video.download()

def extract_audio_ffmpeg(video_path, overwrite=False):
    audio_path = video_path.split('.')[0] + '.wav'

    # Check if the audio file already exists
    if os.path.exists(audio_path):
        if overwrite:
            print(f"Overwriting existing file: {audio_path}")
        else:
            print(f"File already exists: {audio_path}")
            return audio_path

    command = ['ffmpeg', '-i', video_path, '-vn', '-acodec', 'pcm_s16le', '-ar', '44100', '-ac', '2', audio_path]
    if overwrite:
        command.insert(1, '-y')
    subprocess.run(command)
    return audio_path

def convert_audio_to_text(audio_path):
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio_data = recognizer.record(source)
    return recognizer.recognize_google(audio_data)

# User inputs the YouTube URL
youtube_url = input("Enter the YouTube video URL: ")

video_path = download_youtube_video(youtube_url)
audio_path = extract_audio_ffmpeg(video_path, overwrite=True)
text = convert_audio_to_text(audio_path)

# Print the extracted text
print(text)

# Cleanup: Delete the downloaded video file
os.remove(video_path)


# COMMAND ----------

