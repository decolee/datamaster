# Databricks notebook source
# MAGIC %run ./create_siglas_e_graficos/create_df_siglas

# COMMAND ----------

# MAGIC %run ./create_siglas_e_graficos/analises_e_graficos

# COMMAND ----------

