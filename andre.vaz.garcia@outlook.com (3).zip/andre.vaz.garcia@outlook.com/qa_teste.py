# Databricks notebook source
import random

def buscar_funcionario_por_matricula(matricula):
    return funcionario_df.filter(funcionario_df.matricula == matricula).first()

def realizar_pergunta(perguntas, assunto, total_perguntas, matricula):
    resultados = []
    for i, pergunta_selecionada in enumerate(random.sample(perguntas, total_perguntas), start=1):
        print(f"{assunto} - Pergunta {i} de {total_perguntas}")
        print(pergunta_selecionada['pergunta'])
        for opcao in pergunta_selecionada['opcoes']:
            print(opcao)
        while True:
            resposta = input("Escolha a opção: ").upper()
            if resposta in ['A', 'B', 'C', 'D', 'E']:
                resultado = 1 if resposta == pergunta_selecionada['resposta_correta'] else 0
                resultados.append((matricula, pergunta_selecionada['id'], resultado))
                break
            else:
                print("Resposta não existe, selecione A, B, C, D ou E.")
    return resultados


# Exemplo de matrículas para cada nível
print("Exemplos de matrícula:")
for nivel in ['basico', 'medio', 'avancado']:
    exemplo = funcionario_df.filter(funcionario_df.nivel == nivel).first()
    if exemplo:
        print(f"Matrícula: {exemplo['matricula']} - Nível: {nivel}")

# Solicitar a matrícula do usuário
matricula_input = input("Insira sua matricula: ")
funcionario = buscar_funcionario_por_matricula(matricula_input)

# Combinar todas as perguntas de nível básico
#todas_perguntas_basico = perguntas_data_engineer_basico + perguntas_machine_learning_basico + perguntas_maestro_basico + perguntas_controlm_basico + perguntas_azure_basico
#todas_perguntas_intermediario =
#todas_perguntas_avancado = 
if funcionario:
    print(f"Bem-vindo {funcionario['Nome']}, seu nível é {funcionario['nivel']}")
    nivel = funcionario['nivel']
    if nivel == 'basico':
        resultados = realizar_pergunta(todas_perguntas_basico, 'Data Engineering Básico', 5, matricula_input)
    elif nivel == 'medio':
        resultados = realizar_pergunta(perguntas_data_engineer_intermediario, 'Data Engineering Intermediário', 5, matricula_input)
    elif nivel == 'avancado':
        resultados = realizar_pergunta(todas_perguntas_avancado, 'Data Engineering Avançado', 5, matricula_input)
    else:
        print("Nível desconhecido.")
        resultados = []

    # Convertendo os resultados em um DataFrame e mostrando
    if resultados:
        resultados_df = spark.createDataFrame(resultados, ["Matricula", "ID_Pergunta", "Resultado"])
        print("Resultados, n1 = correto, n0 = errado")
        resultados_df.show()
else:
    print("Matrícula não encontrada, tente novamente")
