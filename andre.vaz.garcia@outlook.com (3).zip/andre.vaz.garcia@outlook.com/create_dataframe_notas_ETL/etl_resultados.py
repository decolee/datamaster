# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col, lit, regexp_extract

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("TransformacaoDFCompleta").getOrCreate()

# Carregar o DataFrame de resultados
# Suponha que df_resultados já esteja carregado com as colunas 'matricula', 'ID_Pergunta', e 'Resultado'

# Extrair a categoria de cada ID_Pergunta
df_categoria = df_resultados.withColumn("categoria", regexp_extract("ID_Pergunta", r"(\D+)$", 1))

# Traduzir abreviações para nomes completos
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}
for abrev, nome in traducao_categoria.items():
    df_categoria = df_categoria.withColumn("categoria", 
                                           when(col("categoria") == abrev, nome).otherwise(col("categoria")))

# Converter Resultado para correto/errado
df_categoria = df_categoria.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Pivotar para transformar categorias em colunas e contar 'correto' e 'errado'
df_pivotado = df_categoria.groupBy("matricula").pivot("categoria").agg(
    sum(when(col("Resultado") == "correto", 1)).alias("corretas"),
    sum(when(col("Resultado") == "errado", 1)).alias("erradas")
).na.fill(0)

# Lista de categorias para iterar
categorias = list(traducao_categoria.values())

# Calcular a nota para cada categoria
for categoria in categorias:
    df_pivotado = df_pivotado.withColumn(f"nota_{categoria}", 
                                          (col(f"{categoria}_corretas") / 
                                           (col(f"{categoria}_corretas") + col(f"{categoria}_erradas"))) * 100)

# Selecionar e renomear colunas conforme necessário
colunas_selecionadas = ["matricula"] + \
                       [f"{categoria}_corretas" for categoria in categorias] + \
                       [f"{categoria}_erradas" for categoria in categorias] + \
                       [f"nota_{categoria}" for categoria in categorias]

df_final = df_pivotado.select(*colunas_selecionadas)

# Exibir o DataFrame final para verificação
df_final.show(truncate=False)

# Encerrar a sessão Spark, se necessário
# spark.stop()
