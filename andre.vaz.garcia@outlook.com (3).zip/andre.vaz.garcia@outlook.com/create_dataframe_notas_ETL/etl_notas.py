# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, sum, length, expr,lit, regexp_extract, concat,format_number

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CalculoNotas").enableHiveSupport().getOrCreate()

# Ler a tabela resultados em um DataFrame
df_resultados = spark.table("resultados")

# Função para traduzir o ID da pergunta para a categoria correspondente
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}

# Criar uma coluna com a categoria traduzida
df_traduzido = df_resultados.withColumn("categoria", 
    expr("""
        CASE 
            WHEN substring(ID_Pergunta, -2) = 'az' THEN 'azure'
            WHEN substring(ID_Pergunta, -2) = 'ms' THEN 'maestro'
            WHEN substring(ID_Pergunta, -2) = 'ml' THEN 'machine_learning'
            WHEN substring(ID_Pergunta, -2) = 'cm' THEN 'control_m'
            WHEN substring(ID_Pergunta, -2) = 'de' THEN 'data_engineer'
        END
    """))

# Substituindo valores de Resultado por 'correto' e 'errado'
df_traduzido = df_traduzido.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Agrupar por matrícula e categoria, e contar 'correto' e 'errado'
df_agrupado = df_traduzido.groupBy("matricula", "categoria").pivot("Resultado").count()

# Calcular a porcentagem de acertos
df_notas = df_agrupado.withColumn("nota", 
                                  concat(format_number((col("correto") / (col("correto") + col("errado"))) * 100, 2), lit('%')))

# Ajuste conforme necessário para incluir as colunas 'corretas' e 'erradas'
# E renomear colunas de nota para seguir o formato desejado

# Exibir o DataFrame para verificar o resultado
df_notas.show()
