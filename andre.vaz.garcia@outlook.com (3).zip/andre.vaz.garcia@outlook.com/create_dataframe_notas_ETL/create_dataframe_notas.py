# Databricks notebook source
# MAGIC %md
# MAGIC Criando o Dataframe df_notas

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, concat, format_number, lit, expr

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CalculoNotas").enableHiveSupport().getOrCreate()

def traduzir_categoria(df_resultados):
    """
    Traduz o ID da pergunta para a categoria correspondente.
    """
    traducao_expr = """
        CASE 
            WHEN substring(ID_Pergunta, -2) = 'az' THEN 'azure'
            WHEN substring(ID_Pergunta, -2) = 'ms' THEN 'maestro'
            WHEN substring(ID_Pergunta, -2) = 'ml' THEN 'machine_learning'
            WHEN substring(ID_Pergunta, -2) = 'cm' THEN 'control_m'
            WHEN substring(ID_Pergunta, -2) = 'de' THEN 'data_engineer'
        END
    """
    return df_resultados.withColumn("categoria", expr(traducao_expr))

def substituir_resultados(df):
    """
    Substitui valores de Resultado por 'correto' e 'errado'.
    """
    return df.withColumn("Resultado", when(col("Resultado") == 1, "correto").otherwise("errado"))

def agrupar_calcular_notas(df):
    """
    Agrupa por matrícula e categoria, conta 'correto' e 'errado', e calcula a porcentagem de acertos.
    """
    df_agrupado = df.groupBy("matricula", "categoria").pivot("Resultado").count()
    return df_agrupado.withColumn("nota", concat(format_number((col("correto") / (col("correto") + col("errado"))) * 100, 2), lit('%')))

def calcular_notas():
    """
    Função principal que executa o fluxo de processamento.
    """
    df_resultados = spark.table("resultados")
    df_traduzido = traduzir_categoria(df_resultados)
    df_traduzido = substituir_resultados(df_traduzido)
    df_notas = agrupar_calcular_notas(df_traduzido)
    df_notas.show()

# Chamar a função principal
calcular_notas()


# COMMAND ----------

# MAGIC %md
# MAGIC Testes unitários.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col, lit, regexp_extract, sum

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("TransformacaoDFCompleta").getOrCreate()

# Suponha que df_resultados já esteja carregado com as colunas 'matricula', 'ID_Pergunta', e 'Resultado'

def extrair_categoria(df_resultados):
    return df_resultados.withColumn("categoria", regexp_extract("ID_Pergunta", r"(\D+)$", 1))

def traduzir_abreviacoes(df, traducao_categoria):
    for abrev, nome in traducao_categoria.items():
        df = df.withColumn("categoria", when(col("categoria") == abrev, nome).otherwise(col("categoria")))
    return df

def converter_resultado(df):
    return df.withColumn("Resultado", when(col("Resultado") == 1, "correto").otherwise("errado"))

def pivotar_df(df):
    return df.groupBy("matricula").pivot("categoria").agg(
        sum(when(col("Resultado") == "correto", 1)).alias("corretas"),
        sum(when(col("Resultado") == "errado", 1)).alias("erradas")
    ).na.fill(0)

def calcular_notas(df, categorias):
    for categoria in categorias:
        df = df.withColumn(f"nota_{categoria}", 
                           (col(f"{categoria}_corretas") / 
                            (col(f"{categoria}_corretas") + col(f"{categoria}_erradas"))) * 100)
    return df

def selecionar_renomear_colunas(df, categorias):
    colunas_selecionadas = ["matricula"] + \
                           [f"{categoria}_corretas" for categoria in categorias] + \
                           [f"{categoria}_erradas" for categoria in categorias] + \
                           [f"nota_{categoria}" for categoria in categorias]
    return df.select(*colunas_selecionadas)

def transformar_df_completo(df_resultados, traducao_categoria):
    categorias = list(traducao_categoria.values())
    df_categoria = extrair_categoria(df_resultados)
    df_categoria = traduzir_abreviacoes(df_categoria, traducao_categoria)
    df_categoria = converter_resultado(df_categoria)
    df_pivotado = pivotar_df(df_categoria)
    df_pivotado = calcular_notas(df_pivotado, categorias)
    df_final = selecionar_renomear_colunas(df_pivotado, categorias)
    df_final.show(truncate=False)

# Exemplo de uso:
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}

# Suponha que df_resultados já esteja definido
# transformar_df_completo(df_resultados, traducao_categoria)

# Encerrar a sessão Spark, se necessário
# spark.stop()


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, concat, format_number, lit, expr

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CalculoNotas").enableHiveSupport().getOrCreate()

def traduzir_categoria(df_resultados):
    """
    Traduz o ID da pergunta para a categoria correspondente.
    """
    traducao_expr = """
        CASE 
            WHEN substring(ID_Pergunta, -2) = 'az' THEN 'azure'
            WHEN substring(ID_Pergunta, -2) = 'ms' THEN 'maestro'
            WHEN substring(ID_Pergunta, -2) = 'ml' THEN 'machine_learning'
            WHEN substring(ID_Pergunta, -2) = 'cm' THEN 'control_m'
            WHEN substring(ID_Pergunta, -2) = 'de' THEN 'data_engineer'
        END
    """
    return df_resultados.withColumn("categoria", expr(traducao_expr))

def substituir_resultados(df):
    """
    Substitui valores de Resultado por 'correto' e 'errado'.
    """
    return df.withColumn("Resultado", when(col("Resultado") == 1, "correto").otherwise("errado"))

def agrupar_calcular_notas(df):
    """
    Agrupa por matrícula e categoria, conta 'correto' e 'errado', e calcula a porcentagem de acertos.
    """
    df_agrupado = df.groupBy("matricula", "categoria").pivot("Resultado").count()
    return df_agrupado.withColumn("nota", concat(format_number((col("correto") / (col("correto") + col("errado"))) * 100, 2), lit('%')))

def calcular_notas():
    """
    Função principal que executa o fluxo de processamento.
    """
    df_resultados = spark.table("resultados")
    df_traduzido = traduzir_categoria(df_resultados)
    df_traduzido = substituir_resultados(df_traduzido)
    df_notas = agrupar_calcular_notas(df_traduzido)
    df_notas.show()

# Chamar a função principal
calcular_notas()
