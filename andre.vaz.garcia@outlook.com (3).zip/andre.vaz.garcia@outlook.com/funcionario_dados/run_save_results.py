# Databricks notebook source
funcionario_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Transformando valor string para long. (vamos utilizar essa coluna mais para frente)

# COMMAND ----------

from pyspark.sql import functions as F

# Transformando a coluna 'nota_media' de string para long
funcionario_df = funcionario_df.withColumn("nota_media", funcionario_df["nota_media"].cast("long"))

# Verificando o esquema após a transformação
funcionario_df.printSchema()


# COMMAND ----------

resultados_df.write.format("parquet").insertInto("resultados")
#criar uma sigla de database e salvar ele como um resultado ex pe_resultados. 