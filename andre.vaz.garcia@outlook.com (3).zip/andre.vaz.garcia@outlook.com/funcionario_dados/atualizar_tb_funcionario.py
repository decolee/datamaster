# Databricks notebook source
# MAGIC %md
# MAGIC from pyspark.sql import SparkSession
# MAGIC from pyspark.sql.functions import col
# MAGIC
# MAGIC # Ajustando o tipo da coluna 'nota_media' para long
# MAGIC funcionario_df = funcionario_df.withColumn("nota_media", col("nota_media").cast("long"))
# MAGIC
# MAGIC # Salvando o DataFrame ajustado como uma tabela, sobrescrevendo a tabela existente
# MAGIC funcionario_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(nome_tabela)
# MAGIC
# MAGIC print(f"A tabela {nome_tabela} foi atualizada com sucesso.")
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession

# Nome da tabela
nome_tabela = "tb_funcionarios"

# Verifica se a tabela existe
if not spark._jsparkSession.catalog().tableExists(nome_tabela):
    # Se a tabela não existir, cria a tabela a partir do DataFrame 'funcionario_df'
    funcionario_df.write.mode("overwrite").saveAsTable(nome_tabela)
    print(f"A tabela {nome_tabela} foi criada com sucesso.")
else:
    # Caso a tabela já exista, uma mensagem é exibida
    print(f"A tabela {nome_tabela} já existe.")
