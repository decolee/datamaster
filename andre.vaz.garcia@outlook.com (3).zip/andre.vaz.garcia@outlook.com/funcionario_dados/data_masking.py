# Databricks notebook source
# MAGIC %md
# MAGIC Dois tipos de data masking diferentes, o primeiro (que está comentado) é uma forma mais complexa e demorada, utilizando regex, a vantagem dele é que pode ser atribuido a diversos dados diferentes por conta da sua localização por regex match, já a segunda forma está sendo utilizada um modelo mais básico aplicado a uma fonte de dados específica, assim ele respeita os padrões de masking mas ganha performance.

# COMMAND ----------

# MAGIC %md
# MAGIC from pyspark.sql import SparkSession
# MAGIC from pyspark.sql.functions import col, lit, regexp_replace, expr
# MAGIC
# MAGIC # Inicializando a sessão Spark
# MAGIC spark = SparkSession.builder.appName("DataMasking").getOrCreate()
# MAGIC
# MAGIC # Carregando a tabela tb_funcionarios
# MAGIC df_funcionarios = spark.table("tb_funcionarios")
# MAGIC
# MAGIC # Aplicando o data masking
# MAGIC df_masked = df_funcionarios.withColumn("email", regexp_replace("email", "^[^@]+", "*****")) \
# MAGIC                            .withColumn("nome", expr("concat(repeat('*', length(nome)-1), substr(nome, -1, 1))")) \
# MAGIC                            .withColumn("matricula", lit("********"))
# MAGIC
# MAGIC # Salvando a tabela com os dados mascarados
# MAGIC df_masked.write.mode("overwrite").saveAsTable("tb_funcionarios_mask")
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr, col

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("DataMaskingOptimized").getOrCreate()

# Carregando a tabela tb_funcionarios
df_funcionarios = spark.table("tb_funcionarios")

# Convertendo a coluna 'nota_media' de StringType para LongType para evitar conflitos de tipo
df_funcionarios = df_funcionarios.withColumn("nota_media", col("nota_media").cast("long"))

# Aplicando o data masking de maneira otimizada
df_masked = df_funcionarios \
    .withColumn("email", expr("CONCAT('*****', SUBSTRING(email, INSTR(email, '@'), LENGTH(email)))")) \
    .withColumn("nome", expr("CONCAT(REPEAT('*', LENGTH(nome) - 1), SUBSTRING(nome, -1))")) \
    .withColumn("matricula", expr("REPEAT('*', 8)"))

# Salvando a tabela com os dados mascarados
df_masked.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("tb_funcionarios_mask")
