# Databricks notebook source
# MAGIC %md
# MAGIC Restart Python lib para funcionar a API da OpenAI

# COMMAND ----------

# Comando para reiniciar o kernel Python no Databricks
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC Installs necessários para o código:

# COMMAND ----------

# MAGIC %pip install langchain
# MAGIC %pip install pypdf
# MAGIC %pip install yt_dlp
# MAGIC %pip install pydub
# MAGIC %pip install unstructured > /dev/null
# MAGIC %pip install chromadb
# MAGIC %pip install lark
# MAGIC %pip install openai
# MAGIC %pip install tiktoken
# MAGIC %pip install -U langchain-openai
# MAGIC %pip install pysqlite3-binary
# MAGIC %pip install PyPDF2
# MAGIC %pip install pymupdf

# COMMAND ----------

# MAGIC %md
# MAGIC Criando o enviroment da chave OpenAI, necessário ser colocado a chave OpenAI em formato de input toda vez que rodar o código.

# COMMAND ----------

import getpass
import os

os.environ["OPENAI_API_KEY"] = getpass.getpass("OpenAI API Key:")

# COMMAND ----------

# MAGIC %md
# MAGIC Setando valores de environment para utilizar o Framework LangChain

# COMMAND ----------

import os

import sys
# sys.path.append('../..')

from dotenv import load_dotenv
load_dotenv()
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.langchain.plus"

# COMMAND ----------

# MAGIC %md
# MAGIC Framework pyPDF

# COMMAND ----------

from langchain.document_loaders import PyPDFLoader

# Copy the file from DBFS to the local file system
dbutils.fs.cp("dbfs:/FileStore/pysparkguide.pdf", "file:/tmp/pyspark.pdf")

# Use the local file path for PyPDFLoader
pdf_loader = PyPDFLoader("/tmp/pyspark.pdf")
pdf_pages = pdf_loader.load()
#pdf_text = pdf_loader.load()


# COMMAND ----------

# MAGIC %md
# MAGIC Utilização do page extract para separar os textos do pdf.

# COMMAND ----------

from PyPDF2 import PdfReader

# Path to the PDF file
pdf_path = "/tmp/pyspark.pdf"

# Initialize a PDF reader object
reader = PdfReader(pdf_path)

# Initialize a variable to hold the extracted text
pdf_text = ""

# Iterate over pages and extract text
for page in reader.pages:
    pdf_text += page.extract_text() + "\n"

# Now, pdf_text contains all the text extracted from the PDF
print(pdf_text)


# COMMAND ----------

import fitz  # PyMuPDF

def convert_pdf_to_text(pdf_path):
    # Open the PDF file
    document = fitz.open(pdf_path)
    
    # Initialize a text holder
    text = ""
    
    # Iterate through each page in the PDF
    for page_num in range(len(document)):
        # Get a page
        page = document.load_page(page_num)
        
        # Extract text from the page
        text += page.get_text()
    
    # Close the document
    document.close()
    
    return text

# Path to your PDF file
pdf_path = '/tmp/pyspark.pdf'

# Convert PDF to text
pdf_text = convert_pdf_to_text(pdf_path)

# Optionally, print or process the extracted text
print(pdf_text)


# COMMAND ----------

pdf_docs = docs
pdf_pages = text

# COMMAND ----------

# MAGIC %run ./Splitting_the_documents

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

pdf_docs = r_splitter.split_documents(pdf_pages)

# COMMAND ----------

pdf_pages = text

# COMMAND ----------

pdf_docs = docs

# COMMAND ----------

print (pdf_docs)

# COMMAND ----------

# Caminho no sistema de arquivos local
local_file_path = "/tmp/textpyspark.txt"

# Abrir o arquivo para escrita
with open(local_file_path, "w") as file:
    # Iterar sobre cada documento na lista pdf_docs
    for doc in pdf_docs:
        # Extrair o conteúdo de texto de cada documento
        page_content = doc.page_content  # Ajuste este atributo se necessário
        # Escrever o conteúdo de texto no arquivo, seguido de uma quebra de linha
        file.write(page_content + "\n")

# Copiar o arquivo do sistema local para o DBFS
dbfs_path = "dbfs:/FileStore/textpyspark.txt"  # Destino no DBFS
dbutils.fs.cp(f"file:{local_file_path}", dbfs_path)

print(f"Arquivo salvo com sucesso em {dbfs_path}")


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("PDF to Parquet").getOrCreate()

# Definir o esquema para o DataFrame
schema = StructType([
    StructField("page_content", StringType(), True)
])

# Criar uma lista de tuplas a partir de pdf_docs (cada tupla contendo o conteúdo de uma página)
data = [(doc.page_content,) for doc in pdf_docs]

# Criar o DataFrame
df = spark.createDataFrame(data, schema)

# Mostrar o DataFrame para verificação
df.show()


# COMMAND ----------

# Definir o caminho no DBFS onde o arquivo Parquet será salvo
parquet_path = "/FileStore/pdf_docs_parquet"

# Salvar o DataFrame como Parquet
df.write.mode("overwrite").parquet(parquet_path)

print(f"Arquivo Parquet salvo com sucesso em {parquet_path}")


# COMMAND ----------

# MAGIC %md ### Creating a RetrievalQA chain with PySpark-based document loading

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import lit

# Função para iniciar ou obter a sessão Spark existente
def get_or_create_spark_session(app_name="PDF Content to DataFrame"):
    return SparkSession.builder.appName(app_name).getOrCreate()

# Suponha que 'pdf_docs' seja sua lista de documentos extraídos, onde cada 'doc' tem um atributo 'page_content'
def create_pdf_dataframe(pdf_docs, number_of_articles=20):
    # Verifica se a lista não está vazia e tem elementos suficientes
    if not pdf_docs or len(pdf_docs) < number_of_articles:
        raise ValueError("A lista 'pdf_docs' está vazia ou contém menos elementos do que 'number_of_articles'")
    
    # Definir o esquema para o DataFrame
    schema = StructType([
        StructField("page_content", StringType(), True),
        StructField("source", StringType(), True)  # Incluímos uma coluna extra para a fonte, se necessário
    ])

    # Criar uma lista de tuplas a partir dos documentos, incluindo um identificador de fonte, se aplicável
    data = [(doc.page_content, "source_info") for doc in pdf_docs[:number_of_articles]]

    # Iniciar a sessão Spark
    spark = get_or_create_spark_session()

    # Criar o DataFrame com o esquema definido
    pdf_dataframe = spark.createDataFrame(data, schema)

    return pdf_dataframe

# Supondo que 'pdf_docs' esteja definida, criar o DataFrame
try:
    pdf_dataframe = create_pdf_dataframe(pdf_docs, 20)
    # Exibir o DataFrame
    display(pdf_dataframe)
except ValueError as e:
    print(e)


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

# Iniciar a sessão Spark, se ainda não foi iniciada
spark = SparkSession.builder.appName("PDF Content to DataFrame").getOrCreate()

# Suponha que 'pdf_docs' seja a sua lista de documentos extraídos
# Definir o esquema para o DataFrame
schema = StructType([
    StructField("page_content", StringType(), True)
])

# Criar uma lista de tuplas a partir dos primeiros 'number_of_articles' documentos em 'pdf_docs'
number_of_articles = 20  # ou o número de páginas que você deseja incluir
data = [(doc.page_content,) for doc in pdf_docs[:number_of_articles]]

# Criar o DataFrame com o esquema definido
pdf_dataframe = spark.createDataFrame(data, schema)

# Exibir o DataFrame
display(pdf_dataframe)


# COMMAND ----------

from langchain.document_loaders import PySparkDataFrameLoader

# Supondo que pdf_dataframe seja o seu DataFrame PySpark contendo o texto do PDF
loader = PySparkDataFrameLoader(spark, pdf_dataframe, page_content_column="page_content")
documents = loader.load()

# COMMAND ----------

# MAGIC %md The following lines are all that is needed for loading data from a PySpark Dataframe into Langchain 

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter

text_splitter = RecursiveCharacterTextSplitter(chunk_size=3000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)
print(f"Number of documents: {len(texts)}")

# COMMAND ----------

#%pip install openai

# COMMAND ----------

# MAGIC %pip install faiss-gpu

# COMMAND ----------

# MAGIC %md ### Create a FAISS vector store using HuggingfaceEmbeddings
# MAGIC
# MAGIC This FAISS vector store is the intermediate step to ensure you can log the model with MLflow.

# COMMAND ----------

from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS

embeddings = OpenAIEmbeddings()
db = FAISS.from_documents(texts, embeddings)

# COMMAND ----------

# MAGIC %md ### Create a RetrievalQA chain

# COMMAND ----------

from langchain.chains import RetrievalQA
from langchain import OpenAI

retrieval_qa = RetrievalQA.from_chain_type(llm=OpenAI(), chain_type="stuff", retriever=db.as_retriever())

# COMMAND ----------

import mlflow

persist_directory = "langchain/faiss_index"
db.save_local(persist_directory)

def load_retriever(persist_directory):
  embeddings = OpenAIEmbeddings()
  db = FAISS.load_local(persist_directory, embeddings)
  return db.as_retriever()

# Log the RetrievalQA chain
with mlflow.start_run() as mlflow_run:
  logged_model = mlflow.langchain.log_model(
    retrieval_qa,
    "retrieval_qa_chain",
    loader_fn=load_retriever,
    persist_dir=persist_directory,
  )

# COMMAND ----------

# MAGIC %md ### Loading the chain using MLFlow

# COMMAND ----------

model_uri = f"runs:/{ mlflow_run.info.run_id }/retrieval_qa_chain"

loaded_pyfunc_model = mlflow.pyfunc.load_model(model_uri)
langchain_input = {"query": "O que é pyspark?"}
loaded_pyfunc_model.predict([langchain_input])

# COMMAND ----------

import os
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI

# Certifique-se de que a chave da API da OpenAI está setada corretamente no ambiente
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# Inicializa o modelo da OpenAI com um modelo atualizado, por exemplo, "gpt-3.5-turbo"
llm = OpenAI(api_key=OPENAI_API_KEY, model="gpt-3.5-turbo-0125")

# Aqui, você deve garantir que 'llm' seja passado corretamente para 'RetrievalQA'
retrieval_qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())

query = "O que é Pyspark?"
result = retrieval_qa({"query": query})
print("Result:", result["result"])


# COMMAND ----------

import openai
import os

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

# Utilize o endpoint 'create' com o parâmetro 'model' e outros parâmetros específicos para sua necessidade
response = openai.Completion.create(
    model="gpt-3.5-turbdiscord
    o",
    prompt="O que é Pyspark?",
    temperature=0.7,
    max_tokens=150,
    n=1,
    stop=None
)

print("Result:", response.choices[0].text.strip())


# COMMAND ----------

#%run ./role_gpt

# COMMAND ----------

# Comando para reiniciar o kernel Python no Databricks
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %pip install openai

# COMMAND ----------

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

# COMMAND ----------

OPENAI_API_KEY = os.environ.get("OwEYew7F4GrN3Oalu0VjT3BlbkFJnuLl939vmJKs3ZILytkV")
openai.api_key = OPENAI_API_KEY

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from pyspark.sql import SparkSession
import pandas as pd

# Substitua pelo método de autenticação adequado
import openai

# COMMAND ----------

from openai import OpenAI
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("SalvarPerguntasGPT").getOrCreate()

# Definindo o esquema conforme solicitado
pergunta_schema = StructType([
    StructField("id", StringType(), True),
    StructField("pergunta", StringType(), True),
    StructField("opcoes", ArrayType(StringType()), True),
    StructField("resposta_correta", StringType(), True)
])

# Inicialize o cliente da API OpenAI
client = OpenAI()

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from delta.tables import DeltaTable

response = client.chat.completions.create(
  model="gpt-3.5-turbo-0125",
  response_format={ "type": "json_object" },
  messages=[
      {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
      {"role": "system", "content": "use own data_pdf embedding."},
      {"role": "system", "content": "max 100 tokens."},
      {"role": "system", "content": "create a QA file with this structure, {\"id\": \"id value, like (1de, 2de, 3de)\", \"pergunta\": \"Alguma pergunta relacionada a pyspark e engenharia de dados\", \"opcoes\": [\"criar uma lista de pergunta se respostas e por fim a resposta correta, seguir proxima rule para melhor compreencao e espelho\"], \"resposta_correta\": \"A\"}"},
      {"role": "system", "content": "Exemplo: {\"id\": \"1de\", \"pergunta\": \"O que é um Data Lake?\", \"opcoes\": [\"A) Um tipo de banco de dados relacional\", \"B) Um sistema de armazenamento que permite guardar grandes volumes de dados brutos\", \"C) Uma ferramenta de visualização de dados\", \"D) Um modelo de processamento de dados\", \"E) Uma técnica de machine learning\"], \"resposta_correta\": \"B\"}"},
      {"role": "system", "content": "crie suas proprias perguntas com o esqueleto acima"},
      {"role": "system", "content": "crie no minimo quatro perguntas"}
  ]

)
print(response.choices[0].message.content)

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("SalvarPerguntasGPT").getOrCreate()

# Processando a resposta para ajustar ao schema
import json

# Supondo que a resposta esteja no formato esperado e possa ser convertida diretamente
# Isso pode precisar de ajustes baseados no formato exato da resposta
resposta_json = json.loads(response.choices[0].message.content)
df_perguntas = spark.createDataFrame([resposta_json], schema=pergunta_schema)

# Define o caminho onde a tabela será salva
path = "dbfs:/user/hive/warehouse/perguntas_gpt"

# Verifica se a tabela "perguntas_gpt" já existe
if DeltaTable.isDeltaTable(spark, path):
    # A tabela existe, então faz append
    df_perguntas.write.format("delta").mode("append").option("path", path).saveAsTable("perguntas_gpt")
else:
    # A tabela não existe, então cria a tabela
    df_perguntas.write.format("delta").mode("overwrite").option("path", path).saveAsTable("perguntas_gpt")



# COMMAND ----------

from pyspark.sql import SparkSession

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("LeituraPerguntasGPT").getOrCreate()

# Define o caminho da tabela Delta
path = "dbfs:/user/hive/warehouse/perguntas_gpt"

# Lendo a tabela Delta
df_perguntas_gpt = spark.read.format("delta").load(path)

# Alternativamente, se a tabela está registrada no catálogo do Spark, você pode usar:
# df_perguntas_gpt = spark.table("perguntas_gpt")

# Mostrando os dados da tabela
df_perguntas_gpt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Continuacao do codigo

# COMMAND ----------

def pretty_print_docs(pdf_docs):
    print(f"\n{'-' * 100}\n".join([f"Document {i+1}:\n\n" + d.page_content for i, d in enumerate(docs)]))

# COMMAND ----------

print (pdf_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Utilizando OpenAI

# COMMAND ----------

# MAGIC %md # Vector Search External Embedding Model (OpenAI) Example
# MAGIC
# MAGIC This notebook demonstrates usage of the Vector Search Python SDK, which provides a `VectorSearchClient` as a primary API for working with Vector Search.
# MAGIC
# MAGIC This notebook uses Databricks support of external models ([AWS](https://docs.databricks.com/en/generative-ai/external-models/index.html)|[Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/external-models/)) to access  an OpenAI embeddings model to generate embeddings.

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

vsc = VectorSearchClient(disable_notice=True)

# COMMAND ----------

import mlflow.deployments

# Obter o cliente de deploy do MLflow
mlflow_deploy_client = mlflow.deployments.get_deploy_client("databricks")

# Nome do endpoint a ser criado ou atualizado
embedding_model_endpoint_name = "new_embedding_model_endpoint"  # Nome atualizado conforme necessário

# Configuração do novo modelo recomendado
new_model_config = {
    "served_entities": [{
        "external_model": {
            "name": "gpt-3.5-turbo-instruct",  # Modelo recomendado como substituto
            "provider": "openai",
            "task": "llm/v1/embeddings",  # Supondo que esta tarefa ainda seja aplicável
            "openai_config": {
                "openai_api_key": OPENAI_API_KEY  # Substitua por seu escopo correto e nome da chave
            }
        }
    }]
}

# Criar ou atualizar o endpoint com a nova configuração do modelo
mlflow_deploy_client.create_endpoint(
    name=embedding_model_endpoint_name,
    config=new_model_config
)


# COMMAND ----------

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY