# Databricks notebook source
spark.sparkContext.setLogLevel("WARN")  # Options include ERROR, WARN, INFO, DEBUG

# COMMAND ----------



# COMMAND ----------

# MAGIC %run ./create_table

# COMMAND ----------

# MAGIC %run ./perguntas_nv_basico

# COMMAND ----------

# MAGIC %run ./perguntas_nv_medio

# COMMAND ----------

# MAGIC %run ./perguntas_nv_avancado

# COMMAND ----------

# MAGIC %run ./create_table_perguntas

# COMMAND ----------

# MAGIC %run ./qa_teste

# COMMAND ----------

# MAGIC %md
# MAGIC import random
# MAGIC
# MAGIC def buscar_funcionario_por_matricula(matricula):
# MAGIC     return funcionario_df.filter(funcionario_df.matricula == matricula).first()
# MAGIC
# MAGIC def realizar_pergunta(perguntas, assunto, total_perguntas, matricula):
# MAGIC     resultados = []
# MAGIC     for i, pergunta_selecionada in enumerate(random.sample(perguntas, total_perguntas), start=1):
# MAGIC         print(f"{assunto} - Pergunta {i} de {total_perguntas}")
# MAGIC         print(pergunta_selecionada['pergunta'])
# MAGIC         for opcao in pergunta_selecionada['opcoes']:
# MAGIC             print(opcao)
# MAGIC         while True:
# MAGIC             resposta = input("Escolha a opção: ").upper()
# MAGIC             if resposta in ['A', 'B', 'C', 'D', 'E']:
# MAGIC                 resultado = 1 if resposta == pergunta_selecionada['resposta_correta'] else 2
# MAGIC                 resultados.append((matricula, pergunta_selecionada['id'], resultado))
# MAGIC                 break
# MAGIC             else:
# MAGIC                 print("Resposta não existe, selecione A, B, C, D ou E.")
# MAGIC     return resultados
# MAGIC
# MAGIC
# MAGIC # Exemplo de matrículas para cada nível
# MAGIC print("Exemplos de matrícula:")
# MAGIC for nivel in ['basico', 'medio', 'avancado']:
# MAGIC     exemplo = funcionario_df.filter(funcionario_df.nivel == nivel).first()
# MAGIC     if exemplo:
# MAGIC         print(f"Matrícula: {exemplo['matricula']} - Nível: {nivel}")
# MAGIC
# MAGIC # Solicitar a matrícula do usuário
# MAGIC matricula_input = input("Insira sua matricula: ")
# MAGIC funcionario = buscar_funcionario_por_matricula(matricula_input)
# MAGIC
# MAGIC # Combinar todas as perguntas de nível básico
# MAGIC #todas_perguntas_basico = perguntas_data_engineer_basico + perguntas_machine_learning_basico + perguntas_maestro_basico + perguntas_controlm_basico + perguntas_azure_basico
# MAGIC #todas_perguntas_intermediario =
# MAGIC #todas_perguntas_avancado = 
# MAGIC if funcionario:
# MAGIC     print(f"Bem-vindo {funcionario['Nome']}, seu nível é {funcionario['nivel']}")
# MAGIC     nivel = funcionario['nivel']
# MAGIC     if nivel == 'basico':
# MAGIC         resultados = realizar_pergunta(todas_perguntas_basico, 'Data Engineering Básico', 5, matricula_input)
# MAGIC     elif nivel == 'medio':
# MAGIC         resultados = realizar_pergunta(perguntas_data_engineer_intermediario, 'Data Engineering Intermediário', 5, matricula_input)
# MAGIC     elif nivel == 'avancado':
# MAGIC         resultados = realizar_pergunta(todas_perguntas_avancado, 'Data Engineering Avançado', 5, matricula_input)
# MAGIC     else:
# MAGIC         print("Nível desconhecido.")
# MAGIC         resultados = []
# MAGIC
# MAGIC     # Convertendo os resultados em um DataFrame e mostrando
# MAGIC     if resultados:
# MAGIC         resultados_df = spark.createDataFrame(resultados, ["Matricula", "ID_Pergunta", "Resultado"])
# MAGIC         print("Resultados, n1 = correto, n2 = errado")
# MAGIC         resultados_df.show()
# MAGIC else:
# MAGIC     print("Matrícula não encontrada, tente novamente")
# MAGIC

# COMMAND ----------

funcionario_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Salvando os resultados no DBFS correspondente.

# COMMAND ----------

resultados_df.write.format("parquet").insertInto("resultados")
#criar uma sigla de database e salvar ele como um resultado ex pe_resultados. 

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, sum, length, expr,lit, regexp_extract, concat,format_number

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CalculoNotas").enableHiveSupport().getOrCreate()

# Ler a tabela resultados em um DataFrame
df_resultados = spark.table("resultados")

# Função para traduzir o ID da pergunta para a categoria correspondente
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}

# Criar uma coluna com a categoria traduzida
df_traduzido = df_resultados.withColumn("categoria", 
    expr("""
        CASE 
            WHEN substring(ID_Pergunta, -2) = 'az' THEN 'azure'
            WHEN substring(ID_Pergunta, -2) = 'ms' THEN 'maestro'
            WHEN substring(ID_Pergunta, -2) = 'ml' THEN 'machine_learning'
            WHEN substring(ID_Pergunta, -2) = 'cm' THEN 'control_m'
            WHEN substring(ID_Pergunta, -2) = 'de' THEN 'data_engineer'
        END
    """))

# Substituindo valores de Resultado por 'correto' e 'errado'
df_traduzido = df_traduzido.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Agrupar por matrícula e categoria, e contar 'correto' e 'errado'
df_agrupado = df_traduzido.groupBy("matricula", "categoria").pivot("Resultado").count()

# Calcular a porcentagem de acertos
df_notas = df_agrupado.withColumn("nota", 
                                  concat(format_number((col("correto") / (col("correto") + col("errado"))) * 100, 2), lit('%')))

# Ajuste conforme necessário para incluir as colunas 'corretas' e 'erradas'
# E renomear colunas de nota para seguir o formato desejado

# Exibir o DataFrame para verificar o resultado
df_notas.show()


# COMMAND ----------

# MAGIC %run ./create_dataframe_df_resultados

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col, lit, regexp_extract

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("TransformacaoDFCompleta").getOrCreate()

# Carregar o DataFrame de resultados
# Suponha que df_resultados já esteja carregado com as colunas 'matricula', 'ID_Pergunta', e 'Resultado'

# Extrair a categoria de cada ID_Pergunta
df_categoria = df_resultados.withColumn("categoria", regexp_extract("ID_Pergunta", r"(\D+)$", 1))

# Traduzir abreviações para nomes completos
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}
for abrev, nome in traducao_categoria.items():
    df_categoria = df_categoria.withColumn("categoria", 
                                           when(col("categoria") == abrev, nome).otherwise(col("categoria")))

# Converter Resultado para correto/errado
df_categoria = df_categoria.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Pivotar para transformar categorias em colunas e contar 'correto' e 'errado'
df_pivotado = df_categoria.groupBy("matricula").pivot("categoria").agg(
    sum(when(col("Resultado") == "correto", 1)).alias("corretas"),
    sum(when(col("Resultado") == "errado", 1)).alias("erradas")
).na.fill(0)

# Lista de categorias para iterar
categorias = list(traducao_categoria.values())

# Calcular a nota para cada categoria
for categoria in categorias:
    df_pivotado = df_pivotado.withColumn(f"nota_{categoria}", 
                                          (col(f"{categoria}_corretas") / 
                                           (col(f"{categoria}_corretas") + col(f"{categoria}_erradas"))) * 100)

# Selecionar e renomear colunas conforme necessário
colunas_selecionadas = ["matricula"] + \
                       [f"{categoria}_corretas" for categoria in categorias] + \
                       [f"{categoria}_erradas" for categoria in categorias] + \
                       [f"nota_{categoria}" for categoria in categorias]

df_final = df_pivotado.select(*colunas_selecionadas)

# Exibir o DataFrame final para verificação
df_final.show(truncate=False)

# Encerrar a sessão Spark, se necessário
# spark.stop()


# COMMAND ----------

# MAGIC %md
# MAGIC ./create_df_nota_final

# COMMAND ----------

from pyspark.sql import SparkSession

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("YourAppName").getOrCreate()

# Lista com os DataFrames e os nomes das tabelas correspondentes
dfs_e_tabelas = [
    (df_notas, "df_notas"),
    (df_final, "df_final")
]

for df, tabela in dfs_e_tabelas:
    # Verifica se a tabela existe
    if spark._jsparkSession.catalog().tableExists(tabela):
        # Se a tabela existir, faça o insert into
        df.write.mode("append").format("parquet").insertInto(tabela)
    else:
        # Verifica se o diretório associado à tabela existe
        path = f"dbfs:/user/hive/warehouse/{tabela}"
        if dbutils.fs.ls(path):
            # Se o diretório existir, remove o diretório
            dbutils.fs.rm(path, recurse=True)
        # Cria a tabela com os dados do DataFrame após remover o diretório existente
        df.write.mode("overwrite").format("parquet").saveAsTable(tabela)

# COMMAND ----------

# Lista com os nomes das tabelas para ler
nomes_tabelas = ["df_notas", "df_final"]

for nome_tabela in nomes_tabelas:
    # Ler a tabela para um DataFrame
    df = spark.table(nome_tabela)
    
    # Exibir os primeiros registros do DataFrame para verificar
    print(f"Conteúdo da tabela {nome_tabela}:")
    df.display()

# COMMAND ----------

df_notas.printSchema()

# COMMAND ----------

# MAGIC %run ./create_ts_tb_funcionarios_nota

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import LongType

# Passo 1: Identificar matrículas presentes em ambos os DataFrames
matriculas_comuns = df_notas.select("matricula").intersect(funcionario_df.select("matricula"))

# Passo 2: Filtrar df_notas e calcular a nova nota
df_notas_filtrado = df_notas.join(matriculas_comuns, "matricula", "inner")\
    .withColumn("errado", F.coalesce("errado", F.lit(0)))\
    .withColumn("nova_nota", F.col("correto") - F.col("errado"))

# Agregar as notas por matrícula
df_agregado = df_notas_filtrado.groupBy("matricula")\
    .agg(F.sum("nova_nota").alias("soma_nova_nota"))

# Passo 3: Preparar funcionario_df e atualizar a nota média
funcionario_df = funcionario_df.withColumn("nota_media_long", F.col("nota_media").cast(LongType()))

# Juntar os DataFrames para atualizar a nota média
funcionario_atualizado = funcionario_df.join(df_agregado, "matricula", "left_outer")\
    .withColumn("nota_media_atualizada", 
                F.when(F.col("soma_nova_nota").isNull(), F.col("nota_media_long"))
                 .otherwise((F.col("nota_media_long") + F.col("soma_nova_nota")) / 2))\
    .drop("nota_media", "nota_media_long", "soma_nova_nota")\
    .withColumnRenamed("nota_media_atualizada", "nota_media")

# Passo 4: Salvar como tabela
funcionario_atualizado.write.mode("overwrite").saveAsTable("ts_tb_funcionarios_nota")


# COMMAND ----------

# MAGIC %md
# MAGIC from pyspark.sql import functions as F
# MAGIC from pyspark.sql.types import StringType, LongType
# MAGIC
# MAGIC # Assumindo que spark seja sua SparkSession já iniciada
# MAGIC
# MAGIC def identificar_matriculas_comuns(df_notas, funcionario_df):
# MAGIC     return df_notas.select("matricula").distinct().intersect(funcionario_df.select("matricula").distinct())
# MAGIC
# MAGIC def filtrar_calcular_nova_nota(df_notas, matriculas_comuns):
# MAGIC     return df_notas.join(matriculas_comuns, "matricula")\
# MAGIC         .withColumn("errado", F.coalesce("errado", F.lit(0)))\
# MAGIC         .withColumn("nova_nota", F.col("correto") - F.col("errado"))\
# MAGIC         .groupBy("matricula")\
# MAGIC         .agg(F.avg("nova_nota").alias("media_nova_nota"))
# MAGIC
# MAGIC def atualizar_nota_media(funcionario_df, df_agregado):
# MAGIC     funcionario_df = funcionario_df.withColumn("nota_media", funcionario_df["nota_media"].cast(LongType()))
# MAGIC     return funcionario_df.join(df_agregado, "matricula", "left_outer")\
# MAGIC         .withColumn("nota_media_atualizada",
# MAGIC                     F.when(F.col("media_nova_nota").isNull(), F.col("nota_media"))
# MAGIC                      .otherwise((F.col("nota_media") + F.col("media_nova_nota")) / 2))\
# MAGIC         .drop("nota_media")\
# MAGIC         .withColumnRenamed("nota_media_atualizada", "nota_media")
# MAGIC
# MAGIC def salvar_como_tabela(funcionario_atualizado, tabela):
# MAGIC     funcionario_atualizado.write.mode("overwrite").saveAsTable(tabela)
# MAGIC
# MAGIC def processar_atualizar_notas(df_notas, funcionario_df):
# MAGIC     matriculas_comuns = identificar_matriculas_comuns(df_notas, funcionario_df)
# MAGIC     df_agregado = filtrar_calcular_nova_nota(df_notas, matriculas_comuns)
# MAGIC     funcionario_atualizado = atualizar_nota_media(funcionario_df, df_agregado)
# MAGIC     salvar_como_tabela(funcionario_atualizado, "ts_tb_funcionarios_nota")
# MAGIC

# COMMAND ----------

# Certifique-se de que df_notas e funcionario_df estejam definidos e carregados corretamente
processar_atualizar_notas(df_notas, funcionario_df)

# COMMAND ----------

print ("df_notas")
df_notas.printSchema()
print ("funcionario_df")
funcionario_df.printSchema()

funcionario_atualizado.show()


# COMMAND ----------

df_tb_funcionarios_nota = spark.table("ts_tb_funcionarios_nota")

# COMMAND ----------

# MAGIC %md
# MAGIC criando dataframe por siglas.

# COMMAND ----------

# MAGIC %run ./create_df_siglas

# COMMAND ----------

# MAGIC %md
# MAGIC Ativando funções criar dataframe siglas.

# COMMAND ----------

processar_salvar_dfs(df_tb_funcionarios_nota)

# COMMAND ----------

# Filtrar o DataFrame para cada uma das siglas específicas
df_ror = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'ROR')
df_bma = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'BMA')
df_coe = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'COE')

# Agora você tem três DataFrames: df_ror, df_bma, df_coe
# Salvar o DataFrame df_ror como uma tabela chamada tb_sigla_ror
df_ror.write.mode("overwrite").saveAsTable("tb_sigla_ror")

# Salvar o DataFrame df_bma como uma tabela chamada tb_sigla_bma
df_bma.write.mode("overwrite").saveAsTable("tb_sigla_bma")

# Salvar o DataFrame df_coe como uma tabela chamada tb_sigla_coe
df_coe.write.mode("overwrite").saveAsTable("tb_sigla_coe")


# COMMAND ----------

lider_df.printSchema()

# COMMAND ----------

# MAGIC %run ./analises_e_graficos

# COMMAND ----------

from pyspark.sql import SparkSession

# Supõe-se que a sessão Spark já tenha sido iniciada anteriormente como 'spark'
# spark = SparkSession.builder.appName("AppName").getOrCreate()

# Nome da tabela
nome_tabela = "tb_funcionarios"

# Verifica se a tabela existe
if not spark._jsparkSession.catalog().tableExists(nome_tabela):
    # Se a tabela não existir, cria a tabela a partir do DataFrame 'funcionario_df'
    funcionario_df.write.mode("overwrite").saveAsTable(nome_tabela)
    print(f"A tabela {nome_tabela} foi criada com sucesso.")
else:
    # Caso a tabela já exista, uma mensagem é exibida
    print(f"A tabela {nome_tabela} já existe.")


# COMMAND ----------

# MAGIC %run ./data_masking

# COMMAND ----------

# Assuming you've already set up your SparkSession as 'spark'

# Define the path to the data
path = 'dbfs:/user/hive/warehouse/tb_funcionarios_mask'

# Read data from the specified path
df = spark.read.format("delta").load(path)

# Display the DataFrame schema
df.printSchema()

# Show some rows of the DataFrame
df.show()


# COMMAND ----------

# MAGIC %run ./lider_view

# COMMAND ----------

df = spark.table("tb_sigla_bma")
df_ror.display()

# COMMAND ----------

