# Databricks notebook source
perguntas_data_engineer_basico  = [
    {"id": "1de", "pergunta": "O que é um Data Lake?", "opcoes": ["A) Um tipo de banco de dados relacional", "B) Um sistema de armazenamento que permite guardar grandes volumes de dados brutos", "C) Uma ferramenta de visualização de dados", "D) Um modelo de processamento de dados", "E) Uma técnica de machine learning"], "resposta_correta": "B"},
    {"id": "2de", "pergunta": "Qual destas é uma prática comum em engenharia de dados?", "opcoes": ["A) Normalização de dados", "B) Deep Learning", "C) Design de interfaces de usuário", "D) Desenvolvimento de jogos", "E) Testes de software"], "resposta_correta": "A"},
    {"id": "3de", "pergunta": "Qual ferramenta é frequentemente usada para processamento de dados em larga escala?", "opcoes": ["A) Excel", "B) Oracle Database", "C) Hadoop", "D) Photoshop", "E) Microsoft Word"], "resposta_correta": "C"},
    {"id": "4de", "pergunta": "O que é ETL?", "opcoes": ["A) External Tool Language", "B) Extract, Transform, Load", "C) Enter, Transfer, Link", "D) Evaluate, Test, Launch", "E) Encode, Transmit, Load"], "resposta_correta": "B"},
    {"id": "5de", "pergunta": "Qual linguagem de programação é amplamente usada na engenharia de dados?", "opcoes": ["A) JavaScript", "B) Python", "C) C#", "D) Ruby", "E) Swift"], "resposta_correta": "B"},
    {"id": "6de", "pergunta": "Qual é o propósito de um Data Warehouse?", "opcoes": ["A) Armazenar dados de forma desorganizada", "B) Armazenar dados de forma organizada para análise", "C) Executar aplicativos de front-end", "D) Gerenciar transações de clientes", "E) Controlar dispositivos IoT"], "resposta_correta": "B"},
    {"id": "7de", "pergunta": "O que são pipelines de dados?", "opcoes": ["A) Ferramentas para desenvolvimento de software", "B) Conjuntos de passos para mover e transformar dados", "C) Técnicas para design de banco de dados", "D) Métodos para testar aplicativos", "E) Práticas para segurança de rede"], "resposta_correta": "B"},
    {"id": "8de", "pergunta": "Big Data é caracterizado por:", "opcoes": ["A) Volume, Variedade e Velocidade", "B) Volume, Veracidade e Valor", "C) Velocidade, Veracidade e Variedade", "D) Volume, Velocidade e Vulnerabilidade", "E) Variedade, Velocidade e Valor"], "resposta_correta": "A"},
    {"id": "9de", "pergunta": "Qual destas é uma ferramenta usada para orquestração de workflows em engenharia de dados?", "opcoes": ["A) Jenkins", "B) Apache Airflow", "C) Selenium", "D) TensorFlow", "E) Kubernetes"], "resposta_correta": "B"},
    {"id": "10de", "pergunta": "Stream processing é usado principalmente para:", "opcoes": ["A) Armazenamento de dados", "B) Processamento de dados em tempo real", "C) Análise de dados históricos", "D) Visualização de dados", "E) Limpeza de dados"], "resposta_correta": "B"}
]


# COMMAND ----------

perguntas_machine_learning_basico = [
    {"id": "1ml", "pergunta": "O que é aprendizado supervisionado?", "opcoes": ["A) Aprendizado com a presença de um instrutor", "B) Aprendizado com dados não rotulados", "C) Aprendizado com dados rotulados", "D) Aprendizado sem a intervenção de humanos", "E) Aprendizado baseado em reforço"], "resposta_correta": "C"},
    {"id": "2ml", "pergunta": "Qual destes é um exemplo de algoritmo de classificação?", "opcoes": ["A) Regressão linear", "B) K-means", "C) Árvore de decisão", "D) Análise de componentes principais", "E) Algoritmo genético"], "resposta_correta": "C"},
    {"id": "3ml", "pergunta": "O que é 'overfitting' em machine learning?", "opcoes": ["A) Modelo que não se ajusta bem aos dados", "B) Modelo que se ajusta excessivamente aos dados de treino", "C) Modelo que utiliza muitos dados", "D) Modelo que é muito simples", "E) Modelo que é treinado por muito tempo"], "resposta_correta": "B"},
    {"id": "4ml", "pergunta": "Em machine learning, o que é um 'feature'?", "opcoes": ["A) Um erro no modelo", "B) Uma variável de entrada", "C) O resultado do modelo", "D) Uma técnica de otimização", "E) Um tipo de algoritmo"], "resposta_correta": "B"},
    {"id": "5ml", "pergunta": "Qual técnica é usada para reduzir a dimensionalidade dos dados?", "opcoes": ["A) Normalização", "B) Aumento de dados", "C) Análise de componentes principais (PCA)", "D) Regularização", "E) Boosting"], "resposta_correta": "C"},
    {"id": "6ml", "pergunta": "O que é um 'neural network'?", "opcoes": ["A) Um tipo de banco de dados", "B) Uma estrutura de dados", "C) Um modelo de machine learning baseado em como os neurônios humanos trabalham", "D) Um algoritmo de ordenação", "E) Uma técnica de criptografia"], "resposta_correta": "C"},
    {"id": "7ml", "pergunta": "Qual destes é um uso comum de machine learning?", "opcoes": ["A) Desenvolvimento web", "B) Reconhecimento de voz", "C) Gerenciamento de projetos", "D) Cálculos matemáticos complexos", "E) Redação de código-fonte"], "resposta_correta": "B"},
    {"id": "8ml", "pergunta": "O que é 'deep learning'?", "opcoes": ["A) Aprendizado com uma grande quantidade de dados", "B) Aprendizado com muitas camadas em redes neurais", "C) Aprendizado com uma complexa árvore de decisão", "D) Aprendizado com algoritmos genéticos", "E) Aprendizado com reforço"], "resposta_correta": "B"},
    {"id": "9ml", "pergunta": "Qual destes é um desafio comum no machine learning?", "opcoes": ["A) Escrita de código-fonte", "B) Design de interfaces de usuário", "C) Lidar com dados desbalanceados", "D) Configuração de hardware", "E) Marketing digital"], "resposta_correta": "C"},
    {"id": "10ml", "pergunta": "Em machine learning, o que é um modelo?", "opcoes": ["A) Uma representação de dados", "B) Uma técnica de visualização", "C) Uma simulação de um processo ou sistema", "D) Um algoritmo para processamento de dados", "E) Uma ferramenta de desenvolvimento de software"], "resposta_correta": "C"}
]


# COMMAND ----------

perguntas_maestro_basico = [
    {"id": "1ms", "pergunta": "O que é Maestro no contexto de TI?", "opcoes": ["A) Uma linguagem de programação", "B) Um software de automação de processos", "C) Um serviço de nuvem", "D) Um sistema operacional", "E) Uma ferramenta de análise de dados"], "resposta_correta": "B"},
    {"id": "2ms", "pergunta": "Maestro é mais conhecido por:", "opcoes": ["A) Armazenamento de dados em nuvem", "B) Automação e gerenciamento de workflows", "C) Desenvolvimento de aplicações móveis", "D) Análises estatísticas", "E) Segurança de rede"], "resposta_correta": "B"},
    {"id": "3ms", "pergunta": "Uma vantagem do uso do Maestro é:", "opcoes": ["A) Melhoria na experiência do usuário", "B) Redução de custos operacionais", "C) Suporte para desenvolvimento ágil", "D) Análise avançada de dados", "E) Forte segurança de rede"], "resposta_correta": "B"},
    {"id": "4ms", "pergunta": "Maestro é usado para:", "opcoes": ["A) Gerenciamento de identidades", "B) Virtualização de infraestrutura", "C) Automação de tarefas de TI", "D) Hospedagem de websites", "E) Desenvolvimento de jogos"], "resposta_correta": "C"},
    # Completo com mais 6 perguntas...
]


# COMMAND ----------

# MAGIC %md
# MAGIC perguntas_aws_basico = [
# MAGIC     {"id": 1, "pergunta": "O que é a AWS?", "opcoes": ["A) Uma linguagem de programação", "B) Um serviço de computação em nuvem da Amazon", "C) Um sistema de gerenciamento de banco de dados", "D) Um framework de desenvolvimento", "E) Uma plataforma de e-commerce"], "resposta_correta": "B"},
# MAGIC     {"id": 2, "pergunta": "Qual serviço AWS é usado para computação sem servidor?", "opcoes": ["A) AWS Lambda", "B) Amazon EC2", "C) AWS Elastic Beanstalk", "D) Amazon S3", "E) Amazon RDS"], "resposta_correta": "A"},
# MAGIC     {"id": 3, "pergunta": "Amazon S3 é usado para:", "opcoes": ["A) Computação em nuvem", "B) Banco de dados NoSQL", "C) Armazenamento de objetos", "D) Machine Learning", "E) Hospedagem de aplicações web"], "resposta_correta": "C"},
# MAGIC     {"id": 4, "pergunta": "Qual é o serviço de banco de dados relacional da AWS?", "opcoes": ["A) Amazon DynamoDB", "B) Amazon Redshift", "C) AWS Glue", "D) Amazon RDS", "E) AWS Lambda"], "resposta_correta": "D"},
# MAGIC     # Completo com mais 6 perguntas...
# MAGIC ]
# MAGIC

# COMMAND ----------

perguntas_controlm_basico = [
    {"id": "1cm", "pergunta": "O que é Control-M?", "opcoes": ["A) Uma linguagem de programação", "B) Um sistema operacional", "C) Um software de automação de trabalho", "D) Um serviço de nuvem", "E) Uma ferramenta de análise de dados"], "resposta_correta": "C"},
    {"id": "2cm", "pergunta": "Control-M é utilizado principalmente para:", "opcoes": ["A) Desenvolvimento de software", "B) Gerenciamento de banco de dados", "C) Automação de processos de negócios", "D) Análise de grandes volumes de dados", "E) Segurança de rede"], "resposta_correta": "C"},
    {"id": "3cm", "pergunta": "Qual característica é um benefício do Control-M?", "opcoes": ["A) Redução de custos com infraestrutura", "B) Melhoria na segurança de dados", "C) Suporte a múltiplos sistemas operacionais", "D) Agilidade no desenvolvimento de software", "E) Integração com sistemas legados"], "resposta_correta": "A"},
    {"id": "4cm", "pergunta": "Control-M permite:", "opcoes": ["A) Gestão de identidades", "B) Monitoramento em tempo real de fluxos de trabalho", "C) Virtualização de máquinas", "D) Análise preditiva", "E) Desenvolvimento de aplicações móveis"], "resposta_correta": "B"},
    {"id": "5cm", "pergunta": "Em que Control-M é diferenciado de outras ferramentas de automação?", "opcoes": ["A) Em sua capacidade de processamento de dados", "B) Na sua interface de usuário intuitiva", "C) Em sua habilidade de integração com diversas plataformas", "D) No seu foco em segurança cibernética", "E) Na sua capacidade de automação de marketing"], "resposta_correta": "C"},
    {"id": "6cm", "pergunta": "Como Control-M facilita a gestão de workflows?", "opcoes": ["A) Através de uma linguagem de programação simplificada", "B) Utilizando inteligência artificial", "C) Por meio de uma interface gráfica de usuário", "D) Implementando algoritmos de aprendizado de máquina", "E) Por meio de plugins para navegadores web"], "resposta_correta": "C"},
    {"id": "7cm", "pergunta": "Control-M pode ser integrado com quais tipos de sistemas?", "opcoes": ["A) Somente sistemas baseados em Windows", "B) Exclusivamente com sistemas de cloud", "C) Apenas sistemas Unix/Linux", "D) Uma ampla variedade de sistemas e aplicações", "E) Somente com sistemas desenvolvidos pela BMC"], "resposta_correta": "D"},
    {"id": "8cm", "pergunta": "Qual é a principal função do Control-M?", "opcoes": ["A) Gerenciamento de banco de dados", "B) Automação de processos de negócios", "C) Desenvolvimento de software", "D) Análises de Big Data", "E) Segurança de infraestrutura de TI"], "resposta_correta": "B"},
    {"id": "9cm", "pergunta": "Control-M oferece suporte a que tipo de processamento?", "opcoes": ["A) Processamento em lote", "B) Processamento em tempo real", "C) Ambos, processamento em lote e em tempo real", "D) Processamento distribuído", "E) Processamento gráfico"], "resposta_correta": "C"},
    {"id": "10cm", "pergunta": "Qual é o foco principal do Control-M em uma organização?", "opcoes": ["A) Análise de dados", "B) Comunicações internas", "C) Automação de processos de TI", "D) Gestão de projetos", "E) Marketing digital"], "resposta_correta": "C"}
]


# COMMAND ----------

# Banco de dados de perguntas para Azure
perguntas_azure_basico = [
    {"id": "1az", "pergunta": "O que é Azure?", "opcoes": ["A) Um serviço de computação em nuvem da Microsoft", "B) Um sistema operacional", "C) Um banco de dados", "D) Uma linguagem de programação", "E) Um dispositivo móvel"], "resposta_correta": "A"},
    {"id": "2az", "pergunta": "Qual serviço Azure permite o gerenciamento de máquinas virtuais?", "opcoes": ["A) Azure Functions", "B) Azure DevOps", "C) Azure Virtual Machines", "D) Azure Cosmos DB", "E) Azure Kubernetes Service"], "resposta_correta": "C"},
    {"id": "3az", "pergunta": "Que serviço Azure é usado para hospedar bancos de dados SQL?", "opcoes": ["A) Azure Blobs", "B) Azure SQL Database", "C) Azure DevOps", "D) Azure Table Storage", "E) Azure Active Directory"], "resposta_correta": "B"},
    {"id": "4az", "pergunta": "O Azure Active Directory é usado para:", "opcoes": ["A) Hospedagem de aplicações", "B) Análise de dados", "C) Gerenciamento de identidades", "D) Armazenamento de objetos", "E) Orquestração de contêineres"], "resposta_correta": "C"},
    {"id": "5az", "pergunta": "Qual ferramenta Azure oferece serviços de análise em tempo real?", "opcoes": ["A) Azure SQL Data Warehouse", "B) Azure Logic Apps", "C) Azure Data Lake Analytics", "D) Azure Stream Analytics", "E) Azure Machine Learning"], "resposta_correta": "D"},
    {"id": "6az", "pergunta": "Qual serviço Azure é melhor para a implementação de pipelines de CI/CD?", "opcoes": ["A) Azure Repos", "B) Azure Boards", "C) Azure Pipelines", "D) Azure Monitor", "E) Azure Security Center"], "resposta_correta": "C"},
    {"id": "7az", "pergunta": "Azure Cosmos DB é conhecido por ser:", "opcoes": ["A) Um serviço de banco de dados SQL", "B) Uma plataforma de aprendizado de máquina", "C) Um serviço de banco de dados NoSQL", "D) Um serviço de análise de dados", "E) Um serviço de gerenciamento de API"], "resposta_correta": "C"},
    {"id": "8az", "pergunta": "Qual serviço do Azure é usado para automação de processos?", "opcoes": ["A) Azure Automation", "B) Azure Functions", "C) Azure Logic Apps", "D) Azure Machine Learning", "E) Azure Virtual Network"], "resposta_correta": "A"},
    {"id": "9az", "pergunta": "Azure Virtual Network é usado para:", "opcoes": ["A) Hospedar aplicativos web", "B) Armazenar dados não estruturados", "C) Criar redes privadas na nuvem", "D) Gerenciar bancos de dados", "E) Monitorar aplicativos"], "resposta_correta": "C"},
    {"id": "10az", "pergunta": "Para que é usado o Azure Blob Storage?", "opcoes": ["A) Armazenamento de dados estruturados", "B) Hospedagem de sites estáticos", "C) Backup e recuperação de desastres", "D) Todos os anteriores", "E) Nenhuma das anteriores"], "resposta_correta": "D"}
]