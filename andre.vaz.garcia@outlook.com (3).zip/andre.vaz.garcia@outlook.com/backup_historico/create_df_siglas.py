# Databricks notebook source
# MAGIC %md
# MAGIC Filtragem por Sigla

# COMMAND ----------

# MAGIC %md
# MAGIC Salvar o DataFrame como Tabela

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("TransformacaoNotaMedia").getOrCreate()

# Transformando 'nota_media' de double para long
df_tb_funcionarios_nota = df_tb_funcionarios_nota.withColumn("nota_media", col("nota_media").cast("long"))


# COMMAND ----------

# Filtrar o DataFrame para cada uma das siglas específicas
df_ror = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'ROR')
df_bma = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'BMA')
df_coe = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == 'COE')

# Salvar o DataFrame df_ror como uma tabela chamada tb_sigla_ror
df_ror.write.mode("overwrite").saveAsTable("tb_sigla_ror")

# Salvar o DataFrame df_bma como uma tabela chamada tb_sigla_bma
df_bma.write.mode("overwrite").saveAsTable("tb_sigla_bma")

# Salvar o DataFrame df_coe como uma tabela chamada tb_sigla_coe
df_coe.write.mode("overwrite").saveAsTable("tb_sigla_coe")