# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg, sum

# Supondo que seu DataFrame já esteja criado e nomeado como funcionario_df

# Agrupamento por domínio para cálculo da média de notas
nota_media_por_dominio = funcionario_df.groupBy("dominio").agg(avg("nota_media").alias("nota_media"))

# Agrupamento por domínio para cálculo da soma de faltas
faltas_por_dominio = funcionario_df.groupBy("dominio").agg(sum("faltas").alias("faltas"))

# Exibindo os resultados para visualização no Databricks
nota_media_por_dominio.display()
faltas_por_dominio.display()


# COMMAND ----------

# Convertendo DataFrames do PySpark para pandas DataFrames
nota_media_por_dominio_pd = nota_media_por_dominio.toPandas()
faltas_por_dominio_pd = faltas_por_dominio.toPandas()

# Agora, usando matplotlib para criar os gráficos
import matplotlib.pyplot as plt

# Configurando o plot
fig, ax1 = plt.subplots(figsize=(10, 6))

# Gráfico de barras para nota média
color = 'tab:blue'
ax1.set_xlabel('Domínio')
ax1.set_ylabel('Nota Média', color=color)
ax1.bar(nota_media_por_dominio_pd['dominio'], nota_media_por_dominio_pd['nota_media'], color=color)
ax1.tick_params(axis='y', labelcolor=color)
ax1.tick_params(axis='x', rotation=45)

# Instanciando um segundo eixo para as faltas
ax2 = ax1.twinx()
color = 'tab:red'
ax2.set_ylabel('Faltas', color=color)
ax2.plot(faltas_por_dominio_pd['dominio'], faltas_por_dominio_pd['faltas'], color=color, marker='o', linestyle='None')
ax2.tick_params(axis='y', labelcolor=color)

# Título do gráfico
plt.title('Nota Média e Faltas por Domínio')

# Mostrando o gráfico
plt.tight_layout()
plt.show()


# COMMAND ----------

