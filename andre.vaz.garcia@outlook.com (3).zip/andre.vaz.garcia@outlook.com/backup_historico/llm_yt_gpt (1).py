# Databricks notebook source
# Comando para reiniciar o kernel Python no Databricks
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %pip install langchain
# MAGIC %pip install pypdf
# MAGIC %pip install yt_dlp
# MAGIC %pip install pydub
# MAGIC %pip install unstructured > /dev/null
# MAGIC %pip install chromadb
# MAGIC %pip install lark
# MAGIC %pip install openai
# MAGIC %pip install tiktoken
# MAGIC %pip install -U langchain-openai
# MAGIC %pip install pysqlite3-binary
# MAGIC %pip install PyPDF2
# MAGIC %pip install pymupdf

# COMMAND ----------

# MAGIC %md
# MAGIC # Atualiza a biblioteca typing_extensions
# MAGIC %pip install --upgrade typing_extensions
# MAGIC
# MAGIC # Instala ou atualiza o pacote openai
# MAGIC %pip install --upgrade openai

# COMMAND ----------

import getpass
import os

os.environ["OPENAI_API_KEY"] = getpass.getpass("OpenAI API Key:")

# COMMAND ----------

import os

import sys
# sys.path.append('../..')

from dotenv import load_dotenv
load_dotenv()
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.langchain.plus"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Youtube

# COMMAND ----------

from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import OpenAIWhisperParser
from langchain.document_loaders.blob_loaders.youtube_audio import YoutubeAudioLoader

# COMMAND ----------

# MAGIC %pip install openai

# COMMAND ----------

from langchain.document_loaders import WebBaseLoader

web_loader = WebBaseLoader("https://github.com/andkret/Cookbook/blob/master/sections/03-AdvancedSkills.md")
web_docs = web_loader.load()

# COMMAND ----------

# MAGIC %pip install openai
# MAGIC %pip install typing_extensions --upgrade

# COMMAND ----------

# MAGIC %pip install -U openai-whisper

# COMMAND ----------

from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import OpenAIWhisperParser
from langchain.document_loaders.blob_loaders.youtube_audio import YoutubeAudioLoader

# COMMAND ----------

import os
import openai
import sys

# COMMAND ----------

url="https://www.youtube.com/watch?v=wyGAYa2UMXQ&ab_channel=SeattleDataGuy"
save_dir="docs/youtube/"
yt_loader = GenericLoader(
    YoutubeAudioLoader([url],save_dir),
    OpenAIWhisperParser()
)
yt_docs = yt_loader.load()

# COMMAND ----------

print (yt_docs)

# COMMAND ----------

yt_save = yt_docs

# COMMAND ----------

# MAGIC %run ./Splitting_the_documents

# COMMAND ----------

# MAGIC %md
# MAGIC ## Splitting the documents

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

yt_docs = r_splitter.split_documents(yt_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Token

# COMMAND ----------

# MAGIC %md
# MAGIC install tiktoken

# COMMAND ----------

# Token text splitter
token_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=10)

# COMMAND ----------

yt_docs_split = token_splitter.split_documents(yt_docs)

# COMMAND ----------

yt_docs_rec = r_splitter.split_documents(yt_docs)

# COMMAND ----------

yt_docs = list(yt_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Embeddings

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

yt_docs = r_splitter.split_documents(yt_docs)

# COMMAND ----------

print (yt_docs)

# COMMAND ----------

# Caminho no DBFS onde os dados serão salvos
output_path = "dbfs:/user/hive/warehouse/yt_docs"

# Salvar o DataFrame como arquivos JSON no caminho especificado
yt_docs.write.mode("overwrite").format("json").save(output_path)