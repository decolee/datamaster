# Databricks notebook source
# MAGIC %md
# MAGIC ## Splitting the documents

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

pdf_docs = r_splitter.split_documents(pdf_pages)

# COMMAND ----------

