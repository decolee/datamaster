# Databricks notebook source
# MAGIC %pip install langchain
# MAGIC %pip install pypdf 
# MAGIC %pip install yt_dlp
# MAGIC %pip install pydub
# MAGIC %pip install unstructured > /dev/null
# MAGIC %pip install chromadb
# MAGIC %pip install lark
# MAGIC %pip install openai
# MAGIC %pip install tiktoken
# MAGIC %pip install -U langchain-openai
# MAGIC %pip install pysqlite3-binary
# MAGIC %pip install tiktoken
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 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

# COMMAND ----------

# MAGIC %md
# MAGIC os.environ['OPENAI_API_KEY']

# COMMAND ----------

import os
import openai
import sys
# sys.path.append('../..')

from dotenv import load_dotenv
load_dotenv()

openai.api_key  = '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'
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.langchain.plus"
os.environ["OPENAI_API_KEY"] = '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'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading documents

# COMMAND ----------

# MAGIC %md
# MAGIC ### PDFs

# COMMAND ----------

from langchain.document_loaders import PyPDFLoader

# Copy the file from DBFS to the local file system
dbutils.fs.cp("dbfs:/FileStore/pyspark.pdf", "file:/tmp/pyspark.pdf")

# Use the local file path for PyPDFLoader
pdf_loader = PyPDFLoader("/tmp/pyspark.pdf")
pdf_pages = pdf_loader.load()


# COMMAND ----------

# MAGIC %md
# MAGIC from langchain.document_loaders import PyPDFLoader
# MAGIC pdf_loader = PyPDFLoader("/dbfs/FileStore/pyspark.pdf")
# MAGIC pdf_pages = pdf_loader.load()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Youtube

# COMMAND ----------

from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import OpenAIWhisperParser
from langchain.document_loaders.blob_loaders.youtube_audio import YoutubeAudioLoader

# COMMAND ----------

url="https://www.youtube.com/watch?v=hNJCxF3IWC4"
save_dir="docs/youtube/"
yt_loader = GenericLoader(
    YoutubeAudioLoader([url],save_dir),
    OpenAIWhisperParser()
)
yt_docs = yt_loader.load()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Web

# COMMAND ----------

from langchain.document_loaders import WebBaseLoader

web_loader = WebBaseLoader("https://github.com/andkret/Cookbook/blob/master/sections/03-AdvancedSkills.md")
web_docs = web_loader.load()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Markdown loader

# COMMAND ----------

from langchain.document_loaders import UnstructuredMarkdownLoader

# COMMAND ----------

md_loader = UnstructuredMarkdownLoader("docs/markdown/03-AdvancedSkills.md")
md_docs = md_loader.load()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Splitting the documents

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

# MAGIC %md
# MAGIC ### Character text

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

pdf_docs = r_splitter.split_documents(pdf_pages)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Token

# COMMAND ----------

# MAGIC %md
# MAGIC install tiktoken

# COMMAND ----------

# Token text splitter
token_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=10)

# COMMAND ----------

yt_docs_split = token_splitter.split_documents(yt_docs)

# COMMAND ----------

yt_docs_rec = r_splitter.split_documents(yt_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Markdown

# COMMAND ----------

headers_to_split_on = [
    ("#", "Header 1"),
    ("##", "Header 2"),
    ("###", "Header 3"),
    ("###", "Header 4")
]
md_txt = ' '.join([d.page_content for d in md_docs])

# COMMAND ----------

markdown_splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=headers_to_split_on
)
md_header_splits = markdown_splitter.split_text(md_txt)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Embeddings

# COMMAND ----------

from langchain.embeddings.openai import OpenAIEmbeddings
embedding = OpenAIEmbeddings()

# COMMAND ----------

# folder that persisted vectors will be stored
from langchain.vectorstores import Chroma
persist_directory = 'docs/chroma/'

# COMMAND ----------

!rm -rf ./docs/chroma  # remove old database files if any

# COMMAND ----------

vectordb = Chroma.from_documents(
    documents=pdf_docs,
    embedding=embedding,
    persist_directory=persist_directory
)
# persisting vector to disk
vectordb.persist()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Vectorstore retrieval

# COMMAND ----------

# MAGIC %md
# MAGIC ### Similarity Search

# COMMAND ----------

def pretty_print_docs(docs):
    print(f"\n{'-' * 100}\n".join([f"Document {i+1}:\n\n" + d.page_content for i, d in enumerate(docs)]))

# COMMAND ----------

question = "What is pyspark"

# COMMAND ----------

docs = vectordb.similarity_search(question,k=3)
pretty_print_docs(docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Addressing Diversity: Maximum marginal relevance

# COMMAND ----------

docs_mmr = vectordb.max_marginal_relevance_search(question,k=3)
pretty_print_docs(docs)

# COMMAND ----------

docs = vectordb.similarity_search(
    question,
    k=3,
    filter={"source":"docs/pdfs/Fundamentals of Data Observability.pdf"}
)

# COMMAND ----------

pretty_print_docs(docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Addressing Specificity: working with metadata using self-query retriever

# COMMAND ----------

from langchain.llms import OpenAI
from langchain.retrievers.self_query.base import SelfQueryRetriever
from langchain.chains.query_constructor.base import AttributeInfo

# COMMAND ----------

metadata_field_info = [
    AttributeInfo(
        name="source",
        description="The pdf the chunk is from, should be one of `docs/pdfs/Fundamentals of Data Observability.pdf`",
        type="string",
    ),
    AttributeInfo(
        name="page",
        description="The page from the pdf",
        type="integer",
    ),
]

# COMMAND ----------

document_content_description = "Pyspark"
llm = OpenAI(temperature=0)

# COMMAND ----------

print(vectordb._collection.count())

# COMMAND ----------

retriever = SelfQueryRetriever.from_llm(
    llm,
    vectordb,
    document_content_description,
    metadata_field_info,
    verbose=True
)
question = "What is Data Observability"
docs = retriever.get_relevant_documents(question)

# COMMAND ----------

pretty_print_docs(docs)

# COMMAND ----------

from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor

# COMMAND ----------

# Wrap our vectorstore
llm = OpenAI(temperature=0)
compressor = LLMChainExtractor.from_llm(llm)

# COMMAND ----------

compression_retriever = ContextualCompressionRetriever(
    base_compressor=compressor,
    base_retriever=vectordb.as_retriever()
)

# COMMAND ----------

question = "What is Data Observability"
compressed_docs = compression_retriever.get_relevant_documents(question)
pretty_print_docs(compressed_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Questions answering

# COMMAND ----------

llm_name = "gpt-3.5-turbo-0301"
vectordb = Chroma(persist_directory=persist_directory, embedding_function=embedding)

# COMMAND ----------

from langchain.chat_models import ChatOpenAI
llm = ChatOpenAI(model_name=llm_name, temperature=0)

# COMMAND ----------

# MAGIC %md
# MAGIC ### RetrievalQA chain

# COMMAND ----------

from langchain.chains import RetrievalQA
qa_chain = RetrievalQA.from_chain_type(
    llm,
    retriever=vectordb.as_retriever()
)

# COMMAND ----------

question = "What is Data Observability"

# COMMAND ----------

result = qa_chain({"query": question})

# COMMAND ----------

result["result"]

# COMMAND ----------

qa_chain({"query": "What is the relation between data quality and data observability?"})["result"]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prompt

# COMMAND ----------

from langchain.prompts import PromptTemplate

# Build prompt
template = """Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer. Use three sentences maximum. Keep the answer as concise as possible. Always say "thanks for asking!" at the end of the answer. 
{context}
Question: {question}
Helpful Answer:"""
QA_CHAIN_PROMPT = PromptTemplate.from_template(template)


# COMMAND ----------

# Run chain
qa_chain = RetrievalQA.from_chain_type(
    llm,
    retriever=vectordb.as_retriever(),
    return_source_documents=True,
    chain_type_kwargs={"prompt": QA_CHAIN_PROMPT}
)

# COMMAND ----------

result = qa_chain({"query": question})
result["result"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Chat

# COMMAND ----------

# MAGIC %md
# MAGIC ### Memory

# COMMAND ----------

from langchain.memory import ConversationBufferMemory
memory = ConversationBufferMemory(
    memory_key="chat_history",
    return_messages=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### ConversationalRetrievalChain

# COMMAND ----------

from langchain.chains import ConversationalRetrievalChain
retriever=vectordb.as_retriever()
qa = ConversationalRetrievalChain.from_llm(
    llm,
    retriever=retriever,
    memory=memory
)

# COMMAND ----------

question = "What is the relation between data quality and data observability?"
result = qa({"question": question})
result['answer']

# COMMAND ----------

question = "Why is it a critical aspect of data observability?"
result = qa({"question": question})
result['answer']