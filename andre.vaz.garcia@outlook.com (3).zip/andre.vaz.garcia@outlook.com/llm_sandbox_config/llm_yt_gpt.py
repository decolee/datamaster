# Databricks notebook source
# MAGIC %md
# MAGIC Restart Python lib para funcionar a API da OpenAI

# COMMAND ----------

# Comando para reiniciar o kernel Python no Databricks
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC Installs necessários para o código:

# COMMAND ----------

# MAGIC %pip install langchain
# MAGIC %pip install pypdf
# MAGIC %pip install yt_dlp
# MAGIC %pip install pydub
# MAGIC %pip install unstructured > /dev/null
# MAGIC %pip install chromadb
# MAGIC %pip install lark
# MAGIC %pip install openai
# MAGIC %pip install tiktoken
# MAGIC %pip install -U langchain-openai
# MAGIC %pip install pysqlite3-binary
# MAGIC %pip install -U openai-whisper

# COMMAND ----------

# MAGIC %md
# MAGIC Criando o enviroment da chave OpenAI, necessário ser colocado a chave OpenAI em formato de input toda vez que rodar o código.

# COMMAND ----------

import getpass
import os

os.environ["OPENAI_API_KEY"] = getpass.getpass("OpenAI API Key:")

# COMMAND ----------

# MAGIC %md
# MAGIC Setando valores de environment para utilizar o Framework LangChain

# COMMAND ----------

import os

import sys
# sys.path.append('../..')

from dotenv import load_dotenv
load_dotenv()
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.langchain.plus"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Youtube
# MAGIC #### Imports necessários para utilizar o framework do Langchain

# COMMAND ----------

from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import OpenAIWhisperParser
from langchain.document_loaders.blob_loaders.youtube_audio import YoutubeAudioLoader
import os
import openai
import sys

# COMMAND ----------

# MAGIC %md
# MAGIC Link para transformar audio em texto.

# COMMAND ----------

#url="https://www.youtube.com/watch?v=wyGAYa2UMXQ"
url = input("Coloque a URL do YouTube, exemplo 'https://www.youtube.com/watch?v=wyGAYa2UMXQ': ")
save_dir="docs/youtube/"
yt_loader = GenericLoader(
    YoutubeAudioLoader([url],save_dir),
    OpenAIWhisperParser()
)
yt_docs = yt_loader.load()

# COMMAND ----------

# MAGIC %md
# MAGIC Texto separado pelo WhisperParser.

# COMMAND ----------

print (yt_docs)

# COMMAND ----------

yt_save = yt_docs

# COMMAND ----------

pdf_pages = yt_save

# COMMAND ----------

# MAGIC %run ./Splitting_the_documents

# COMMAND ----------

print (pdf_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Splitting the documents

# COMMAND ----------

import re

def split_text(document, chunk_size=500, separators=["\n\n", "\n", r"(?<=\. )", " "], chunk_overlap=50):
    """
    Função para dividir um documento de texto em pedaços menores com base em separadores e tamanho de pedaço.
    
    Args:
    - document (str): O documento de texto a ser dividido.
    - chunk_size (int): O tamanho máximo de cada pedaço.
    - separators (list): Lista de separadores a serem usados para dividir o texto.
    - chunk_overlap (int): O número de caracteres de sobreposição entre pedaços consecutivos.
    
    Returns:
    - list: Uma lista de strings, cada uma sendo um pedaço do documento original.
    """
    # Verifica se o documento é uma string
    if not isinstance(document, str):
        raise ValueError("O documento deve ser uma string")
    
    chunks = []
    current_pos = 0
    while current_pos < len(document):
        found_sep = False
        # Tenta dividir pelo maior separador primeiro
        for sep in separators:
            if sep == "":
                # Trata o caso especial onde não há separador
                next_pos = min(current_pos + chunk_size, len(document))
                found_sep = True
            else:
                # Encontra a posição do próximo separador dentro do tamanho do chunk
                sep_pattern = re.compile(sep)
                match = sep_pattern.search(document[current_pos:current_pos+chunk_size])
                if match:
                    next_pos = current_pos + match.end()
                    found_sep = True
                    break # Sai do loop de separadores ao encontrar o primeiro que corresponde
            
            if found_sep:
                break
        
        if not found_sep:
            # Se nenhum separador foi encontrado, simplesmente usa o tamanho do chunk
            next_pos = min(current_pos + chunk_size, len(document))
        
        chunk = document[current_pos:next_pos]
        if chunk:
            chunks.append(chunk)
            current_pos = next_pos - chunk_overlap  # Ajusta para sobreposição
        
        # Evita loop infinito
        if chunk_overlap >= chunk_size or not chunk:
            break

    return chunks

# Certifique-se de que yt_docs é uma string antes de passá-la para a função
yt_docs_split = split_text(yt_docs, chunk_size=500, chunk_overlap=50)
print(yt_docs_split)


# COMMAND ----------

print (yt_docs_split)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Token

# COMMAND ----------

# MAGIC %md
# MAGIC install tiktoken

# COMMAND ----------

# Token text splitter
token_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=10)

# COMMAND ----------

yt_docs_split = token_splitter.split_documents(yt_docs)

# COMMAND ----------

yt_docs_rec = r_splitter.split_documents(yt_docs)

# COMMAND ----------

yt_docs = list(yt_docs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Embeddings

# COMMAND ----------

from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter, TokenTextSplitter, MarkdownHeaderTextSplitter

# COMMAND ----------

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=500,
    chunk_overlap=50,
    length_function=len
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recursive text

# COMMAND ----------

# Recursive text splitter
r_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=150,
    separators=["\n\n", "\n", "(?<=\. )", " ", ""]
)

# COMMAND ----------

yt_docs = r_splitter.split_documents(yt_docs)

# COMMAND ----------

print (pdf_docs)

# COMMAND ----------

# Definir o caminho no DBFS onde o arquivo Parquet será salvo
parquet_path = "/FileStore/yt_docs_parquet"

# Salvar o DataFrame como Parquet
df.write.mode("overwrite").parquet(parquet_path)

print(f"Arquivo Parquet salvo com sucesso em {parquet_path}")


# COMMAND ----------

# Caminho no DBFS onde os dados serão salvos
output_path = "dbfs:/user/hive/warehouse/yt_docs"

# Salvar o DataFrame como arquivos JSON no caminho especificado
yt_docs.write.mode("overwrite").format("json").save(output_path)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import lit

# Função para iniciar ou obter a sessão Spark existente
def get_or_create_spark_session(app_name="PDF Content to DataFrame"):
    return SparkSession.builder.appName(app_name).getOrCreate()

# Suponha que 'pdf_docs' seja sua lista de documentos extraídos, onde cada 'doc' tem um atributo 'page_content'
def create_pdf_dataframe(pdf_docs, number_of_articles=20):
    # Verifica se a lista não está vazia e tem elementos suficientes
    if not pdf_docs or len(pdf_docs) < number_of_articles:
        raise ValueError("A lista 'pdf_docs' está vazia ou contém menos elementos do que 'number_of_articles'")
    
    # Definir o esquema para o DataFrame
    schema = StructType([
        StructField("page_content", StringType(), True),
        StructField("source", StringType(), True)  # Incluímos uma coluna extra para a fonte, se necessário
    ])

    # Criar uma lista de tuplas a partir dos documentos, incluindo um identificador de fonte, se aplicável
    data = [(doc.page_content, "source_info") for doc in pdf_docs[:number_of_articles]]

    # Iniciar a sessão Spark
    spark = get_or_create_spark_session()

    # Criar o DataFrame com o esquema definido
    pdf_dataframe = spark.createDataFrame(data, schema)

    return pdf_dataframe

# Supondo que 'pdf_docs' esteja definida, criar o DataFrame
try:
    pdf_dataframe = create_pdf_dataframe(pdf_docs, 20)
    # Exibir o DataFrame
    display(pdf_dataframe)
except ValueError as e:
    print(e)


# COMMAND ----------

# MAGIC %md
# MAGIC Separando o texto tabular da source para treinar o modelo.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

# Iniciar a sessão Spark, se ainda não foi iniciada
spark = SparkSession.builder.appName("PDF Content to DataFrame").getOrCreate()

# Suponha que 'pdf_docs' seja a sua lista de documentos extraídos
# Definir o esquema para o DataFrame
schema = StructType([
    StructField("page_content", StringType(), True)
])

# Criar uma lista de tuplas a partir dos primeiros 'number_of_articles' documentos em 'pdf_docs'
number_of_articles = 20  # ou o número de páginas que você deseja incluir
data = [(doc.page_content,) for doc in pdf_docs[:number_of_articles]]

# Criar o DataFrame com o esquema definido
pdf_dataframe = spark.createDataFrame(data, schema)

# Exibir o DataFrame
display(pdf_dataframe)


# COMMAND ----------

# MAGIC %md Esqueleto GPT.

# COMMAND ----------

from openai import OpenAI
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("SalvarPerguntasGPT").getOrCreate()

# Definindo o esquema conforme solicitado
pergunta_schema = StructType([
    StructField("id", StringType(), True),
    StructField("pergunta", StringType(), True),
    StructField("opcoes", ArrayType(StringType()), True),
    StructField("resposta_correta", StringType(), True)
])

# Inicialize o cliente da API OpenAI
client = OpenAI()

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from delta.tables import DeltaTable

response = client.chat.completions.create(
  model="gpt-3.5-turbo-0125",
  response_format={ "type": "json_object" },
  messages=[
      {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
      {"role": "system", "content": "use own data_pdf embedding."},
      {"role": "system", "content": "max 100 tokens."},
      {"role": "system", "content": "create a QA file with this structure, {\"id\": \"id value, like (1de, 2de, 3de)\", \"pergunta\": \"Alguma pergunta relacionada a pyspark e engenharia de dados\", \"opcoes\": [\"criar uma lista de pergunta se respostas e por fim a resposta correta, seguir proxima rule para melhor compreencao e espelho\"], \"resposta_correta\": \"A\"}"},
      {"role": "system", "content": "Exemplo: {\"id\": \"1de\", \"pergunta\": \"O que é um Data Lake?\", \"opcoes\": [\"A) Um tipo de banco de dados relacional\", \"B) Um sistema de armazenamento que permite guardar grandes volumes de dados brutos\", \"C) Uma ferramenta de visualização de dados\", \"D) Um modelo de processamento de dados\", \"E) Uma técnica de machine learning\"], \"resposta_correta\": \"B\"}"},
      {"role": "system", "content": "crie suas proprias perguntas com o esqueleto acima"},
      {"role": "system", "content": "crie no minimo quatro perguntas"},
      {"role": "system", "content": "crie o texto utilizando o arquivo yt_docs"},
      {"role": "system", "content": "Se o arquivo yt_docs estiver em ingles, faça a pergunta em portugês"},
  ]

)
print(response.choices[0].message.content)

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("SalvarPerguntasGPT").getOrCreate()

# Processando a resposta para ajustar ao schema
import json

# Supondo que a resposta esteja no formato esperado e possa ser convertida diretamente
resposta_json = json.loads(response.choices[0].message.content)
df_perguntas = spark.createDataFrame([resposta_json], schema=pergunta_schema)

# Define o caminho onde a tabela será salva
path = "dbfs:/user/hive/warehouse/perguntas_gpt"

# Verifica se a tabela "perguntas_gpt" já existe
if DeltaTable.isDeltaTable(spark, path):
    # A tabela existe, então faz append
    df_perguntas.write.format("delta").mode("append").option("path", path).saveAsTable("perguntas_gpt")
else:
    # A tabela não existe, então cria a tabela
    df_perguntas.write.format("delta").mode("overwrite").option("path", path).saveAsTable("perguntas_gpt")



# COMMAND ----------

from pyspark.sql import SparkSession

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("LeituraPerguntasGPT").getOrCreate()

# Define o caminho da tabela Delta
path = "dbfs:/user/hive/warehouse/perguntas_gpt"

# Lendo a tabela Delta
df_perguntas_gpt = spark.read.format("delta").load(path)

# Alternativamente, se a tabela está registrada no catálogo do Spark, você pode usar:
# df_perguntas_gpt = spark.table("perguntas_gpt")

# Mostrando os dados da tabela
df_perguntas_gpt.show()


# COMMAND ----------

