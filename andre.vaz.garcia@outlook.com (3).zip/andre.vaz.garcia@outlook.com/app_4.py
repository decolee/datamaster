# Databricks notebook source
# MAGIC %run ./etl_nota_final/create_df_nota_final

# COMMAND ----------

# MAGIC %run ./etl_nota_final/etl_nota_final

# COMMAND ----------

# MAGIC %run ./etl_nota_final/atualizar_df_func