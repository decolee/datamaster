# Databricks notebook source
# MAGIC %md
# MAGIC Utilização do consumer e topic.

# COMMAND ----------

# MAGIC %sh
# MAGIC
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic topic1 --from-beginning
# MAGIC

# COMMAND ----------

# MAGIC %sh
# MAGIC
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic topic1

# COMMAND ----------

