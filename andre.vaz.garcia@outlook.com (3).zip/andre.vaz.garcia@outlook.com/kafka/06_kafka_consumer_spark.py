# Databricks notebook source
# MAGIC %md
# MAGIC Consumer da notificação

# COMMAND ----------

# MAGIC %sh
# MAGIC
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic notificacao --from-beginning
# MAGIC

# COMMAND ----------

