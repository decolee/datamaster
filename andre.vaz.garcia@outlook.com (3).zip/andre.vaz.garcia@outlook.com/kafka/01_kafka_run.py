# Databricks notebook source
# MAGIC %md
# MAGIC Analíse de hostname.

# COMMAND ----------

# MAGIC %sh
# MAGIC hostname

# COMMAND ----------

# MAGIC %sh
# MAGIC cat \etc\os-release

# COMMAND ----------

# MAGIC %sh
# MAGIC java-version

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -la ./

# COMMAND ----------

# MAGIC %sh
# MAGIC pwd

# COMMAND ----------

# MAGIC %md
# MAGIC ####File uploaded to /FileStore/kafka_3_6_1_src.tgz

# COMMAND ----------

# MAGIC %md
# MAGIC Instalar o Kafka no DBFS do Databricks.

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/FileStore/kafka_2_12_3_6_1.tgz"))

# COMMAND ----------

# MAGIC %md
# MAGIC Cópia para driver

# COMMAND ----------

dbutils.fs.cp("FileStore/kafka_2_12_3_6_1.tgz", "file:///databricks/driver/kafka_2_12_3_6_1.tgz")

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -lt ./

# COMMAND ----------

# MAGIC %sh
# MAGIC tar -xzf kafka_2_12_3_6_1.tgz

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -lt ./

# COMMAND ----------

# MAGIC %sh
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC ls -la ./

# COMMAND ----------

# MAGIC %md
# MAGIC Start do zookeeper no cluster.

# COMMAND ----------

# MAGIC %sh
# MAGIC cd kafka_2.12-3.6.1
# MAGIC bin/zookeeper-server-start.sh config/zookeeper.properties

# COMMAND ----------

# MAGIC %md
# MAGIC LocalHost clientPortAddress is 0.0.0.0:2181

# COMMAND ----------

