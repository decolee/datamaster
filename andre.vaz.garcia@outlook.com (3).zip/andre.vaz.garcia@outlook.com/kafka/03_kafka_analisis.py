# Databricks notebook source
# MAGIC %sh
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC ls -lt ./

# COMMAND ----------

# MAGIC %sh
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic topic1

# COMMAND ----------

# MAGIC %sh
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-topics.sh --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1 --topic topic1
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC echo '
# MAGIC {"id": "1de", "pergunta": "O que é um Data Lake?", "opcoes": ["A) Um tipo de banco de dados relacional", "B) Um sistema de armazenamento que permite guardar grandes volumes de dados brutos", "C) Uma ferramenta de visualização de dados", "D) Um modelo de processamento de dados", "E) Uma técnica de machine learning"], "resposta_correta": "B"}]
# MAGIC ' | bin/kafka-console-producer.sh --broker-list localhost:9092 --topic topic1
# MAGIC

# COMMAND ----------

