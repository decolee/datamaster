# Databricks notebook source
from pyspark.sql.functions import from_json, col, expr
from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType, IntegerType, ArrayType

# COMMAND ----------

streamingDF =(
                spark.readStream
                    .format("kafka")
                    .option("kafka.bootstrap.servers", "localhost:9092")
                    .option("subscribe", "topic1")
                    .option("startingOffsets", "earliest")
                    .load()
            )

streamingDF.printSchema()

# COMMAND ----------

streamingDF.display()

# COMMAND ----------

streamingDF.select(col("value").cast("string").alias("value")).display()

# COMMAND ----------

# MAGIC %scala
# MAGIC import java.util.Properties
# MAGIC val props = new Properties()
# MAGIC props.put("bootstrap.servers", "localhost:9092")
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

pergunta_schema = StructType([
    StructField("id", StringType(), True),
    StructField("pergunta", StringType(), True),
    StructField("opcoes", ArrayType(StringType()), True),
    StructField("resposta_correta", StringType(), True)
])

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Definindo o esquema que corresponde à estrutura do seu JSON
resultado_schema = StructType([
    StructField("matricula", StringType(), True),
    StructField("ID_Pergunta", StringType(), True),
    StructField("Resultado", IntegerType(), True)
])


# COMMAND ----------

from pyspark.sql.functions import from_json, col

# Aplicando a função from_json para deserializar a string JSON para um DataFrame conforme o esquema definido
parsed_df = streamingDF.select(from_json(col("value").cast("string"), resultado_schema).alias("parsed_value"))

parsed_df.printSchema()
# Isso deve imprimir o esquema correto, refletindo a estrutura do seu JSON

# Para visualizar os dados deserializados corretamente
parsed_df.display()


# COMMAND ----------

parsed_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Schema Enforcement

# COMMAND ----------

explode_df = parsed_df.selectExpr("parsed_value.id as id",
                                  "parsed_value.pergunta as pergunta",
                                  "parsed_value.opcoes as opcoes",
                                  "parsed_value.resposta_correta as resposta_correta")

explode_df.printSchema()

# COMMAND ----------

explode_df.display()

# COMMAND ----------

# Removendo linhas que contêm qualquer valor null
clean_df = explode_df.dropna()

# Para verificar o esquema e garantir que as linhas com valores null foram removidas
clean_df.printSchema()
clean_df.display()  # Mostra uma pré-visualização dos dados para confirmar a remoção


# COMMAND ----------

df_stream_kafka = clean_df

# COMMAND ----------

chk_point = "dbfs:/FileStore/kafka/kafka_chk/"
dir_output = "dbfs:/FileStore/kafka/kafka_dir/"

write_query = (
    df_stream_kafka
    .writeStream
    .format("json")  # Mova o método format para ser chamado com writeStream
    .queryName("writeStream")
    .outputMode("append")
    .option("path", dir_output)
    .option("checkpointLocation", chk_point)
    .trigger(processingTime="15 seconds")
    .start()
)

# COMMAND ----------

df_stream_kafka.display()

# COMMAND ----------

display(dbutils.fs.ls(dir_output))

# COMMAND ----------

# Define o caminho do diretório que você deseja criar no DBFS
chk_point = "FileStore/kafka/kafka_chk/"
dir_output = "FileStore/kafka/kafka_dir/"

# Cria o diretório usando dbutils
dbutils.fs.mkdirs(chk_point)


# COMMAND ----------

chk_point_notif = "dbfs:FileStore/kafka/notif_chk/"

write_notificacao = (
                    kafka_targuet.writeStream
                        .queryName("notificacao_writer")
                        .format("kafka")
                        .option("kafka.bootstrap.servers", "localhost:9092")
                        .option("topic", "notificacao")
                        .outputMode("append")
                        .option("checkpointLocation", chk_point_notif)
                        .start()  
)

# COMMAND ----------

