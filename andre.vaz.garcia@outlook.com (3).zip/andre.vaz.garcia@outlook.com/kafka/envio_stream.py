# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_json, struct

# Iniciar sessão Spark
spark = SparkSession.builder.appName("DatabricksKafkaIntegration").getOrCreate()

# Ler a tabela
df = spark.table("default.resultados")

# Selecionar e converter os dados em JSON
json_df = df.select(to_json(struct(*df.columns)).alias("value"))

# Configurar o envio para o Kafka
query = json_df \
    .write \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "topic1") \
    .save()

# Finalizar a sessão Spark
#spark.stop()

# COMMAND ----------

