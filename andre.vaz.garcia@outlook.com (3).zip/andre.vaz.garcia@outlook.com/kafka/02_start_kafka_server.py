# Databricks notebook source
# MAGIC %md
# MAGIC Start do Kafka

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -lta
# MAGIC cd kafka_2.12-3.6.1
# MAGIC
# MAGIC bin/kafka-server-start.sh config/server.properties

# COMMAND ----------

