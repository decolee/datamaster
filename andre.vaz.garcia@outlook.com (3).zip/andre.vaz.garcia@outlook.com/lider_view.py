# Databricks notebook source
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F

# Inicializar a SparkSession (assumindo que já esteja criada como 'spark')

# Supondo que lider_df e df_tb_funcionarios_nota já estejam definidos e carregados

# Definir uma janela particionada por sigla e ordenada por 'numero_lider_lider'
windowSpec = Window.partitionBy("sigla").orderBy("numero_lider_lider")

# Atribuir um número de linha dentro de cada partição de sigla
lider_df_with_row_number = lider_df.withColumn("row_number", F.row_number().over(windowSpec))

# Filtrar para manter apenas a primeira linha por sigla
examples_per_sigla = lider_df_with_row_number.filter(lider_df_with_row_number.row_number == 1)

# Selecionar matrículas de exemplo para 'ROR', 'BMA', e 'COE'
examples_per_sigla = examples_per_sigla.filter(
    (examples_per_sigla.sigla == 'ROR') | 
    (examples_per_sigla.sigla == 'BMA') | 
    (examples_per_sigla.sigla == 'COE')
).select('matricula_lider', 'sigla')

# Coletar os exemplos e printar
examples_list = examples_per_sigla.collect()
for example in examples_list:
    print(f"Matrícula: {example['matricula_lider']}, Sigla: {example['sigla']}")

# Input do usuário para escolher a matrícula do líder
matricula_escolhida = input("Digite a matrícula do líder escolhida: ")

# Encontrar a sigla correspondente à matrícula escolhida
sigla_escolhida = [m['sigla'] for m in examples_list if m['matricula_lider'] == matricula_escolhida][0]

# Filtrar df_tb_funcionarios_nota pela sigla e aplicar o tratamento específico
if sigla_escolhida:
    # Encontrar o número do líder correspondente à matrícula escolhida no df de líderes
    numero_lider_lider = lider_df.filter(lider_df.matricula_lider == matricula_escolhida).select('numero_lider_lider').collect()[0]['numero_lider_lider']
    
    # Filtrar o df_tb_funcionarios_nota pela sigla escolhida
    df_filtrado = df_tb_funcionarios_nota.filter(df_tb_funcionarios_nota.sigla == sigla_escolhida)
    
    # Aplicar o tratamento específico mencionado
    df_filtrado = df_filtrado.withColumn("numero_lider_calculado", F.col("numero_lider") * numero_lider_lider)
    
    # Exibir os dados filtrados
    df_filtrado.show()
else:
    print("Matrícula não encontrada ou sigla inválida.")


# COMMAND ----------

