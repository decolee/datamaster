# Databricks notebook source
# MAGIC %run ./funcionario_dados/run_save_results

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas_ETL/create_dataframe_notas

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas_ETL/etl_notas

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas_ETL/create_dataframe_df_resultados

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas_ETL/etl_resultados