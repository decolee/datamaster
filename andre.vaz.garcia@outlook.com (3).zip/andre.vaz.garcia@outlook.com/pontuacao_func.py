# Databricks notebook source
import pandas as pd

# Exemplo de DataFrames
funcionario_df = pd.DataFrame({
    'matricula': ['123', '456', '789', '1011'],
    'nome': ['Alice', 'Bob', 'Carlos', 'Diana'],
    'cargo': ['Especialista 1', 'Especialista 2', 'Especialista 3', 'Especialista 4'],
    'nota_geral': [5, 6, 7, 8]
})

perguntas_facil_df = pd.DataFrame({'pergunta': ['Fácil 1', 'Fácil 2']})
perguntas_media_df = pd.DataFrame({'pergunta': ['Média 1', 'Média 2']})
perguntas_dificil_df = pd.DataFrame({'pergunta': ['Difícil 1', 'Difícil 2']})

# Função para selecionar perguntas
def selecionar_perguntas(cargo):
    if cargo == 'Especialista 1':
        return perguntas_facil_df.sample(5, replace=True)
    elif cargo == 'Especialista 2':
        return pd.concat([perguntas_facil_df, perguntas_media_df]).sample(5, replace=True)
    elif cargo == 'Especialista 3':
        return pd.concat([perguntas_media_df, perguntas_dificil_df]).sample(5, replace=True)
    elif cargo == 'Especialista 4':
        return perguntas_dificil_df.sample(5, replace=True)

# Função principal
def interagir_com_funcionario(matricula):
    funcionario = funcionario_df[funcionario_df['matricula'] == matricula].iloc[0]
    print(f"Bem vindo {funcionario['nome']}")

    perguntas = selecionar_perguntas(funcionario['cargo'])

    # Simulação de respostas (substitua por lógica real conforme necessário)
    respostas = []
    for index, row in perguntas.iterrows():
        print(row['pergunta'])
        resposta = input("Digite sua resposta: ")
        respostas.append({'pergunta': row['pergunta'], 'resposta': resposta})

    # Suponha que cada resposta correta vale 2 pontos
    pontos = sum([2 for resposta in respostas if resposta['resposta'] == 'correta'])

    # Atualizar a nota geral do funcionário
    nova_nota_geral = (funcionario['nota_geral'] + pontos * 2) / 2
    funcionario_df.loc[funcionario_df['matricula'] == matricula, 'nota_geral'] = nova_nota_geral
    print(f"Nova nota geral de {funcionario['nome']}: {nova_nota_geral}")

# Execução
interagir_com_funcionario('123')
