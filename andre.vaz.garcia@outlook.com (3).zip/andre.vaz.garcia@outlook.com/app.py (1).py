# Databricks notebook source
spark.sparkContext.setLogLevel("WARN")  # Options include ERROR, WARN, INFO, DEBUG

# COMMAND ----------

# MAGIC %run ./create_table

# COMMAND ----------

# MAGIC %run ./perguntas_nv_basico

# COMMAND ----------

# MAGIC %run ./perguntas_nv_medio

# COMMAND ----------

# MAGIC %run ./perguntas_nv_avancado

# COMMAND ----------

# MAGIC %run ./create_table_perguntas

# COMMAND ----------

# MAGIC %run ./qa_teste

# COMMAND ----------

funcionario_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Transformando valor string para long. (vamos utilizar essa coluna mais para frente)

# COMMAND ----------

from pyspark.sql import functions as F

# Transformando a coluna 'nota_media' de string para long
funcionario_df = funcionario_df.withColumn("nota_media", funcionario_df["nota_media"].cast("long"))

# Verificando o esquema após a transformação
funcionario_df.printSchema()


# COMMAND ----------

# MAGIC %md
# MAGIC Salvando os resultados no DBFS correspondente.

# COMMAND ----------

resultados_df.write.format("parquet").insertInto("resultados")
#criar uma sigla de database e salvar ele como um resultado ex pe_resultados. 

# COMMAND ----------



# COMMAND ----------

# MAGIC %run ./kafka/envio_stream

# COMMAND ----------

# MAGIC %run ./create_dataframe_notas

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, sum, length, expr,lit, regexp_extract, concat,format_number

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CalculoNotas").enableHiveSupport().getOrCreate()

# Ler a tabela resultados em um DataFrame
df_resultados = spark.table("resultados")

# Função para traduzir o ID da pergunta para a categoria correspondente
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}

# Criar uma coluna com a categoria traduzida
df_traduzido = df_resultados.withColumn("categoria", 
    expr("""
        CASE 
            WHEN substring(ID_Pergunta, -2) = 'az' THEN 'azure'
            WHEN substring(ID_Pergunta, -2) = 'ms' THEN 'maestro'
            WHEN substring(ID_Pergunta, -2) = 'ml' THEN 'machine_learning'
            WHEN substring(ID_Pergunta, -2) = 'cm' THEN 'control_m'
            WHEN substring(ID_Pergunta, -2) = 'de' THEN 'data_engineer'
        END
    """))

# Substituindo valores de Resultado por 'correto' e 'errado'
df_traduzido = df_traduzido.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Agrupar por matrícula e categoria, e contar 'correto' e 'errado'
df_agrupado = df_traduzido.groupBy("matricula", "categoria").pivot("Resultado").count()

# Calcular a porcentagem de acertos
df_notas = df_agrupado.withColumn("nota", 
                                  concat(format_number((col("correto") / (col("correto") + col("errado"))) * 100, 2), lit('%')))

# Ajuste conforme necessário para incluir as colunas 'corretas' e 'erradas'
# E renomear colunas de nota para seguir o formato desejado

# Exibir o DataFrame para verificar o resultado
df_notas.show()


# COMMAND ----------

# MAGIC %run ./create_dataframe_df_resultados

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col, lit, regexp_extract

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("TransformacaoDFCompleta").getOrCreate()

# Carregar o DataFrame de resultados
# Suponha que df_resultados já esteja carregado com as colunas 'matricula', 'ID_Pergunta', e 'Resultado'

# Extrair a categoria de cada ID_Pergunta
df_categoria = df_resultados.withColumn("categoria", regexp_extract("ID_Pergunta", r"(\D+)$", 1))

# Traduzir abreviações para nomes completos
traducao_categoria = {
    'az': 'azure',
    'ms': 'maestro',
    'ml': 'machine_learning',
    'cm': 'control_m',
    'de': 'data_engineer'
}
for abrev, nome in traducao_categoria.items():
    df_categoria = df_categoria.withColumn("categoria", 
                                           when(col("categoria") == abrev, nome).otherwise(col("categoria")))

# Converter Resultado para correto/errado
df_categoria = df_categoria.withColumn("Resultado", 
                                       when(col("Resultado") == 1, "correto").otherwise("errado"))

# Pivotar para transformar categorias em colunas e contar 'correto' e 'errado'
df_pivotado = df_categoria.groupBy("matricula").pivot("categoria").agg(
    sum(when(col("Resultado") == "correto", 1)).alias("corretas"),
    sum(when(col("Resultado") == "errado", 1)).alias("erradas")
).na.fill(0)

# Lista de categorias para iterar
categorias = list(traducao_categoria.values())

# Calcular a nota para cada categoria
for categoria in categorias:
    df_pivotado = df_pivotado.withColumn(f"nota_{categoria}", 
                                          (col(f"{categoria}_corretas") / 
                                           (col(f"{categoria}_corretas") + col(f"{categoria}_erradas"))) * 100)

# Selecionar e renomear colunas conforme necessário
colunas_selecionadas = ["matricula"] + \
                       [f"{categoria}_corretas" for categoria in categorias] + \
                       [f"{categoria}_erradas" for categoria in categorias] + \
                       [f"nota_{categoria}" for categoria in categorias]

df_final = df_pivotado.select(*colunas_selecionadas)

# Exibir o DataFrame final para verificação
df_final.show(truncate=False)

# Encerrar a sessão Spark, se necessário
# spark.stop()


# COMMAND ----------

# MAGIC %md
# MAGIC ./create_df_nota_final

# COMMAND ----------

from pyspark.sql import SparkSession

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("Criando_df_notas").getOrCreate()

# Lista com os DataFrames e os nomes das tabelas correspondentes
dfs_e_tabelas = [
    (df_notas, "df_notas"),
    (df_final, "df_final")
]

for df, tabela in dfs_e_tabelas:
    # Verifica se a tabela existe
    if spark._jsparkSession.catalog().tableExists(tabela):
        # Se a tabela existir, faça o insert into
        df.write.mode("append").format("parquet").insertInto(tabela)
    else:
        # Verifica se o diretório associado à tabela existe
        path = f"dbfs:/user/hive/warehouse/{tabela}"
        if dbutils.fs.ls(path):
            # Se o diretório existir, remove o diretório
            dbutils.fs.rm(path, recurse=True)
        # Cria a tabela com os dados do DataFrame após remover o diretório existente
        df.write.mode("overwrite").format("parquet").saveAsTable(tabela)

# COMMAND ----------

# Lista com os nomes das tabelas para ler
nomes_tabelas = ["df_notas", "df_final"]

for nome_tabela in nomes_tabelas:
    # Ler a tabela para um DataFrame
    df = spark.table(nome_tabela)
    
    # Exibir os primeiros registros do DataFrame para verificar
    print(f"Conteúdo da tabela {nome_tabela}:")
    df.display()

# COMMAND ----------

df_notas.printSchema()

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import LongType

# Passo 1: Identificar matrículas presentes em ambos os DataFrames
matriculas_comuns = df_notas.select("matricula").intersect(funcionario_df.select("matricula"))

# Passo 2: Filtrar df_notas e calcular a nova nota
df_notas_filtrado = df_notas.join(matriculas_comuns, "matricula", "inner")\
    .withColumn("errado", F.coalesce("errado", F.lit(0)))\
    .withColumn("nova_nota", F.col("correto") - F.col("errado"))

# Agregar as notas por matrícula
df_agregado = df_notas_filtrado.groupBy("matricula")\
    .agg(F.sum("nova_nota").alias("soma_nova_nota"))

# Passo 3: Preparar funcionario_df e atualizar a nota média
funcionario_df = funcionario_df.withColumn("nota_media_long", F.col("nota_media").cast(LongType()))

# Juntar os DataFrames para atualizar a nota média
funcionario_atualizado = funcionario_df.join(df_agregado, "matricula", "left_outer")\
    .withColumn("nota_media_atualizada", 
                F.when(F.col("soma_nova_nota").isNull(), F.col("nota_media_long"))
                 .otherwise((F.col("nota_media_long") + F.col("soma_nova_nota")) / 2))\
    .drop("nota_media", "nota_media_long", "soma_nova_nota")\
    .withColumnRenamed("nota_media_atualizada", "nota_media")

# Passo 4: Salvar como tabela
funcionario_atualizado.write.mode("overwrite").saveAsTable("ts_tb_funcionarios_nota")


# COMMAND ----------

print ("df_notas")
df_notas.printSchema()
print ("funcionario_df")
funcionario_df.printSchema()

funcionario_atualizado.show()


# COMMAND ----------

df_tb_funcionarios_nota = spark.table("ts_tb_funcionarios_nota")

# COMMAND ----------

df_tb_funcionarios_nota.count()

# COMMAND ----------

# MAGIC %md
# MAGIC criando dataframe por siglas.

# COMMAND ----------

# MAGIC %md
# MAGIC Ativando funções criar dataframe siglas.

# COMMAND ----------

# MAGIC %run ./create_df_siglas

# COMMAND ----------

# MAGIC %run ./analises_e_graficos

# COMMAND ----------

# MAGIC %md
# MAGIC from pyspark.sql import SparkSession
# MAGIC
# MAGIC # Supondo que sua SparkSession já esteja iniciada com o nome `spark`
# MAGIC # e que `funcionario_df` seja o DataFrame que você deseja salvar/atualizar.
# MAGIC
# MAGIC # Nome da tabela
# MAGIC nome_tabela = "tb_funcionarios"
# MAGIC
# MAGIC def salvar_ou_atualizar_tabela(funcionario_df, nome_tabela):
# MAGIC     """
# MAGIC     Salva o DataFrame como uma tabela Delta, habilitando a migração de esquema
# MAGIC     se a tabela já existir.
# MAGIC     """
# MAGIC     # Verifica se a tabela existe
# MAGIC     if not spark._jsparkSession.catalog().tableExists(nome_tabela):
# MAGIC         # Se a tabela não existir, cria a tabela a partir do DataFrame
# MAGIC         funcionario_df.write.mode("overwrite").saveAsTable(nome_tabela)
# MAGIC         print(f"A tabela {nome_tabela} foi criada com sucesso.")
# MAGIC     else:
# MAGIC         # Se a tabela existir, atualiza a tabela com migração de esquema
# MAGIC         funcionario_df.write.option("mergeSchema", "true").mode("overwrite").saveAsTable(nome_tabela)
# MAGIC         print(f"A tabela {nome_tabela} foi atualizada com sucesso.")
# MAGIC
# MAGIC # Chamada da função para salvar ou atualizar a tabela
# MAGIC salvar_ou_atualizar_tabela(funcionario_df, nome_tabela)
# MAGIC

# COMMAND ----------

funcionario_df.printSchema()

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Ajustando o tipo da coluna 'nota_media' para long
funcionario_df = funcionario_df.withColumn("nota_media", col("nota_media").cast("long"))

# Salvando o DataFrame ajustado como uma tabela, sobrescrevendo a tabela existente
funcionario_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(nome_tabela)

print(f"A tabela {nome_tabela} foi atualizada com sucesso.")


# COMMAND ----------

from pyspark.sql import SparkSession

# Nome da tabela
nome_tabela = "tb_funcionarios"

# Verifica se a tabela existe
if not spark._jsparkSession.catalog().tableExists(nome_tabela):
    # Se a tabela não existir, cria a tabela a partir do DataFrame 'funcionario_df'
    funcionario_df.write.mode("overwrite").saveAsTable(nome_tabela)
    print(f"A tabela {nome_tabela} foi criada com sucesso.")
else:
    # Caso a tabela já exista, uma mensagem é exibida
    print(f"A tabela {nome_tabela} já existe.")


# COMMAND ----------

# MAGIC %run ./data_masking

# COMMAND ----------

# Assuming you've already set up your SparkSession as 'spark'

# Define the path to the data
path = 'dbfs:/user/hive/warehouse/tb_funcionarios_mask'

# Read data from the specified path
df = spark.read.format("delta").load(path)

# Display the DataFrame schema
df.printSchema()

# Show some rows of the DataFrame
df.show()


# COMMAND ----------

lider_df.display()

# COMMAND ----------

df_tb_funcionarios_nota.printSchema()

# COMMAND ----------

lider_df.printSchema()

# COMMAND ----------

# MAGIC %run ./lider_view

# COMMAND ----------

