# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import re
from datetime import datetime

# Inicializando a sessão Spark
spark = SparkSession.builder.appName("DataFormatter").getOrCreate()

# Função para converter datas para o formato 'mmAA'
def convert_date_format(date_str):
    """
    Converte datas de vários formatos para o formato 'mmAA'.
    """
    # Definindo os padrões de data
    formats = [
        "%Y%m%d",    # 20231210
        "%m%d%Y",    # 12232023
        "%d%m%Y",    # 23122023
        "%Y-%m-%d",  # 2023-12-10
        "%d-%m-%Y",  # 23-12-2023
        "%m-%d-%Y",  # 12-23-2023
        "%Y/%m/%d",  # 2023/12/10
        "%d/%m/%Y",  # 23/12/2023
        "%m/%d/%Y"   # 12/23/2023
        # Adicionar mais formatos conforme necessário
    ]
    
    for fmt in formats:
        try:
            # Tentando converter com o formato atual
            dt = datetime.strptime(date_str, fmt)
            return dt.strftime("%m%y")  # Convertendo para o formato mmAA
        except ValueError:
            continue  # Tentar o próximo formato se o atual falhar

    return "Formato inválido"  # Retornar se nenhum formato corresponder

# Registrando a UDF
convert_date_udf = udf(convert_date_format, StringType())

# Criando um DataFrame de exemplo para testar
data = [("20231210",), ("12232023",), ("23122023",), ("2023-12-10",), 
        ("23-12-2023",), ("12-23-2023",), ("2023/12/10",), ("23/12/2023",), ("12/23/2023",)]
columns = ["raw_date"]
df = spark.createDataFrame(data, columns)

# Aplicando a UDF para converter as datas
df_formatted = df.withColumn("formatted_date", convert_date_udf(df["raw_date"]))

# Exibindo o resultado
df_formatted.show()

# Função para converter string para lowercase
def to_lowercase(s):
    return s.lower() if s else s

# Função para remover espaços em branco no início e no final
def remove_whitespace(s):
    return s.strip() if s else s

# Função para remover caracteres especiais
def remove_special_chars(s):
    return re.sub(r'[^a-zA-Z0-9\s]', '', s) if s else s

# Registrando as UDFs
convert_date_udf = udf(convert_date_format, StringType())
to_lowercase_udf = udf(to_lowercase, StringType())
remove_whitespace_udf = udf(remove_whitespace, StringType())
remove_special_chars_udf = udf(remove_special_chars, StringType())

# Criando um DataFrame de exemplo
data = [("  20231210  ",), ("***12232023***",), (" 23-12-2023 ",), ("Hello! World?",)]
columns = ["raw_data"]
df = spark.createDataFrame(data, columns)

# Aplicando as UDFs para tratamento de dados
df_processed = df.withColumn("formatted_data", convert_date_udf(df["raw_data"]))\
                 .withColumn("lowercase", to_lowercase_udf(df["raw_data"]))\
                 .withColumn("no_whitespace", remove_whitespace_udf(df["raw_data"]))\
                 .withColumn("no_special_chars", remove_special_chars_udf(df["raw_data"]))


# COMMAND ----------

