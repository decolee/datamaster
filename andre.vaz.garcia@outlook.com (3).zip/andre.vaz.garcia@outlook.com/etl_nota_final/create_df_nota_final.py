# Databricks notebook source
from pyspark.sql import SparkSession

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("YourAppName").getOrCreate()

def tabela_existe(tabela):
    """Verifica se a tabela existe no catálogo do Spark."""
    return spark._jsparkSession.catalog().tableExists(tabela)

def verificar_diretorio_tabela(tabela):
    """Verifica se o diretório associado à tabela existe e o remove se existir."""
    path = f"dbfs:/user/hive/warehouse/{tabela}"
    try:
        if dbutils.fs.ls(path):
            dbutils.fs.rm(path, recurse=True)
            return True
    except Exception as e:
        # Se o diretório não existir, dbutils.fs.ls lançará um erro
        return False

def inserir_ou_criar_tabela(df, tabela):
    """Insere dados em uma tabela existente ou cria uma nova tabela."""
    if tabela_existe(tabela):
        df.write.mode("append").format("parquet").insertInto(tabela)
    else:
        if verificar_diretorio_tabela(tabela):
            print(f"Diretório {tabela} existente foi removido.")
        df.write.mode("overwrite").format("parquet").saveAsTable(tabela)

def processar_dfs_e_tabelas(dfs_e_tabelas):
    """Processa uma lista de DataFrames e seus nomes de tabela correspondentes."""
    for df, tabela in dfs_e_tabelas:
        inserir_ou_criar_tabela(df, tabela)

# Lista com os DataFrames e os nomes das tabelas correspondentes
# Suponha que df_notas e df_final estejam previamente definidos
dfs_e_tabelas = [
    (df_notas, "df_notas"),
    (df_final, "df_final")
]

# Exemplo de uso:
# processar_dfs_e_tabelas(dfs_e_tabelas)
