# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType
import random

# Iniciar sessão Spark
spark = SparkSession.builder.appName("PopulateLiderTable").getOrCreate()

# Definir o esquema para a tabela Lider
lider_schema = StructType([
    StructField("Nome", StringType(), True),
    StructField("Area", StringType(), True),
    StructField("Score", FloatType(), True),
    StructField("numero_lider", IntegerType(), True),
    StructField("Ranking", FloatType(), True),
    StructField("matricula", StringType(), True),
    StructField("sigla", StringType(), True),
    StructField("dominio", StringType(), True),
    StructField("email", StringType(), True)
])

# Lista de nomes brasileiros (exemplos)
nomes_brasileiros = ["Ana", "Luiz", "Carlos", "Mariana", "Paula", "Rafael", "Julia", "Roberto", "Fernanda", "Gabriel"]

# Mapeamento de domínios, siglas e áreas
dominio_sigla_area = {
    "financas": [("ROR", "1")],
    "qualidade": [("BMA", "2")],
    "cartoes": [("COE", "3")]
}

# Função para gerar uma matrícula única
used_matriculas = set()
def gerar_matricula():
    while True:
        matricula = "T" + str(random.randint(100000, 999999))
        if matricula not in used_matriculas:
            used_matriculas.add(matricula)
            return matricula

# Função para gerar um número de líder único
used_numeros_lider = set()
def gerar_numero_lider():
    while True:
        numero = random.randint(0, 10)
        if numero not in used_numeros_lider:
            used_numeros_lider.add(numero)
            return numero

# Shuffle the list of names
random.shuffle(nomes_brasileiros)

# Gerar 10 registros fictícios garantindo a presença de todos os domínios e siglas
dados_lider = []
dominios_siglas = [item for sublist in dominio_sigla_area.values() for item in sublist]
random.shuffle(dominios_siglas)  # Embaralhar a lista de domínios e siglas

for i in range(10):
    nome = nomes_brasileiros[i]
    sigla, area = dominios_siglas[i % len(dominios_siglas)]
    dominio = [dom for dom, siglas in dominio_sigla_area.items() if (sigla, area) in siglas][0]
    score = round(random.uniform(0, 10), 2)
    numero_lider = gerar_numero_lider()
    ranking = round(random.uniform(0, 10), 2)
    matricula = gerar_matricula()
    email = nome.lower() + "@f1rst.com.br"

    dados_lider.append((nome, area, score, numero_lider, ranking, matricula, sigla, dominio, email))

# Criar DataFrame da tabela Lider com os dados
lider_df = spark.createDataFrame(dados_lider, lider_schema)
lider_df.show()


# COMMAND ----------

# MAGIC %run ./dados_mocks

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import col
import random

# Iniciar sessão Spark
spark = SparkSession.builder.appName("FuncionarioLiderMatching").getOrCreate()

# Definir o esquema para a tabela Funcionario
funcionario_schema = StructType([
    StructField("Nome", StringType(), True),
    StructField("matricula", StringType(), True),
    StructField("dominio", StringType(), True),
    StructField("cargo", StringType(), True),
    StructField("nivel", StringType(), True),
    StructField("email", StringType(), True),
    StructField("numero_lider", IntegerType(), True),
    StructField("sigla", StringType(), True)
])

# Lista de nomes brasileiros (exemplos)
#nomes_brasileiros = ["Joao", "Maria", "Jose", "Ana", "Paulo", "Clara", "Ricardo", "Fernanda", "Carlos", "Daniela"]
random.shuffle(nomes_brasileiros)

# Cargos possíveis
cargos = ["Especialista 1", "Especialista 2", "Especialista 3", "Especialista 4", "Especialista 5"]

# Níveis possíveis
niveis = ["basico", "medio", "avancado"]

# Valores possíveis para domínio e sigla
dominios_e_siglas = {
    "financas": "ROR",
    "qualidade": "BMA",
    "cartoes": "COE"
}

# Função para gerar uma matrícula única
used_matriculas = set()
def gerar_matricula():
    while True:
        matricula = "T" + str(random.randint(100000, 999999))
        if matricula not in used_matriculas:
            used_matriculas.add(matricula)
            return matricula

# Gerar 10 registros fictícios
dados_funcionario = []
for _ in range(80):
    nome = nomes_brasileiros.pop()
    matricula = gerar_matricula()
    dominio_escolhido = random.choice(list(dominios_e_siglas.keys()))
    dominio = dominio_escolhido
    cargo = random.choice(cargos)
    nivel = random.choice(niveis)
    email = nome.lower().split()[0] + "@f1rst.com.br"
    numero_lider = random.randint(0, 10)
    sigla = dominios_e_siglas[dominio_escolhido]

    dados_funcionario.append((nome, matricula, dominio, cargo, nivel, email, numero_lider, sigla))

# Criar DataFrame da tabela Funcionario com os dados
funcionario_df = spark.createDataFrame(dados_funcionario, funcionario_schema)

# Criar DataFrame da tabela Funcionario com os dados

funcionario_df = spark.createDataFrame(dados_funcionario, funcionario_schema)

# Criar um DataFrame lider_df de exemplo (como antes)

rename_columns = {
    "numero_lider": "numero_lider_lider",
    "Nome": "nome_lider",
    "matricula": "matricula_lider",
    "dominio": "dominio_lider",
    "email": "email_lider"
}

# Iterate over the dictionary and rename the columns in lider_df
for original_name, new_name in rename_columns.items():
    lider_df = lider_df.withColumnRenamed(original_name, new_name)

# Realizar o join entre funcionario_df e lider_df usando a coluna "sigla"
funcionario_lider_df = funcionario_df.join(lider_df, "sigla", "left")

# Selecionar as colunas necessárias e renomear "numero_lider_lider" para "numero_lider"
funcionario_df_atualizado = funcionario_lider_df.select(
    *[col(f"{nome_coluna}") for nome_coluna in funcionario_df.columns if nome_coluna != "numero_lider"],
    col("numero_lider_lider").alias("numero_lider")
)

# Mostrar o DataFrame atualizado
funcionario_df.show()


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType
import random

# Iniciar sessão Spark
spark = SparkSession.builder.appName("PopulateNotasTable").getOrCreate()

# Definir o esquema para a tabela Notas
notas_schema = StructType([
    StructField("matricula", StringType(), True),
    StructField("nota_dominio", FloatType(), True),
    StructField("nota_cloud", FloatType(), True),
    StructField("nota_tecnica", FloatType(), True),
    StructField("nota_geral", FloatType(), True),
    StructField("cod_cloud", IntegerType(), True),
    StructField("faltas", IntegerType(), True)
])

# Supondo que 'funcionario_df' é o seu DataFrame de funcionários já existente
# Vamos coletar as matrículas dos funcionários
matriculas_funcionarios = [row['matricula'] for row in funcionario_df.select('matricula').collect()]

# Função para gerar notas aleatórias
def gerar_nota():
    return round(random.uniform(0, 10), 1)

# Gerar registros para a tabela Notas, utilizando as matrículas existentes
dados_notas = []
for matricula in matriculas_funcionarios:
    nota_dominio = gerar_nota()
    nota_cloud = gerar_nota()
    nota_tecnica = gerar_nota()
    nota_geral = (nota_dominio + nota_cloud + nota_tecnica) / 3
    cod_cloud = random.randint(0, 4)
    faltas = random.randint(0, 10)

    dados_notas.append((matricula, nota_dominio, nota_cloud, nota_tecnica, nota_geral, cod_cloud, faltas))

# Criar DataFrame da tabela Notas com os dados
notas_df = spark.createDataFrame(dados_notas, notas_schema)
notas_df.show()

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType

# Iniciar sessão Spark
spark = SparkSession.builder.appName("PerguntasDatabase").getOrCreate()

# Definir o esquema para a tabela Perguntas
perguntas_schema = StructType([
    StructField("Azure", IntegerType(), True),
    StructField("ControlM", IntegerType(), True),
    StructField("AWS", IntegerType(), True),
    StructField("Maestro", IntegerType(), True),
    StructField("Data_Engineer", IntegerType(), True),
    StructField("Machine_learning", IntegerType(), True),
    StructField("SRE", IntegerType(), True),
    StructField("Pyspark", IntegerType(), True),
    StructField("Databricks", IntegerType(), True)
])

# Criar a tabela Perguntas com IDs associados (exemplo fictício)
perguntas_data = [(1, 2, 3, 4, 5, 6, 7, 8, 9)]
perguntas_df = spark.createDataFrame(perguntas_data, perguntas_schema)
perguntas_df.show()


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

# Iniciar sessão Spark
spark = SparkSession.builder.appName("DominioTable").getOrCreate()

# Definir o esquema para a tabela dominio
dominio_schema = StructType([
    StructField("dominio", StringType(), True)
])

# Dados da tabela dominio
dominio_data = [
    ("ROR",),
    ("BMA",),
    ("COE",),
    ("DHT",),
    ("CORE",)
]

# Criar DataFrame da tabela dominio com os dados
dominio_df = spark.createDataFrame(dominio_data, dominio_schema)
dominio_df.show()


# COMMAND ----------

from pyspark.sql import SparkSession, Row
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("QuestionsAndAnswers").getOrCreate()

# Lista de perguntas
perguntas_azure = [
    {"id": 1, "pergunta": "O que é Azure?", "opcoes": ["A) Um serviço de computação em nuvem da Microsoft", "B) Um sistema operacional", "C) Um banco de dados", "D) Uma linguagem de programação", "E) Um dispositivo móvel"], "resposta_correta": "A"},
    {"id": 2, "pergunta": "Qual serviço Azure permite o gerenciamento de máquinas virtuais?", "opcoes": ["A) Azure Functions", "B) Azure DevOps", "C) Azure Virtual Machines", "D) Azure Cosmos DB", "E) Azure Kubernetes Service"], "resposta_correta": "C"},
    {"id": 3, "pergunta": "Que serviço Azure é usado para hospedar bancos de dados SQL?", "opcoes": ["A) Azure Blobs", "B) Azure SQL Database", "C) Azure DevOps", "D) Azure Table Storage", "E) Azure Active Directory"], "resposta_correta": "B"},
    {"id": 4, "pergunta": "O Azure Active Directory é usado para:", "opcoes": ["A) Hospedagem de aplicações", "B) Análise de dados", "C) Gerenciamento de identidades", "D) Armazenamento de objetos", "E) Orquestração de contêineres"], "resposta_correta": "C"},
    {"id": 5, "pergunta": "Qual ferramenta Azure oferece serviços de análise em tempo real?", "opcoes": ["A) Azure SQL Data Warehouse", "B) Azure Logic Apps", "C) Azure Data Lake Analytics", "D) Azure Stream Analytics", "E) Azure Machine Learning"], "resposta_correta": "D"},
    {"id": 6, "pergunta": "Qual serviço Azure é melhor para a implementação de pipelines de CI/CD?", "opcoes": ["A) Azure Repos", "B) Azure Boards", "C) Azure Pipelines", "D) Azure Monitor", "E) Azure Security Center"], "resposta_correta": "C"},
    {"id": 7, "pergunta": "Azure Cosmos DB é conhecido por ser:", "opcoes": ["A) Um serviço de banco de dados SQL", "B) Uma plataforma de aprendizado de máquina", "C) Um serviço de banco de dados NoSQL", "D) Um serviço de análise de dados", "E) Um serviço de gerenciamento de API"], "resposta_correta": "C"},
    {"id": 8, "pergunta": "Qual serviço do Azure é usado para automação de processos?", "opcoes": ["A) Azure Automation", "B) Azure Functions", "C) Azure Logic Apps", "D) Azure Machine Learning", "E) Azure Virtual Network"], "resposta_correta": "A"},
    {"id": 9, "pergunta": "Azure Virtual Network é usado para:", "opcoes": ["A) Hospedar aplicativos web", "B) Armazenar dados não estruturados", "C) Criar redes privadas na nuvem", "D) Gerenciar bancos de dados", "E) Monitorar aplicativos"], "resposta_correta": "C"},
    {"id": 10, "pergunta": "Para que é usado o Azure Blob Storage?", "opcoes": ["A) Armazenamento de dados estruturados", "B) Hospedagem de sites estáticos", "C) Backup e recuperação de desastres", "D) Todos os anteriores", "E) Nenhuma das anteriores"], "resposta_correta": "D"}
]


# COMMAND ----------

from pyspark.sql.functions import col, coalesce, lit, round
from pyspark.sql import SparkSession
from pyspark.sql import Row

# Verificar se a coluna "faltas" existe em funcionario_df e removê-la
if "faltas" in funcionario_df.columns:
    funcionario_df = funcionario_df.drop("faltas")
if "nota_media" in funcionario_df.columns:
    funcionario_df = funcionario_df.drop("nota_media")


# Realizar o join entre funcionario_df e notas_df usando a coluna "matricula"
funcionario_notas_df = funcionario_df.join(notas_df, "matricula", "left")

# Verificar a existência das colunas de notas em notas_df e calcular a nota_media
if set(["nota_dominio", "nota_cloud", "nota_tecnica", "nota_geral", "cod_cloud"]).issubset(notas_df.columns):
    funcionario_notas_df = funcionario_notas_df.withColumn(
        "nota_media",
        round(
            (
                coalesce(col("nota_dominio"), lit(0)) +
                coalesce(col("nota_cloud"), lit(0)) +
                coalesce(col("nota_tecnica"), lit(0)) +
                coalesce(col("nota_geral"), lit(0)) +
                coalesce(col("cod_cloud"), lit(0))
            ) / 5, 2
        )
    )
else:
    funcionario_notas_df = funcionario_notas_df.withColumn("nota_media", lit(None))

# Adicionar ou atualizar a coluna "faltas"
funcionario_notas_df = funcionario_notas_df.withColumn(
    "faltas",
    coalesce(col("faltas"), lit(0))
)

# Selecionar as colunas relevantes para o funcionario_df atualizado
funcionario_df = funcionario_notas_df.select(
    funcionario_df["*"],  # Todas as colunas originais de funcionario_df
    "nota_media",         # A média das notas, agora arredondada
    "faltas"              # As faltas, atualizadas ou recém-criadas
)
# Criando a nova linha como um DataFrame
nova_linha = [Row(Nome="Eduardo", matricula="T379632", dominio="cartoes", cargo="Especialista 5", nivel="avancado", email="eduardo@f1rst.com.br", numero_lider=6, sigla="COE", nota_media="9.0", faltas="2")]
novo_df = spark.createDataFrame(nova_linha)

# Unindo o novo DataFrame com o funcionario_df existente
funcionario_df = funcionario_df.union(novo_df)
# Mostrar o DataFrame atualizado
funcionario_df.show()


# COMMAND ----------

from pyspark.sql.functions import when

# Atualizar a coluna "nivel" com base na "nota_media"
funcionario_df = funcionario_df.withColumn(
    "nivel",
    when(
        (col("nota_media") >= 0) & (col("nota_media") <= 3.1), "basico"
    ).when(
        (col("nota_media") > 3.1) & (col("nota_media") <= 7.0), "medio"
    ).when(
        (col("nota_media") > 7.0) & (col("nota_media") <= 10), "avancado"
    ).otherwise(funcionario_df["nivel"])  # Mantém o valor existente caso não se encaixe nas condições
)

# Mostrar o DataFrame atualizado
funcionario_df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC import logging
# MAGIC
# MAGIC # Configurando o logger
# MAGIC logging.basicConfig(level=logging.INFO)
# MAGIC logger = logging.getLogger(__name__)
# MAGIC
# MAGIC def log_dataframe_info(df, df_name):
# MAGIC     """Loga as primeiras linhas de um DataFrame Spark."""
# MAGIC     # Coletando as primeiras linhas do DataFrame em formato de string
# MAGIC     df_info = df._jdf.showString(10, 20, False)  # Ajuste os parâmetros conforme necessário
# MAGIC     logger.info(f"\nDataFrame '{df_name}':\n{df_info}")
# MAGIC
# MAGIC # Exemplo de uso com seus DataFrames
# MAGIC log_dataframe_info(funcionario_df, "funcionario_df")
# MAGIC log_dataframe_info(funcionario_lider_df, "funcionario_lider_df")
# MAGIC log_dataframe_info(lider_df, "lider_df")
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, rand, udf
from pyspark.sql.types import StringType, IntegerType, LongType
import random

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("CriarTabela").enableHiveSupport().getOrCreate()

# Definir o esquema com base na estrutura fornecida
schema = StructType([
    StructField("Matricula", StringType(), True),
    StructField("ID_Pergunta", LongType(), True),
    StructField("Resultado", LongType(), True)
])

# Função para gerar o ID da Pergunta
def gerar_id_pergunta():
    numero = random.randint(0, 100)
    letra = random.choice(["de", "ml", "az", "cm", "ms"])
    return f"{numero}{letra}"

# Registra a função UDF
gerar_id_pergunta_udf = udf(gerar_id_pergunta, StringType())

# Função para gerar o Resultado
def gerar_resultado():
    return random.choice([1, 2])

# Registra a função UDF
gerar_resultado_udf = udf(gerar_resultado, IntegerType())

repeticoes_df = spark.range(10).withColumnRenamed("id", "repeticao")

# Criar um novo DataFrame com os dados necessários
df_populado = funcionario_df.crossJoin(repeticoes_df).select(
    col("matricula"),
    gerar_id_pergunta_udf().alias("ID_Pergunta"),
    gerar_resultado_udf().alias("Resultado")
)

# Sobrescrever a tabela com os novos dados
df_populado.write.mode("overwrite").saveAsTable("resultados")

# COMMAND ----------

df_populado.display()

# COMMAND ----------

funcionario_df.printSchema()

# COMMAND ----------

