# Databricks notebook source
from pyspark.sql import SparkSession

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("Criando_df_notas").getOrCreate()

# Lista com os DataFrames e os nomes das tabelas correspondentes
dfs_e_tabelas = [
    (df_notas, "df_notas"),
    (df_final, "df_final")
]

for df, tabela in dfs_e_tabelas:
    # Verifica se a tabela existe
    if spark._jsparkSession.catalog().tableExists(tabela):
        # Se a tabela existir, faça o insert into
        df.write.mode("append").format("parquet").insertInto(tabela)
    else:
        # Verifica se o diretório associado à tabela existe
        path = f"dbfs:/user/hive/warehouse/{tabela}"
        if dbutils.fs.ls(path):
            # Se o diretório existir, remove o diretório
            dbutils.fs.rm(path, recurse=True)
        # Cria a tabela com os dados do DataFrame após remover o diretório existente
        df.write.mode("overwrite").format("parquet").saveAsTable(tabela)

# COMMAND ----------

# Lista com os nomes das tabelas para ler
nomes_tabelas = ["df_notas", "df_final"]

for nome_tabela in nomes_tabelas:
    # Ler a tabela para um DataFrame
    df = spark.table(nome_tabela)
    
    # Exibir os primeiros registros do DataFrame para verificar
    print(f"Conteúdo da tabela {nome_tabela}:")
    df.display()