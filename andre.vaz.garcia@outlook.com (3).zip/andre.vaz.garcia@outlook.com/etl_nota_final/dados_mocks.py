# Databricks notebook source
# MAGIC %md
# MAGIC ##Nomes Brasileiros

# COMMAND ----------

nomes_brasileiros = [
    "Ana", "Luiz", "Carlos", "Mariana", "Paula", "Rafael", "Julia", "Roberto", "Fernanda", "Gabriel",
    "Isabela", "Diego", "Amanda", "José", "Camila", "Gustavo", "Larissa", "Felipe", "Luciana", "Daniel",
    "Carolina", "Thiago", "Patrícia", "Pedro", "Vanessa", "Bruno", "Natália", "Alexandre", "Raquel", "Vinícius",
    "Beatriz", "Leonardo", "Lúcia", "Ricardo", "Luana", "Fábio", "Tatiana", "André", "Mônica", "Marcelo",
    "Ana Carolina", "Guilherme", "Renata", "Antônio", "Priscila", "João", "Carla", "Fernando", "Roberta",
    "Márcio", "Débora", "Vitor", "Aline", "Jorge", "Viviane", "Raul", "Juliana", "Eduardo", "Cíntia",
    "Lucas", "Elaine", "Marcos", "Letícia", "Luiz Fernando", "Simone", "Paulo", "Bianca", "Adriano", "Mara",
    "Marcela", "Cláudio", "Renan", "Sandra", "Matheus", "Érika", "Hugo", "Nathália", "Rogério", "Cristiane",
    "Sérgio", "Lorena", "Rodrigo", "Andressa", "Caio", "Fernanda", "Roberto", "Taís", "William", "Talita",
    "Alex", "Michele", "Rafaela", "Marco", "Valéria", "Nilton", "Alessandra", "Junior", "Silmara", "Pablo",
    "Cecília", "Henrique", "Monique", "Wagner", "Aurora", "Davi", "Luiza", "Raphael", "Clara", "Giovanni",
    "Elen", "Jonas", "Cassia", "Igor", "Solange", "Fernando", "Ingrid", "Robson", "Caroline", "Arthur",
    "Tatiane", "Ivan", "Patrícia", "Diego", "Renata", "Vinícius", "Sara", "José", "Bruna", "Felipe",
    "Elaine", "Luís", "Lígia", "Wellington", "Renata", "Fabrício", "Laura", "Geraldo", "Tábata", "Ramon",
    "Luana", "Santiago", "Alana", "Henrique", "Marina", "Matheus", "Márcia", "Lucas", "Jaqueline", "Gustavo",
    "Gabriela", "Juliano", "Roberta", "Francisco", "Mariana", "Rafael", "Nathalia", "João", "Bianca", "Paulo",
    "Larissa", "Leonardo", "Tatiana", "André", "Carla", "Rodrigo", "Daniela", "Guilherme", "Renata", "Antônio",
    "Vanessa", "Felipe", "Fernanda", "Vitor", "Sara", "Márcio", "Cíntia", "Eduardo", "Lúcia", "Fábio",
    "Priscila", "Jorge", "Letícia", "Raul", "Érika", "Marcos", "Elaine", "Luiz Fernando", "Talita", "Lucas",
    "Mara", "Paulo", "Simone", "Adriano", "Juliana", "Hugo", "Aline", "Rogério", "Nathália", "Caio",
    "Valéria", "Roberto", "Michele", "William", "Silmara", "Alex", "Monique", "Rafaela", "Alessandra", "Marco",
    "Cecília", "Junior", "Clara", "Pablo", "Elen", "Henrique", "Cassia", "Davi", "Solange", "Giovanni",
    "Ingrid", "Jonas", "Caroline", "Igor", "Tatiane", "Arthur", "Patrícia", "Ivan", "Renata", "Diego",
    "Sara", "Vinícius", "Bruna", "José", "Elaine", "Felipe", "Lígia", "Luís", "Renata", "Wellington",
    "Laura", "Fabrício", "Tábata", "Geraldo", "Luana", "Ramon", "Alana", "Santiago", "Marina", "Henrique",
    "Jaqueline", "Matheus", "Gabriela", "Lucas", "Roberta", "Gustavo", "Mariana", "Juliano", "Nathalia",
    "Francisco", "Bianca", "Rafael", "Larissa", "João", "Tatiana", "Paulo", "Daniela", "Leonardo", "Renata",
    "André", "Carla", "Rodrigo", "Fernanda", "Guilherme", "Vanessa", "Antônio", "Sara", "Felipe", "Cíntia",
    "Vitor", "Lúcia", "Márcio", "Priscila", "Eduardo", "Letícia", "Fábio", "Érika", "Jorge", "Elaine",
    "Raul", "Talita", "Marcos", "Simone", "Luiz Fernando", "Juliana", "Lucas", "Mara", "Adriano", "Aline",
    "Hugo", "Silmara", "Rogério", "Monique", "Caio", "Michele", "Valéria", "William", "Roberto", "Alex",
    "Sara", "Junior", "Bruna", "Marco", "Renata", "Alessandra", "Ivan", "Cecília", "Diego", "Clara",
    "Vinícius", "Elen", "Felipe", "Henrique", "Renata", "Davi", "Lígia", "Giovanni", "Wellington", "Ingrid",
    "Jonas", "Laura", "Igor", "Tábata", "Arthur", "Ramon", "Patrícia", "Santiago"
    ]

# COMMAND ----------

