# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.types import LongType

# Passo 1: Identificar matrículas presentes em ambos os DataFrames
matriculas_comuns = df_notas.select("matricula").intersect(funcionario_df.select("matricula"))

# Passo 2: Filtrar df_notas e calcular a nova nota
df_notas_filtrado = df_notas.join(matriculas_comuns, "matricula", "inner")\
    .withColumn("errado", F.coalesce("errado", F.lit(0)))\
    .withColumn("nova_nota", F.col("correto") - F.col("errado"))

# Agregar as notas por matrícula
df_agregado = df_notas_filtrado.groupBy("matricula")\
    .agg(F.sum("nova_nota").alias("soma_nova_nota"))

# Passo 3: Preparar funcionario_df e atualizar a nota média
funcionario_df = funcionario_df.withColumn("nota_media_long", F.col("nota_media").cast(LongType()))

# Juntar os DataFrames para atualizar a nota média
funcionario_atualizado = funcionario_df.join(df_agregado, "matricula", "left_outer")\
    .withColumn("nota_media_atualizada", 
                F.when(F.col("soma_nova_nota").isNull(), F.col("nota_media_long"))
                 .otherwise((F.col("nota_media_long") + F.col("soma_nova_nota")) / 2))\
    .drop("nota_media", "nota_media_long", "soma_nova_nota")\
    .withColumnRenamed("nota_media_atualizada", "nota_media")

# Passo 4: Salvar como tabela
funcionario_atualizado.write.mode("overwrite").saveAsTable("ts_tb_funcionarios_nota")
