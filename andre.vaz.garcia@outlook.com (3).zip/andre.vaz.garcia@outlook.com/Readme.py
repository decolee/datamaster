# Databricks notebook source
# MAGIC %md
# MAGIC ##Readme
# MAGIC ######Para informações do código e explicações, ir para o arquivo markdown "DOCUMENTAÇÃO_EXPLICADA".

# COMMAND ----------

caminho_do_notebook = "/87582080302018/command/87582080302019"

# URL base do Databricks
base_url = "https://community.cloud.databricks.com/?o=2218444736488697"

# Construindo o link para o notebook
link_do_notebook = f'<a href="{base_url}/#notebook{caminho_do_notebook}" target="_blank">Link para o Notebook</a>'

# Exibindo o link
displayHTML(link_do_notebook)


# COMMAND ----------

# MAGIC %md
# MAGIC # Projeto Data Master - 2024
# MAGIC
# MAGIC ## Descrição
# MAGIC Funcionalidades Principais
# MAGIC 1. Criação de Tabelas Mockadas
# MAGIC O projeto inclui um módulo dedicado à geração de tabelas com dados fictícios, demonstrando a capacidade de simular cenários reais para teste e desenvolvimento. Este processo é realizado através de:
# MAGIC
# MAGIC Uso de Python e PySpark: Demonstração de habilidades avançadas no uso de Python e PySpark para a criação de dados mockados, explorando diversas funções e técnicas de programação.
# MAGIC Aplicação de Diferentes Abordagens: Implementação de múltiplas metodologias para a geração de dados, incluindo simulação de dados transacionais, dados de clientes, e registros de eventos, visando a diversidade e complexidade dos cenários de teste.
# MAGIC 2. Criação e Atualização de ETL
# MAGIC Desenvolvimento de pipelines de ETL (Extract, Transform, Load) que não só extraem e transformam dados de várias fontes, mas também atualizam os conjuntos de dados em tempo real ou conforme programado. Isso inclui:
# MAGIC
# MAGIC Extração de Dados: Coleta de dados de fontes diversas, incluindo arquivos JSON, bancos de dados e APIs externas.
# MAGIC Transformação: Aplicação de técnicas de limpeza, normalização, e enriquecimento de dados utilizando funções customizadas em Python e operações de DataFrame no PySpark.
# MAGIC Carregamento: Atualização de tabelas em sistemas de armazenamento de dados distribuídos, como Delta Lake, garantindo a integridade e a disponibilidade dos dados para análise e processamento subsequente.
# MAGIC
# MAGIC 3. Sistema de Perguntas e Respostas com Pontuação
# MAGIC Implementação de um sistema interativo de QA (Question and Answer) que permite a criação de perguntas e coleta de respostas com um esquema de pontuação, onde:
# MAGIC
# MAGIC Criação de Perguntas: As perguntas podem ser geradas manualmente por usuários ou automaticamente através de algoritmos de IA, que analisam conteúdos de documentos PDF ou vídeos do YouTube para extrair tópicos relevantes.
# MAGIC Coleta e Avaliação de Respostas: As respostas são coletadas através da interface do sistema e avaliadas automaticamente ou manualmente, atribuindo pontuações com base na precisão e relevância.
# MAGIC Atualização Dinâmica: O sistema é projetado para atualizar continuamente a base de dados de perguntas e respostas, refletindo novos aprendizados e feedback dos usuários.
# MAGIC Este módulo destaca a integração eficaz de técnicas de processamento de linguagem natural (PLN) e análise de texto para a geração e avaliação de conteúdo interativo, promovendo um ambiente dinâmico e educativo.
# MAGIC
# MAGIC 4. Utilização de Shell Scripts no Databricks
# MAGIC O projeto faz uso extensivo de Shell Scripts para automatizar tarefas recorrentes na plataforma Databricks, incluindo:
# MAGIC
# MAGIC Automação de Workflows: Execução de scripts para automatizar a criação de clusters, instalação de bibliotecas, e configuração de ambientes, facilitando a replicabilidade e eficiência dos processos.
# MAGIC Integração e Deploy: Utilização de scripts para integrar com serviços externos, realizar deploy de modelos de machine learning e atualizar pipelines de dados, garantindo a agilidade na entrega e manutenção do projeto.
# MAGIC
# MAGIC 5. Utilização de Kafka para Monitoramento e Logs
# MAGIC A integração com Apache Kafka é uma parte crucial do projeto, permitindo:
# MAGIC
# MAGIC Streaming de Dados em Tempo Real: Captura e processamento de dados em tempo real através de tópicos Kafka, possibilitando análises e reações imediatas a eventos e mudanças nos dados.
# MAGIC Print de Logs e Atualizações: Configuração de consumidores Kafka para monitorar logs de execução e atualizações de dados, facilitando o debugging, a análise de performance e a auditoria de segurança. Isso inclui o tracking de eventos críticos, erros e métricas operacionais importantes.
# MAGIC ## Configuração do Ambiente
# MAGIC Instruções sobre como configurar o ambiente necessário para rodar o projeto, incluindo instalação de dependências, variáveis de ambiente, e quaisquer outros pré-requisitos.
# MAGIC
# MAGIC ### Pré-requisitos
# MAGIC - Python >= 3.5.0
# MAGIC - Databricks Runtime Version: 9.0
# MAGIC - Outras dependências ML cluster.
# MAGIC
# MAGIC ### Instalação
# MAGIC Selecionar ML databricks cluster.

# COMMAND ----------

# MAGIC %md
# MAGIC Como Executar
# MAGIC Instruções detalhadas sobre como executar o projeto, incluindo exemplos de comandos.

# COMMAND ----------

# MAGIC %md
# MAGIC Arquitetura do Projeto
# MAGIC Descrição da arquitetura do projeto, incluindo diagramas (se aplicável) e descrição dos componentes principais.
# MAGIC
# MAGIC Uso
# MAGIC Exemplos de como usar o projeto, incluindo snippets de código e explicações sobre as funcionalidades.
# MAGIC
# MAGIC Contribuição
# MAGIC Instruções para contribuir com o projeto, incluindo diretrizes de código, processo para submeter pull requests e outras convenções de contribuição.
# MAGIC
# MAGIC Licença
# MAGIC Informações sobre a licença sob a qual o projeto é distribuído.
# MAGIC
# MAGIC Contato
# MAGIC Informações de contato dos mantenedores do projeto, incluindo e-mail, redes sociais, etc.
# MAGIC
# MAGIC FAQ
# MAGIC Seção de perguntas frequentes sobre o projeto.
# MAGIC
# MAGIC Troubleshooting
# MAGIC Dicas e soluções para problemas comuns encontrados durante a configuração ou execução do projeto.

# COMMAND ----------

# MAGIC %md
# MAGIC Utilizar o Apache Kafka em uma análise de atualização de tabela pode ser extremamente vantajoso por diversas razões, especialmente em cenários que exigem processamento de grandes volumes de dados em tempo real, alta disponibilidade e escalabilidade. Aqui estão alguns motivos pelos quais o Kafka é frequentemente escolhido para essas tarefas:
# MAGIC
# MAGIC 1. Processamento em Tempo Real
# MAGIC O Kafka é projetado para processamento de fluxo de dados em tempo real. Isso é crucial para análises que dependem da atualização de tabelas com dados que estão constantemente mudando. Com o Kafka, é possível capturar e processar essas mudanças quase instantaneamente, permitindo que as análises reflitam o estado atual dos dados.
# MAGIC
# MAGIC 2. Durabilidade e Confiabilidade
# MAGIC O Kafka garante a durabilidade dos dados através do armazenamento de mensagens em discos e replicação entre os brokers. Isso significa que, mesmo em caso de falhas, os dados não são perdidos e podem ser recuperados, garantindo a integridade das atualizações de tabela.
# MAGIC
# MAGIC 3. Alta Throughput
# MAGIC O Kafka é capaz de suportar um alto volume de mensagens sem comprometer o desempenho. Isso o torna ideal para cenários onde as tabelas são atualizadas com uma grande quantidade de dados em curtos intervalos de tempo.
# MAGIC
# MAGIC 4. Escalabilidade
# MAGIC O Kafka é projetado para ser escalável horizontalmente, o que significa que você pode aumentar a capacidade de processamento adicionando mais servidores (brokers) ao cluster do Kafka conforme necessário. Isso permite que o sistema cresça de acordo com as demandas de análise de atualização de tabela, sem grandes dificuldades.
# MAGIC
# MAGIC 5. Desacoplamento de Sistemas
# MAGIC O Kafka atua como um sistema de mensageria que desacopla produtores de dados dos consumidores. Isso significa que as fontes de dados podem publicar atualizações nas tabelas sem ter conhecimento direto das análises ou processos que consomem esses dados. Esse desacoplamento facilita a manutenção e a evolução dos sistemas.
# MAGIC
# MAGIC 6. Flexibilidade de Consumo de Dados
# MAGIC Os consumidores podem ler dados do Kafka a partir de um ponto específico do fluxo de mensagens, permitindo análises complexas que requerem a revisão de históricos de dados ou o processamento de janelas temporais específicas.
# MAGIC
# MAGIC 7. Integração com Ferramentas de Processamento de Dados
# MAGIC O Kafka se integra bem com diversas ferramentas e frameworks de processamento de dados, como Apache Spark, Apache Flink e outros, permitindo análises avançadas e atualizações de tabela baseadas em lógicas complexas.
# MAGIC
# MAGIC 8. Resiliência a Falhas
# MAGIC Com mecanismos de replicação e particionamento, o Kafka oferece alta disponibilidade e resiliência a falhas, essenciais para sistemas críticos de análise de dados em tempo real.
# MAGIC
# MAGIC Em resumo, o Kafka é uma escolha robusta para análise de atualização de tabela em cenários que exigem alto desempenho, escalabilidade, e confiabilidade. Seu design focado em streaming de dados torna-o ideal para capturar e processar atualizações de dados em tempo real, fornecendo insights atualizados e permitindo decisões rápidas baseadas em dados.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Modo de uso do código:
# MAGIC ##O projeto é dividido em três principais partes:
# MAGIC A) Criação de tabelas ETL e QA de perguntas consumindo as tabelas com cruzamento por meio de matrícula.
# MAGIC
# MAGIC B) Criação de perguntas utilizando inteligência artificial, treinamento feito por meio de frameworks e API.
# MAGIC
# MAGIC C) Acompanhamento em realtime criando histórico de logs de novas mudanças e acompanhamento das tabelas.

# COMMAND ----------

# MAGIC %md
# MAGIC ##Criação de tabelas ETL e QA
# MAGIC
# MAGIC ####A criação das tabelas é feita por meio de diversos códigos difentes, utilizando varias abordagens para fazer dados mocks "fictícios" e gerar as tabelas, fiz uma estrutura de tabelas coorelacionadas que são feitas da seguinte forma:
# MAGIC
# MAGIC #####Notebook create_table
# MAGIC
# MAGIC ######Após criar diversos dataframes, e a estrutura lógica que respeita a ordem lider > funcionário > nota, onde são atribuidos pelas PK e FK (sigla, numero_lider e matrícula).
# MAGIC
# MAGIC Para criar essas tabelas, elas passam por diversos ETLs diferentes, e por fim os dataframes se tornam nas três principais tabelas finais:
# MAGIC - líder
# MAGIC - funcionário
# MAGIC - resultados

# COMMAND ----------

# MAGIC %md
# MAGIC ##Criação de tabelas perguntas:
# MAGIC ####Para criar as tabelas de perguntas, foi feito uma abordagem diferente, as perguntas são separadas em 3 tipos diferentes no notebook create_table_perguntas. Essas perguntas foram divididas em três níveis diferentes:
# MAGIC - Básico
# MAGIC - Intermediário
# MAGIC - Avançado
# MAGIC
# MAGIC O notebook faz a leitura dos arquivos em formato Json, após isso, faz o tratamento "setando" um schema para as perguntas dentro do arquivo, seguindo a ordem de escolha do tema abordado de cada pergunta, para essa poc os temas abordados foram:
# MAGIC
# MAGIC - Machine Learning.
# MAGIC - Azure.
# MAGIC - Data Engineer.
# MAGIC - Maestro.
# MAGIC - Control-M.
# MAGIC
# MAGIC No final do código, é gerado as tabelas de cada assunto com seu nível de dificuldade.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ####QA TESTER
# MAGIC notebook %run ./qa_teste
# MAGIC
# MAGIC #####Após criar as tabelas de necessárias (funcionários, notas, lider, perguntas) o notebook qa_teste é chamado. O código apresenta o print sorteado de 3 matrículas sendo sempre uma básica, intermediária e avançada.
# MAGIC ######Ao escolher a matricula dentro do input, as perguntas referentes a matrícula irá aparecer no formato de multipla escolha.
# MAGIC Apos selecionar as respostas, uma breve resposta de acerto ou erro irá printar na tela. 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Notebooks ./app_3 e ./app_4
# MAGIC #####Após o QA respondido, as proximas chamadas de app são referentes a diversos tratamentos de etl, resumo de notas, atualização dos dados como "append" nas tabelas de notas e funcionários e por fim save da tabela final.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Notebook ./app_5
# MAGIC ######Nos notebook app_5, chama dois outros notebooks, create_df_siglas e analises_e_graficos, a intenção foi mostrar como segmentar os funcionários por sigla, após fazer a segmentação foi criado um notebook com o nome "analises_e_graficos" que possui um exemplo básico do uso dos dados para analytics, devido o projeto ser focado em engenharia de dados, não foi focado um trabalho tão aprofundado em análise de dados. Para isso foi feito uma análise simples de Nota Média x Faltas por Domínio.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Notebook ./app_6
# MAGIC ###### Notebook que faz a atualização final nas tabelas e salva no DBFS, por fim é rodado um trabalho de data_masking para mascarar as informações caso as informações precisem ser divulgadas em algum lugar.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Notebook ./lider_view
# MAGIC ######Notebook que apresenta a visão de um lider, fazendo um filtro nas mostragens por matrícula, ou seja, o lider que é da sigla ROR não consegue ver os funcionários e notas da sigla COE, foi feito para mostrar algumas observações de tempview que é possivel serem feitas com o Databricks.

# COMMAND ----------

# MAGIC %md
# MAGIC #LLM criar perguntas com IA.

# COMMAND ----------

# MAGIC %md
# MAGIC ##Documentação: Processamento de Arquivos com LLM GEN AI
# MAGIC ###Introdução
# MAGIC #####Este documento descreve a implementação e funcionalidades de dois processos distintos de transformação de dados utilizando LLM GEN AI, focados na análise de arquivos PDF e vídeos MP4. Ambos os processos são realizados dentro da pasta llm_sandbox_config e têm como objetivo final a conversão de diferentes fontes de dados em texto, permitindo a realização de operações de ETL (Extract, Transform, Load) para posterior análise e aplicação em machine learning.
# MAGIC
# MAGIC ###Análise de Documentos PDF
# MAGIC ####Processo
# MAGIC #####O primeiro processo envolve a manipulação de arquivos no formato PDF. A sequência de operações é a seguinte:
# MAGIC
# MAGIC - Leitura do PDF: Inicialmente, o arquivo PDF é lido pelo sistema.
# MAGIC
# MAGIC - Conversão para Texto: Após a leitura, o conteúdo do arquivo é convertido em texto puro.
# MAGIC
# MAGIC - Tokenização: O texto é então tokenizado, dividindo-o em unidades menores para análise.
# MAGIC
# MAGIC - Embeddings: Com o texto tokenizado, são gerados embeddings, que são representações numéricas do texto, facilitando a análise computacional.
# MAGIC
# MAGIC - Criação da Base de Análise: Utilizando o texto e seus embeddings, é construída uma base de dados específica para análises e aplicações de machine learning.
# MAGIC
# MAGIC ###Análise de Vídeos MP4
# MAGIC ####Processo
# MAGIC #####O segundo processo foca na análise de vídeos no formato MP4, utilizando o framework LangChain para facilitar a extração e transformação de dados:
# MAGIC
# MAGIC - Seleção do Vídeo: Primeiramente, um vídeo é selecionado para análise.
# MAGIC
# MAGIC - Transcrição do Áudio: O áudio do vídeo selecionado é transcrita para texto, convertendo falas em texto legível.
# MAGIC
# MAGIC - Geração de Perguntas: Utilizando a API da OpenAI, são geradas perguntas baseadas nos dados analisados do vídeo, enriquecendo a base de dados com informações relevantes.
# MAGIC
# MAGIC ###Objetivo Comum
# MAGIC #####Embora os processos lidem com tipos diferentes de entrada (documentos PDF e vídeos MP4), ambos convergem para o mesmo objetivo: transformar uma fonte de dados bruta em texto analisável. Esse texto passa por uma série de etapas de processamento, incluindo tokenização, geração de embeddings, vetorização, divisão de dados, treinamento e interpretação, culminando na geração de perguntas formatadas padrão. Estas perguntas são então incorporadas a um banco de dados específico, destinado ao armazenamento de questões para futuras consultas e análises.
# MAGIC
# MAGIC #####Esses processos exemplificam a capacidade da tecnologia LLM GEN AI de automatizar e otimizar a análise de diferentes formatos de dados, transformando informações não estruturadas em insights valiosos para aplicações de machine learning e bases de dados analíticas.

# COMMAND ----------

# MAGIC %md
# MAGIC ##Metodologia de ETL para Análise e Machine Learning
# MAGIC ####A metodologia aplicada nesses processos envolve etapas críticas de ETL (Extração, Transformação e Carga) para preparar os dados extraídos para análises de machine learning. A seguir, detalhamos cada etapa aplicada aos conteúdos de PDF e vídeo MP4, destacando a uniformidade do objetivo apesar da diversidade nas fontes de dados.
# MAGIC
# MAGIC ###Extração
# MAGIC ######PDF: A extração se dá pela leitura do conteúdo do arquivo PDF, identificando e isolando o texto presente.
# MAGIC ######Vídeo MP4: Inicia-se com a seleção do vídeo seguida pela transcrição do áudio, transformando o conteúdo falado em texto.
# MAGIC ###Transformação
# MAGIC ######Tokenização: Independentemente da fonte, o texto extraído é tokenizado, o que envolve a divisão do texto em unidades menores (tokens) para facilitar a análise.
# MAGIC ######Geração de Embeddings: Os tokens são então convertidos em embeddings, representações vetoriais que capturam o significado semântico das palavras ou frases, essencial para processos de machine learning.
# MAGIC ######Vetorização: Esta etapa complementa a criação dos embeddings, organizando os dados textuais em formatos vetoriais adequados para análise computacional.
# MAGIC ######Splitting e Treinamento: O conjunto de dados é dividido em partes para treinamento e teste, permitindo que os modelos de machine learning aprendam e sejam validados de maneira eficaz.
# MAGIC ###Carga
# MAGIC ######Geração de Perguntas: Com base na análise dos dados transformados, são formuladas perguntas relevantes que sintetizam as informações contidas nos documentos PDF e vídeos MP4.
# MAGIC ######Alimentação do Banco de Dados de Perguntas: As perguntas geradas são então carregadas em um banco de dados específico, criando um repositório de questões baseadas nos dados analisados para consulta e uso futuro.
# MAGIC ###Considerações Finais
# MAGIC ######A utilização de LLM GEN AI para processar e analisar diferentes tipos de dados (documentos e vídeos) demonstra a versatilidade e eficácia dessa tecnologia na automação de processos de ETL. Ao transformar dados não estruturados em texto e realizar análises profundas para gerar perguntas inteligentes, esses processos não apenas enriquecem o banco de dados de perguntas mas também pavimentam o caminho para insights mais profundos e aplicações avançadas de machine learning.
# MAGIC
# MAGIC ######Essa abordagem integrada enfatiza a importância da preparação de dados, mostrando que, independentemente da fonte, é possível extrair, transformar e carregar dados de forma eficiente para criar bases sólidas para análise e aprendizado de máquina. Além disso, ressalta o potencial da automação e da inteligência artificial na otimização de processos de análise de dados, contribuindo significativamente para avanços em pesquisa, desenvolvimento e aplicação prática em diversos campos.

# COMMAND ----------

# MAGIC %md
# MAGIC #Análises com Kafka.

# COMMAND ----------

# MAGIC %md
# MAGIC ##Implementação do Apache Kafka no Projeto
# MAGIC ###Introdução
# MAGIC ####Este documento descreve a adoção do Apache Kafka em nosso projeto, destacando sua relevância no cenário atual de processamento de dados e a motivação por trás de sua escolha. O Kafka é uma plataforma distribuída de streaming que permite a publicação, subscrição, armazenamento e processamento de fluxos de registros em tempo real. Sua importância cresceu significativamente em arquiteturas modernas de dados, onde a capacidade de lidar com grandes volumes de dados em movimento se tornou crucial.
# MAGIC
# MAGIC ###Por Que Kafka?
# MAGIC ####Escalabilidade e Confiabilidade
# MAGIC O Kafka foi projetado para ser altamente escalável e confiável, capaz de suportar grandes volumes de dados sem perda de desempenho. Isso o torna uma escolha ideal para projetos que exigem alto throughput e baixa latência, características essenciais para o processamento e análise de dados em tempo real.
# MAGIC
# MAGIC ####Desacoplamento de Sistemas
# MAGIC O Kafka facilita o desacoplamento de sistemas de produção de dados (produtores) dos sistemas de consumo de dados (consumidores), permitindo que ambos operem de forma independente. Isso melhora significativamente a flexibilidade e a escalabilidade das arquiteturas de sistemas.
# MAGIC
# MAGIC ####Processamento de Stream
# MAGIC Capacidades avançadas de processamento de stream, o Kafka permite a implementação de lógicas complexas de processamento de dados em tempo real, como filtragem, agregação e enriquecimento de dados, diretamente na pipeline de dados.
# MAGIC
# MAGIC ####Kafka no Projeto: Demonstração de Habilidades e Abordagens
# MAGIC Acompanhamento de Mudança de Tabela (Change Data Capture - CDC)
# MAGIC A utilização do Kafka no projeto visa demonstrar a habilidade de implementar soluções de Change Data Capture (CDC), uma técnica poderosa para capturar alterações em dados em bases de dados e propagá-las através do sistema. Isso permite a atualização em tempo real de sistemas downstream e habilita análises de dados mais ágeis e precisas.
# MAGIC
# MAGIC ####Saída de Logs
# MAGIC Além do CDC, a configuração do Kafka para a saída de logs é outro aspecto chave do projeto. Isso permite o monitoramento e análise de eventos do sistema em tempo real, oferecendo insights valiosos sobre o comportamento do sistema, detecção de padrões, alertas de segurança e muito mais.
# MAGIC
# MAGIC ####Benefícios e Impactos
# MAGIC Melhoria na Eficiência Operacional
# MAGIC A adoção do Kafka promove uma melhoria significativa na eficiência operacional, permitindo uma gestão de dados mais eficiente e reduzindo a latência na entrega de informações.
# MAGIC
# MAGIC ####Facilitação da Análise de Dados
# MAGIC Com o Kafka, o projeto se beneficia da possibilidade de análise de dados em tempo real, abrindo caminho para insights mais rápidos e decisões baseadas em dados atualizados.
# MAGIC
# MAGIC ####Demonstração de Competência Técnica
# MAGIC A escolha do Kafka também reflete um compromisso com a utilização de tecnologias avançadas e comprovadas, demonstrando competência técnica e a capacidade de implementar soluções modernas e eficazes.
# MAGIC
# MAGIC ###Conclusão
# MAGIC A implementação do Apache Kafka no projeto não apenas sublinha a importância dessa tecnologia no cenário de processamento de dados contemporâneo mas também ressalta a habilidade em aplicar abordagens avançadas para o acompanhamento de mudanças em tabelas e a saída de logs. Isso demonstra uma compreensão profunda das necessidades de arquiteturas de dados modernas e a capacidade de utilizar ferramentas de ponta para enfrentar desafios complexos de dados, alinhando-se perfeitamente com as melhores práticas e tendências atuais no campo da engenharia de dados.

# COMMAND ----------

