# Databricks notebook source
# Cell 1: Install the OpenAI and additional libraries
%pip install openai

# Cell 2: Import necessary libraries
import openai
import requests
import json

# Function to read PDF from Databricks File System
def read_pdf(file_path):
    # Assuming the PDF file is small enough to be handled in memory
    pdf_content = requests.get(file_path)
    return pdf_content.text

# Function to generate questions using ChatGPT API
def generate_questions(pdf_text):
    openai.api_key = 'your-api-key'  # Replace with your OpenAI API key

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Or the appropriate model you have access to
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"Generate 10 questions based on this text: {pdf_text}"}
        ]
    )

    return response.choices[0].message['content']  # Extract the generated questions

# Function to save questions to a JSON file in DBFS
def save_questions_to_json(questions, file_name):
    with open(f"/dbfs/{file_name}", "w") as file:
        json.dump(questions, file)

# Cell 3: Main execution
pdf_text = read_pdf("/dbfs/path_to_your_pdf.pdf")  # Replace with your PDF file path
questions = generate_questions(pdf_text)

# Saving the questions to a JSON file
save_questions_to_json(questions, "generated_questions.json")

print("Questions saved to generated_questions.json")


# COMMAND ----------

