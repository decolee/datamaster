# Databricks notebook source
perguntas_data_engineer_avancado = [
    {"id": "8de", "pergunta": "No contexto de Big Data, o que é 'Sharding'?", "opcoes": ["A) Encriptação de dados", "B) Divisão de um banco de dados em partes menores distribuídas", "C) Fusão de conjuntos de dados de diferentes fontes", "D) Criação de visualizações de dados", "E) Análise preditiva de dados"], "resposta_correta": "B"},
    {"id": "9de", "pergunta": "O que é um 'Data Lakehouse'?", "opcoes": ["A) Uma nova técnica de machine learning", "B) Um tipo de visualização de dados", "C) Um sistema que combina características de Data Lakes e Data Warehouses", "D) Um serviço de armazenamento de dados em nuvem", "E) Um framework de processamento de dados"], "resposta_correta": "C"},
    {"id": "10de", "pergunta": "O que é Apache Airflow?", "opcoes": ["A) Uma ferramenta de análise de dados", "B) Um sistema de gerenciamento de banco de dados", "C) Uma plataforma para processamento de dados em streaming", "D) Uma ferramenta de orquestração de workflows", "E) Um framework de machine learning"], "resposta_correta": "D"},
    {"id": "11de", "pergunta": "O que é particionamento de dados em um banco de dados?", "opcoes": ["A) Dividir um banco de dados em tabelas menores", "B) Criptografar dados sensíveis", "C) Distribuir dados em diferentes servidores", "D) Armazenar dados em diferentes formatos", "E) Separar dados em diferentes seções para otimizar consultas"], "resposta_correta": "E"},
    {"id": "12de", "pergunta": "Em um contexto de Big Data, o que significa o termo 'Lambda Architecture'?", "opcoes": ["A) Uma arquitetura para processamento de dados baseada em funções", "B) Um design de sistema para processamento tanto de dados em batch quanto em streaming", "C) Uma técnica de machine learning", "D) Um padrão de design de interfaces de usuário para aplicações de análise de dados", "E) Um modelo de segurança para bancos de dados"], "resposta_correta": "B"}
]


# COMMAND ----------

perguntas_maestro_avancado = [
    {"id": "1ms", "pergunta": "Qual é a principal função do Maestro no gerenciamento de workflows?", "opcoes": ["A) Monitoramento em tempo real dos processos", "B) Armazenamento de dados de processos", "C) Análise de desempenho dos workflows", "D) Orquestração e automação de processos de negócios", "E) Segurança e controle de acesso aos dados"], "resposta_correta": "D"},
    {"id": "2ms", "pergunta": "Como o Maestro lida com falhas em tarefas individuais dentro de um workflow?", "opcoes": ["A) Parando todo o workflow imediatamente", "B) Reagendando automaticamente a tarefa falhada", "C) Notificando os administradores para intervenção manual", "D) Executando um workflow alternativo pré-definido", "E) Ignorando a falha e continuando o processo"], "resposta_correta": "B"},
    {"id": "3ms", "pergunta": "Quais são os benefícios de usar o Maestro em ambientes de TI complexos?", "opcoes": ["A) Simplificação do gerenciamento de banco de dados", "B) Redução do uso de recursos computacionais", "C) Melhoria na colaboração entre equipes", "D) Automação e integração de processos de negócios", "E) Aumento da capacidade de armazenamento de dados"], "resposta_correta": "D"},
    {"id": "4ms", "pergunta": "Em que cenário o uso do Maestro é particularmente eficaz?", "opcoes": ["A) Na análise de dados em tempo real", "B) No gerenciamento de projetos de desenvolvimento de software", "C) Na orquestração de workflows de TI complexos", "D) Na gestão de recursos humanos", "E) No marketing digital e gestão de campanhas"], "resposta_correta": "C"},
    {"id": "5ms", "pergunta": "Como o Maestro auxilia na conformidade e auditoria de processos?", "opcoes": ["A) Fornecendo backups automáticos dos dados", "B) Através de relatórios detalhados de execução de tarefas", "C) Implementando controles de segurança rígidos", "D) Gerenciando permissões de usuário", "E) Oferecendo funcionalidades de criptografia de dados"], "resposta_correta": "B"}
]


# COMMAND ----------

perguntas_controlm_avancado = [
    {"id": "1cm", "pergunta": "Como o Control-M facilita a gestão de dependências em workflows complexos?", "opcoes": ["A) Através de uma interface gráfica intuitiva", "B) Usando scripts personalizados para cada tarefa", "C) Implementando políticas de segurança automatizadas", "D) Oferecendo análises preditivas de falhas", "E) Por meio de recursos de versionamento de workflows"], "resposta_correta": "A"},
    {"id": "2cm", "pergunta": "Qual é a principal vantagem do Control-M na automação de workflows de TI?", "opcoes": ["A) Redução de custos operacionais", "B) Aumento da segurança dos dados", "C) Melhoria na eficiência e redução de erros", "D) Facilidade de integração com outras plataformas", "E) Capacidade de processamento de dados em tempo real"], "resposta_correta": "C"},
    {"id": "3cm", "pergunta": "Como o Control-M lida com falhas em tarefas agendadas?", "opcoes": ["A) Enviando notificações imediatas para os administradores", "B) Tentando automaticamente a reexecução da tarefa", "C) Movendo a tarefa para uma fila de prioridade", "D) Gerando um relatório detalhado sobre a falha", "E) Parando todas as tarefas dependentes imediatamente"], "resposta_correta": "B"},
    {"id": "4cm", "pergunta": "Qual recurso do Control-M permite o gerenciamento centralizado de múltiplos jobs?", "opcoes": ["A) O painel de controle de recursos", "B) O módulo de agendamento avançado", "C) A ferramenta de gerenciamento de incidentes", "D) O console de operações", "E) O sistema de alertas em tempo real"], "resposta_correta": "D"},
    {"id": "5cm", "pergunta": "Em que aspecto o Control-M ajuda na conformidade regulatória?", "opcoes": ["A) Na criptografia de dados em trânsito", "B) Ao fornecer trilhas de auditoria detalhadas", "C) Implementando políticas de backup automatizadas", "D) Na gestão de acesso a dados sensíveis", "E) Oferecendo suporte a múltiplas legislações internacionais"], "resposta_correta": "B"}
]


# COMMAND ----------

perguntas_azure_avancado = [
    {"id": "1az", "pergunta": "No Azure, o que é Azure Resource Manager (ARM) e qual sua função principal?", "opcoes": ["A) Um serviço de armazenamento de dados", "B) Uma ferramenta de gerenciamento de identidade e acesso", "C) Uma interface para gerenciamento e organização de recursos", "D) Um sistema de monitoramento de rede", "E) Um serviço de computação em nuvem"], "resposta_correta": "C"},
    {"id": "2az", "pergunta": "Como o Azure Kubernetes Service (AKS) beneficia a orquestração de contêineres?", "opcoes": ["A) Através da automação de backups de dados", "B) Facilitando a escalabilidade e gestão de aplicações em contêineres", "C) Implementando políticas de segurança avançadas", "D) Oferecendo análise de dados em tempo real", "E) Gerenciando automaticamente a infraestrutura de rede"], "resposta_correta": "B"},
    {"id": "3az", "pergunta": "Qual é a principal vantagem de usar Azure Logic Apps?", "opcoes": ["A) Para análise aprofundada de dados", "B) Para automação de fluxos de trabalho e integração de aplicativos", "C) Para gerenciamento de banco de dados", "D) Para hospedagem de sites e aplicações web", "E) Para monitoramento e diagnóstico de aplicativos"], "resposta_correta": "B"},
    {"id": "4az", "pergunta": "O que diferencia o Azure SQL Database de um SQL Server tradicional?", "opcoes": ["A) Azure SQL é apenas para armazenamento de dados", "B) SQL Server oferece maior escalabilidade", "C) Azure SQL é um serviço de banco de dados como serviço totalmente gerenciado", "D) SQL Server é mais adequado para aplicações baseadas em nuvem", "E) Não há diferenças significativas entre os dois"], "resposta_correta": "C"},
    {"id": "5az", "pergunta": "Como o Azure Monitor melhora as operações de TI?", "opcoes": ["A) Aumentando a capacidade de armazenamento de dados", "B) Reduzindo custos operacionais", "C) Facilitando a comunicação entre diferentes plataformas", "D) Oferecendo insights abrangentes sobre o desempenho das aplicações", "E) Automatizando tarefas de desenvolvimento de software"], "resposta_correta": "D"}
]

# COMMAND ----------

perguntas_machine_learning_avancado = [
    {"id": "1ml", "pergunta": "O que é 'overfitting' em um modelo de Machine Learning?", "opcoes": ["A) Quando o modelo é muito simples para os dados", "B) Quando o modelo se ajusta demais aos dados de treino", "C) Falta de dados para treinar o modelo", "D) Uso de muitos algoritmos diferentes", "E) Treinamento insuficiente do modelo"], "resposta_correta": "B"},
    {"id": "2ml", "pergunta": "O que são 'features' em Machine Learning?", "opcoes": ["A) Erros no modelo", "B) As saídas do modelo", "C) Os inputs ou variáveis de entrada", "D) Os algoritmos utilizados", "E) Resultados das previsões"], "resposta_correta": "C"},
    {"id": "3ml", "pergunta": "Qual é a diferença entre 'classificação' e 'regressão' em Machine Learning?", "opcoes": ["A) Classificação lida com entradas numéricas e regressão com categóricas", "B) Não há diferença significativa", "C) Classificação é para previsões contínuas e regressão para discretas", "D) Classificação é para previsões discretas e regressão para contínuas", "E) Classificação usa somente dados não rotulados"], "resposta_correta": "D"},
    {"id": "4ml", "pergunta": "O que é um 'ensemble method' em Machine Learning?", "opcoes": ["A) Um único modelo robusto", "B) Um método para reduzir a dimensionalidade dos dados", "C) Uma combinação de diversos modelos para melhorar a performance", "D) Uma técnica para dividir o dataset", "E) Um método para acelerar o treinamento de modelos"], "resposta_correta": "C"},
    {"id": "5ml", "pergunta": "Como funciona o algoritmo K-means?", "opcoes": ["A) Divide o dataset em K grupos baseados em similaridades", "B) É um algoritmo de classificação supervisionada", "C) Usa redes neurais para agrupar os dados", "D) É baseado em árvores de decisão para clustering", "E) Funciona somente com dados categóricos"], "resposta_correta": "A"}
]
