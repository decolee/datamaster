# Databricks notebook source
perguntas_data_engineer_intermediario = [
    {"id": "3de", "pergunta": "Qual é o propósito principal de um ETL (Extract, Transform, Load)?", "opcoes": ["A) Extração de dados da internet", "B) Transformação de dados em gráficos", "C) Carga de dados em sistemas legados", "D) Extração, transformação e carga de dados para armazenamento", "E) Limpeza de dados corrompidos"], "resposta_correta": "D"},
    {"id": "4de", "pergunta": "O que é um Data Warehouse?", "opcoes": ["A) Uma ferramenta para processamento de transações online", "B) Um banco de dados usado para armazenar dados temporários", "C) Um sistema para armazenamento e análise de dados de grandes empresas", "D) Uma solução de backup de dados", "E) Um tipo de Data Lake"], "resposta_correta": "C"},
    {"id": "5de", "pergunta": "O que significa 'Data Munging'?", "opcoes": ["A) Criptografar dados", "B) Exportar dados", "C) Manipulação de dados para convertê-los de um formato bruto para outro formato", "D) Dividir um grande conjunto de dados", "E) Visualizar dados complexos"], "resposta_correta": "C"},
    {"id": "6de", "pergunta": "O que são pipelines de dados em engenharia de dados?", "opcoes": ["A) Ferramentas para análise de dados em tempo real", "B) Conjuntos de passos de processamento de dados", "C) Bancos de dados otimizados para grandes volumes de dados", "D) Técnicas de visualização de dados", "E) Algoritmos de machine learning"], "resposta_correta": "B"},
    {"id": "7de", "pergunta": "Qual destes é um exemplo de uma ferramenta de processamento de dados em batch?", "opcoes": ["A) Apache Kafka", "B) Apache Storm", "C) Apache Spark", "D) TensorFlow", "E) React"], "resposta_correta": "C"}
]


# COMMAND ----------

perguntas_machine_learning_intermediario = [
    {"id": "1ml", "pergunta": "O que é 'overfitting' em um modelo de Machine Learning?", "opcoes": ["A) Quando o modelo é muito simples para os dados", "B) Quando o modelo se ajusta demais aos dados de treino", "C) Falta de dados para treinar o modelo", "D) Uso de muitos algoritmos diferentes", "E) Treinamento insuficiente do modelo"], "resposta_correta": "B"},
    {"id": "2ml", "pergunta": "O que são 'features' em Machine Learning?", "opcoes": ["A) Erros no modelo", "B) As saídas do modelo", "C) Os inputs ou variáveis de entrada", "D) Os algoritmos utilizados", "E) Resultados das previsões"], "resposta_correta": "C"},
    {"id": "3ml", "pergunta": "Qual é a diferença entre 'classificação' e 'regressão' em Machine Learning?", "opcoes": ["A) Classificação lida com entradas numéricas e regressão com categóricas", "B) Não há diferença significativa", "C) Classificação é para previsões contínuas e regressão para discretas", "D) Classificação é para previsões discretas e regressão para contínuas", "E) Classificação usa somente dados não rotulados"], "resposta_correta": "D"},
    {"id": "4ml", "pergunta": "O que é um 'ensemble method' em Machine Learning?", "opcoes": ["A) Um único modelo robusto", "B) Um método para reduzir a dimensionalidade dos dados", "C) Uma combinação de diversos modelos para melhorar a performance", "D) Uma técnica para dividir o dataset", "E) Um método para acelerar o treinamento de modelos"], "resposta_correta": "C"},
    {"id": "5ml", "pergunta": "Como funciona o algoritmo K-means?", "opcoes": ["A) Divide o dataset em K grupos baseados em similaridades", "B) É um algoritmo de classificação supervisionada", "C) Usa redes neurais para agrupar os dados", "D) É baseado em árvores de decisão para clustering", "E) Funciona somente com dados categóricos"], "resposta_correta": "A"}
]


# COMMAND ----------

perguntas_maestro_intermediario = [
    {"id": "1ms", "pergunta": "Como o Maestro auxilia na gestão de cronogramas de TI?", "opcoes": ["A) Através de análises preditivas", "B) Implementando políticas de segurança", "C) Orquestrando e automatizando tarefas agendadas", "D) Gerenciando a comunicação entre equipes", "E) Monitorando o desempenho da rede"], "resposta_correta": "C"},
    {"id": "2ms", "pergunta": "Qual é a função do 'job scheduler' no Maestro?", "opcoes": ["A) Analisar o desempenho dos jobs", "B) Automatizar o backup de dados", "C) Agendar e gerenciar a execução de jobs", "D) Monitorar a saúde dos sistemas", "E) Gerenciar permissões de usuário"], "resposta_correta": "C"},
    {"id": "3ms", "pergunta": "O que significa a 'automação de processos de negócios' no contexto do Maestro?", "opcoes": ["A) Reduzir a necessidade de interação humana nos processos", "B) Aumentar a segurança dos processos de negócios", "C) Melhorar a comunicação entre diferentes departamentos", "D) Criar relatórios automáticos de desempenho", "E) Implementar novas tecnologias nos processos"], "resposta_correta": "A"},
    {"id": "4ms", "pergunta": "Como o Maestro contribui para a eficiência operacional?", "opcoes": ["A) Por meio da análise de dados em tempo real", "B) Através da otimização de recursos computacionais", "C) Implementando melhores práticas de codificação", "D) Gerenciando melhor os ativos de TI", "E) Automatizando tarefas repetitivas e rotineiras"], "resposta_correta": "E"},
    {"id": "5ms", "pergunta": "Qual é o benefício da 'integração de sistemas' proporcionada pelo Maestro?", "opcoes": ["A) Facilitar a comunicação entre diferentes plataformas", "B) Aumentar a capacidade de armazenamento", "C) Melhorar a segurança dos sistemas", "D) Reduzir os custos operacionais", "E) Aumentar a velocidade de processamento de dados"], "resposta_correta": "A"}
]


# COMMAND ----------

perguntas_controlm_intermediario = [
    {"id": "1cm", "pergunta": "Qual é a principal vantagem do Control-M na gestão de workflows?", "opcoes": ["A) Simplificação da análise de dados", "B) Aumento da segurança dos dados", "C) Melhoria na eficiência operacional", "D) Redução de custos com infraestrutura", "E) Facilitação do gerenciamento de projetos"], "resposta_correta": "C"},
    {"id": "2cm", "pergunta": "Como o Control-M ajuda na prevenção de falhas de sistema?", "opcoes": ["A) Através de monitoramento constante", "B) Implementando redundâncias de sistema", "C) Com backups automáticos de dados", "D) Por meio de testes automatizados de integridade", "E) Gerando relatórios detalhados de performance"], "resposta_correta": "A"},
    {"id": "3cm", "pergunta": "No Control-M, o que é um 'job'?", "opcoes": ["A) Uma tarefa agendada para ser executada", "B) Um relatório de desempenho", "C) Um alerta de sistema", "D) Uma solicitação de backup", "E) Uma tarefa manual executada por um operador"], "resposta_correta": "A"},
    {"id": "4cm", "pergunta": "Como o Control-M pode ser integrado com outras ferramentas?", "opcoes": ["A) Através de APIs", "B) Por meio de scripts personalizados", "C) Utilizando plugins específicos", "D) Com a importação e exportação de dados", "E) Por meio de uma interface gráfica de usuário"], "resposta_correta": "A"},
    {"id": "5cm", "pergunta": "Qual é o impacto do Control-M na gestão de SLAs (Service Level Agreements)?", "opcoes": ["A) Não tem impacto significativo", "B) Reduz a necessidade de SLAs", "C) Melhora o cumprimento dos SLAs através da automação", "D) Aumenta a complexidade dos SLAs", "E) Torna os SLAs obsoletos"], "resposta_correta": "C"}
]


# COMMAND ----------

perguntas_azure_intermediario = [
    {"id": "1az", "pergunta": "No Azure, o que são 'Virtual Machines'?", "opcoes": ["A) Dispositivos para armazenamento de dados", "B) Serviços para análise de dados", "C) Ambientes de computação em nuvem", "D) Ferramentas para gerenciamento de rede", "E) Sistemas para automação de workflows"], "resposta_correta": "C"},
    {"id": "2az", "pergunta": "Como o Azure Active Directory auxilia na segurança?", "opcoes": ["A) Através de backups automáticos", "B) Implementando controle de acesso baseado em identidade", "C) Monitorando o tráfego de rede", "D) Gerenciando a distribuição de recursos", "E) Oferecendo serviços de criptografia de dados"], "resposta_correta": "B"},
    {"id": "3az", "pergunta": "Qual é a função do Azure Blob Storage?", "opcoes": ["A) Hospedar aplicativos web", "B) Gerenciar bancos de dados", "C) Armazenar grandes volumes de dados não estruturados", "D) Automatizar processos de negócios", "E) Monitorar o desempenho da rede"], "resposta_correta": "C"}
   ]