# Databricks notebook source
# MAGIC %md
# MAGIC Passo 1: Identificar Matrículas Comuns
# MAGIC Identifica as matriculas que possuem no df_funcionários para atualizalas com os valores novos de respostas.

# COMMAND ----------

def identificar_matriculas_comuns(df1, df2):
    return df1.select("matricula").intersect(df2.select("matricula"))

# COMMAND ----------

# MAGIC %md
# MAGIC Passo 2: Filtrar df_notas e Calcular a Nova Nota

# COMMAND ----------

from pyspark.sql import functions as F

def filtrar_calcular_nova_nota(df_notas, matriculas_comuns):
    df_notas_filtrado = df_notas.join(matriculas_comuns, "matricula", "inner")\
        .withColumn("errado", F.coalesce("errado", F.lit(0)))\
        .withColumn("nova_nota", F.col("correto") - F.col("errado"))
    return df_notas_filtrado.groupBy("matricula")\
        .agg(F.sum("nova_nota").alias("soma_nova_nota"))


# COMMAND ----------

# MAGIC %md
# MAGIC Passo 3: Preparar funcionario_df e Atualizar a Nota Média

# COMMAND ----------

from pyspark.sql.types import LongType

def preparar_atualizar_funcionario_df(funcionario_df, df_agregado):
    funcionario_df = funcionario_df.withColumn("nota_media_long", F.col("nota_media").cast(LongType()))
    funcionario_atualizado = funcionario_df.join(df_agregado, "matricula", "left_outer")\
        .withColumn("nota_media_atualizada", 
                    F.when(F.col("soma_nova_nota").isNull(), F.col("nota_media_long"))
                     .otherwise((F.col("nota_media_long") + F.col("soma_nova_nota")) / 2))\
        .drop("nota_media", "nota_media_long", "soma_nova_nota")\
        .withColumnRenamed("nota_media_atualizada", "nota_media")
    return funcionario_atualizado


# COMMAND ----------

# MAGIC %md
# MAGIC Passo 4: Salvar como Tabela

# COMMAND ----------

def salvar_como_tabela(funcionario_atualizado, tabela):
    funcionario_atualizado.write.mode("overwrite").saveAsTable(tabela)


# COMMAND ----------

# MAGIC %md
# MAGIC Função Principal para Orquestrar os Passos

# COMMAND ----------

def atualizar_notas_funcionarios(df_notas, funcionario_df):
    matriculas_comuns = identificar_matriculas_comuns(df_notas, funcionario_df)
    df_agregado = filtrar_calcular_nova_nota(df_notas, matriculas_comuns)
    funcionario_atualizado = preparar_atualizar_funcionario_df(funcionario_df, df_agregado)
    salvar_como_tabela(funcionario_atualizado, "ts_tb_funcionarios_nota")
