# Databricks notebook source
import logging
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

# COMMAND ----------

# MAGIC %run ./perguntas_nv_basico

# COMMAND ----------

# MAGIC %run ./perguntas_nv_medio

# COMMAND ----------

# MAGIC %run ./perguntas_nv_avancado

# COMMAND ----------

# List of directories to be removed, including both basic and intermediate
directories = [
    "dbfs:/user/hive/warehouse/perguntas_machine_learning_basico",
    "dbfs:/user/hive/warehouse/perguntas_azure_basico",
    "dbfs:/user/hive/warehouse/perguntas_data_engineer_basico",
    "dbfs:/user/hive/warehouse/perguntas_maestro_basico",
    "dbfs:/user/hive/warehouse/perguntas_controlm_basico",
    "dbfs:/user/hive/warehouse/perguntas_machine_learning_intermediario",
    "dbfs:/user/hive/warehouse/perguntas_azure_intermediario",
    "dbfs:/user/hive/warehouse/perguntas_data_engineer_intermediario",
    "dbfs:/user/hive/warehouse/perguntas_maestro_intermediario",
    "dbfs:/user/hive/warehouse/perguntas_controlm_intermediario",
    "dbfs:/user/hive/warehouse/perguntas_machine_learning_avancado",
    "dbfs:/user/hive/warehouse/perguntas_azure_avancado",
    "dbfs:/user/hive/warehouse/perguntas_data_engineer_avancado",
    "dbfs:/user/hive/warehouse/perguntas_maestro_avancado",
    "dbfs:/user/hive/warehouse/perguntas_controlm_avancado"
]

# Function to remove a directory if it exists
def remove_directory_if_exists(path):
    try:
        # Attempt to delete the directory
        dbutils.fs.rm(path, recurse=True)
        print(f"Successfully removed: {path}")
    except Exception as e:
        # Handle the exception (e.g., directory does not exist)
        print(f"Could not remove {path}: {e}")

# Iterate over the list of directories and attempt to remove them
for directory in directories:
    remove_directory_if_exists(directory)


# COMMAND ----------

from pyspark.sql import SparkSession

# Initialize Spark Session with Delta support if necessary
# Ensure Delta Lake is enabled in your cluster configuration or through packages
spark = SparkSession.builder.appName("PerguntasDB").enableHiveSupport().getOrCreate()

# List of tables to check and delete if they exist
tables = [
    "perguntas_machine_learning_basico",
    "perguntas_azure_basico",
    "perguntas_data_engineer_basico",
    "perguntas_maestro_basico",
    "perguntas_controlm_basico"
]

# Check and delete the tables if they exist
for table in tables:
    if spark.sql(f"SHOW TABLES LIKE '{table}'").count() > 0:
        print(f"Table {table} exists and will be dropped.")
        spark.sql(f"DROP TABLE IF EXISTS {table}")
    else:
        print(f"Table {table} does not exist.")

# Definir o esquema para as perguntas
pergunta_schema = StructType([
    StructField("id", StringType(), True),
    StructField("pergunta", StringType(), True),
    StructField("opcoes", ArrayType(StringType()), True),
    StructField("resposta_correta", StringType(), True)
])

# Criar DataFrames
df_machine_learning_basico = spark.createDataFrame(perguntas_machine_learning_basico, schema=pergunta_schema)
df_azure_basico = spark.createDataFrame(perguntas_azure_basico, schema=pergunta_schema)
df_data_engineer_basico = spark.createDataFrame(perguntas_data_engineer_basico, schema=pergunta_schema)
df_perguntas_maestro_basico = spark.createDataFrame(perguntas_maestro_basico, schema=pergunta_schema)
df_perguntas_controlm_basico = spark.createDataFrame(perguntas_controlm_basico, schema=pergunta_schema)

# Salvar os DataFrames como tabelas
df_machine_learning_basico.write.saveAsTable("perguntas_machine_learning_basico")
df_azure_basico.write.saveAsTable("perguntas_azure_basico")
df_data_engineer_basico.write.saveAsTable("perguntas_data_engineer_basico")
df_perguntas_maestro_basico.write.saveAsTable("perguntas_maestro_basico")
df_perguntas_controlm_basico.write.saveAsTable("perguntas_controlm_basico")

# COMMAND ----------

# Ler as tabelas salvas para DataFrames
df_machine_learning_basico = spark.table("perguntas_machine_learning_basico")
df_azure_basico = spark.table("perguntas_azure_basico")
df_data_engineer_basico = spark.table("perguntas_data_engineer_basico")
df_maestro_basico = spark.table("perguntas_maestro_basico")
df_controlm_basico = spark.table("perguntas_controlm_basico")

# Combinar todos os DataFrames em uma única lista de perguntas
todas_perguntas_basico = (df_machine_learning_basico.union(df_azure_basico)
                          .union(df_data_engineer_basico)
                          .union(df_maestro_basico)
                          .union(df_controlm_basico)
                          .collect())

# Agora você pode usar todas_perguntas_basico com a função realizar_pergunta


# COMMAND ----------

from pyspark.sql import SparkSession
import logging

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("DropTablesAdvance").enableHiveSupport().getOrCreate()

# Lista de tabelas para verificar e excluir
tabelas = [
    "perguntas_machine_learning_avancado",
    "perguntas_azure_avancado",
    "perguntas_data_engineer_avancado",
    "perguntas_maestro_avancado",
    "perguntas_controlm_avancado"
]

# Verificar e excluir as tabelas se existirem
for tabela in tabelas:
    if spark._jsparkSession.catalog().tableExists(tabela):
        logging.info(f"A tabela {tabela} existe e será excluída.")
        spark.sql(f"DROP TABLE {tabela}")
    else:
        logging.info(f"A tabela {tabela} não existe.")


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("PerguntasDA").getOrCreate()

# Criar DataFrames
df_machine_learning_avancado = spark.createDataFrame(perguntas_machine_learning_avancado, schema=pergunta_schema)
df_azure_avancado = spark.createDataFrame(perguntas_azure_avancado, schema=pergunta_schema)
df_data_engineer_avancado = spark.createDataFrame(perguntas_data_engineer_avancado, schema=pergunta_schema)
df_perguntas_maestro_avancado = spark.createDataFrame(perguntas_maestro_avancado, schema=pergunta_schema)
df_perguntas_controlm_avancado = spark.createDataFrame(perguntas_controlm_avancado, schema=pergunta_schema)

# Salvar os DataFrames como tabelas
df_machine_learning_avancado.write.saveAsTable("perguntas_machine_learning_avancado")
df_azure_avancado.write.saveAsTable("perguntas_azure_avancado")
df_data_engineer_avancado.write.saveAsTable("perguntas_data_engineer_avancado")
df_perguntas_maestro_avancado.write.saveAsTable("perguntas_maestro_avancado")
df_perguntas_controlm_avancado.write.saveAsTable("perguntas_controlm_avancado")

# Ler as tabelas salvas para DataFrames
df_machine_learning_avancado = spark.table("perguntas_machine_learning_avancado")
df_azure_avancado = spark.table("perguntas_azure_avancado")
df_data_engineer_avancado = spark.table("perguntas_data_engineer_avancado")
df_maestro_avancado = spark.table("perguntas_maestro_avancado")
df_controlm_avancado = spark.table("perguntas_controlm_avancado")

# Combinar todos os DataFrames em uma única lista de perguntas
todas_perguntas_avancado = (df_machine_learning_avancado.union(df_azure_avancado)
                          .union(df_data_engineer_avancado)
                          .union(df_maestro_avancado)
                          .union(df_controlm_avancado)
                          .collect())


# COMMAND ----------

from pyspark.sql import SparkSession
import logging

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("DropTables").enableHiveSupport().getOrCreate()

# Lista de tabelas para verificar e excluir
tabelas = [
    "perguntas_machine_learning_intermediario",
    "perguntas_azure_intermediario",
    "perguntas_data_engineer_intermediario",
    "perguntas_maestro_intermediario",
    "perguntas_controlm_intermediario"
]

# Verificar e excluir as tabelas se existirem
for tabela in tabelas:
    if spark._jsparkSession.catalog().tableExists(tabela):
        logging.info(f"A tabela {tabela} existe e será excluída.")
        spark.sql(f"DROP TABLE {tabela}")
    else:
        logging.info(f"A tabela {tabela} não existe.")


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType

# Iniciar a sessão Spark
spark = SparkSession.builder.appName("PerguntasDA").getOrCreate()

# Criar DataFrames
df_machine_learning_intermediario = spark.createDataFrame(perguntas_machine_learning_intermediario, schema=pergunta_schema)
df_azure_intermediario = spark.createDataFrame(perguntas_azure_intermediario, schema=pergunta_schema)
df_data_engineer_intermediario = spark.createDataFrame(perguntas_data_engineer_intermediario, schema=pergunta_schema)
df_perguntas_maestro_intermediario = spark.createDataFrame(perguntas_maestro_intermediario, schema=pergunta_schema)
df_perguntas_controlm_intermediario = spark.createDataFrame(perguntas_controlm_intermediario, schema=pergunta_schema)

# Salvar os DataFrames como tabelas
df_machine_learning_intermediario.write.saveAsTable("perguntas_machine_learning_intermediario")
df_azure_intermediario.write.saveAsTable("perguntas_azure_intermediario")
df_data_engineer_intermediario.write.saveAsTable("perguntas_data_engineer_intermediario")
df_perguntas_maestro_intermediario.write.saveAsTable("perguntas_maestro_intermediario")
df_perguntas_controlm_intermediario.write.saveAsTable("perguntas_controlm_intermediario")

# Ler as tabelas salvas para DataFrames
df_machine_learning_intermediario = spark.table("perguntas_machine_learning_intermediario")
df_azure_intermediario = spark.table("perguntas_azure_intermediario")
df_data_engineer_intermediario = spark.table("perguntas_data_engineer_intermediario")
df_maestro_intermediario = spark.table("perguntas_maestro_intermediario")
df_controlm_intermediario = spark.table("perguntas_controlm_intermediario")

# Combinar todos os DataFrames em uma única lista de perguntas
todas_perguntas_intermediario = (df_machine_learning_intermediario.union(df_azure_intermediario)
                          .union(df_data_engineer_intermediario)
                          .union(df_maestro_intermediario)
                          .union(df_controlm_intermediario)
                          .collect())


# COMMAND ----------

